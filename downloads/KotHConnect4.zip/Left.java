public class Left extends Player {
    public String getName () {
        return "Left";
    }

    public int takeTurn (int[][] board) {
        return 0;
    }
}