enum Alignment {
    PLAYER_1,
    PLAYER_2,
    UNALIGNED
}