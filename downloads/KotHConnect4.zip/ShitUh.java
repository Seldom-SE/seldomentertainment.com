public class ShitUh extends Player {
    public String getName () {
        return "Shit, uh...";
    }

    public int takeTurn (int[][] board) {
        return -1;
    }
}