public abstract class Player {
    public abstract String getName ();
    public abstract int takeTurn (int[][] board);
}