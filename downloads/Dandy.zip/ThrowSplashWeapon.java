class ThrowSplashWeapon extends RangedTouchAttack {
    private Dice hitDamage;
    private int hitDamageBonus;
    private Dice missDamage;
    private int missDamageBonus;
    StatusEffect effect;

    public ThrowSplashWeapon (Creature actor, Creature target,
    Dice hitDamage, int hitDamageBonus, Dice missDamage, int missDamageBonus, StatusEffect effect) {
        this.actor = actor;
        this.target = target;
        this.hitDamage = hitDamage;
        this.hitDamageBonus = hitDamageBonus;
        this.missDamage = missDamage;
        this.missDamageBonus = missDamageBonus;
        this.effect = effect;
    }

    public void attack (int attackBonus, int DC) {
        int roll = (new Dice(1, 20)).roll();
        int comp = roll + attackBonus - DC;
        if (roll == 20 || (comp >= 0 && roll != 1)) hit(hitDamage, hitDamageBonus);
        else miss(missDamage, missDamageBonus);
    }

    protected void hit (Dice damage, int damageBonus) {
        System.out.printf("%s's bottle hits %s, breaking against them.\n", actor.getName(), target.getName());
        target.takeDamage(damage.roll() + damageBonus);
        if (effect != null) {
            target.get(effect);
        }
    }

    protected void miss (Dice damage, int damageBonus) {
        System.out.printf("%s dodges %s's bottle, but it shatters against the ground and the fluid splashes against them.\n", target.getName(), actor.getName());
        target.takeDamage(damage.roll() + damageBonus);
    }
}