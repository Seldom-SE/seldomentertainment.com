interface Consumable {
    public void consume (Creature consumer);
}