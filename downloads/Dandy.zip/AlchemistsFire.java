class AlchemistsFire extends Item implements Consumable {
    public AlchemistsFire () {
        super("alchemist's fire", 2000, 10);
    }

    public void consume (Creature consumer) {
        Creature [] creatures = consumer.findCreatures();
        String [] creatureNames = new String [creatures.length];
        for (int i = 0; i < creatures.length; i++) creatureNames[i] = creatures[i].getName();
        Creature target = creatures[Prompt.prompt("Select a target", creatureNames)];
        System.out.printf("%s throws a bottle of alchemist's fire at %s\n", consumer.getName(), target.getName());
        (new ThrowSplashWeapon(consumer, target, new Dice(1, 6), 0, new Dice(0, 0), 1, new ResidualDamage(name, target, new Dice(1, 6), 0, target.getReflex(), 15))).act();
    }
}