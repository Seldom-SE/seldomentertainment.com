import java.util.Random;

class Dice {
    private Random random = new Random();
    private int count;
    private int faces;

    public Dice (int count, int faces) {
        this.count = count;
        this.faces = faces;
    }

    public int roll () {
        int total = 0;
        for (int roll = 0; roll < count; roll++) total += random.nextInt(faces) + 1;
        return total;
    }

    public int getFaces () {
        return faces;
    }

    public String toString () {
        return count + "d" + faces;
    }
}