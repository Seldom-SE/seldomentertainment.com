abstract class RangedAttack extends Attack {
    public void act () {
        attack(actor.getAttackBonus(1) + actor.getDexMod() + actor.getSizeModifier(), target.getAC());
    }
}