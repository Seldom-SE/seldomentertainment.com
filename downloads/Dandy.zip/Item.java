class Item {
    String name;
    long value; // In copper pieces
    int weight; // In tenths of pounds

    public Item (String name, int value, int weight) {
        this.name = name;
        this.value = value;
        this.weight = weight;
    }

    public String getName () {
        return name;
    }

    public long getValue () {
        return value;
    }

    public int getWeight () {
        return weight;
    }
}