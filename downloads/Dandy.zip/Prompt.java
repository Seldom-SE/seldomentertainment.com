import java.util.InputMismatchException;

class Prompt {
    public static int prompt (String prompt, String [] options) {
        if (options.length == 0) throw new IllegalStateException("Prompt has no options");
        System.out.printf("%s\n", prompt);
        for (int i = 0; i < options.length; i++) System.out.printf("[%02d] %s\n", i, options[i]);
        System.out.print("# ");
        int response = -1;
        boolean valid = false;
        while (!valid) {
            try {
                response = Dandy.scanner.nextInt();
                if (response < 0 || response >= options.length) throw new InputMismatchException();
                valid = true;
            } catch (InputMismatchException e) {
                System.out.print("Error\n# ");
                Dandy.scanner.nextLine();
            } 
        }

        Dandy.scanner.nextLine();
        System.err.println();
        return response;
    }

    public static String promptString (String prompt) {
        System.out.printf("%s\n# ", prompt);
        String response = Dandy.scanner.nextLine();
        System.out.println();
        return response;
    }

    public static int promptIntRange (String prompt, int min, int max) {
        System.out.printf("%s [%d-%d]\n# ", prompt, min, max);
        int response = min - 1;
        boolean valid = false;
        while (!valid) {
            try {
                response = Dandy.scanner.nextInt();
                if (response < min || response > max) throw new InputMismatchException();
                valid = true;
            } catch (InputMismatchException e) {
                System.out.print("Error\n# ");
                Dandy.scanner.nextLine();
            } 
        }

        Dandy.scanner.nextLine();
        System.out.println();
        return response;
    }
}