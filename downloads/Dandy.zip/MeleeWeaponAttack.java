class MeleeWeaponAttack extends MeleeAttack {
    private Dice damage;
    private int damageBonus;

    public MeleeWeaponAttack (Creature actor, Creature target,
    Dice damage, int damageBonus) {
        this.actor = actor;
        this.target = target;
        this.damage = damage;
        this.damageBonus = damageBonus;
    }

    public void attack (int attackBonus, int DC) {
        int roll = (new Dice(1, 20)).roll();
        int comp = roll + attackBonus - DC;
        if (roll == 20 || (comp >= 0 && roll != 1)) hit(damage, damageBonus);
        else System.out.printf("%s misses %s with their weapon\n", actor.getName(), target.getName());
    }

    protected void hit (Dice damage, int damageBonus) {
        System.out.printf("%s hits %s with their weapon\n", actor.getName(), target.getName());
        target.takeDamage(damage.roll() + damageBonus);
    }
}