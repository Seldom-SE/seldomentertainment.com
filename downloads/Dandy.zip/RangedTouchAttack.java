abstract class RangedTouchAttack extends RangedAttack {
    public void act () {
        attack(actor.getAttackBonus(1) + actor.getDexMod(), target.getTouchAC());
    }
}