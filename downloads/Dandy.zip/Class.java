class Class {
    private String name;
    private Dice hitDie;

    private AttackBonusQuality attackBonus;
    private SaveBonusQuality fortitudeBonus;
    private SaveBonusQuality reflexBonus;
    private SaveBonusQuality willBonus;

    public Class (String name, Dice hitDie,
    AttackBonusQuality attackBonus, SaveBonusQuality fortitudeBonus, SaveBonusQuality reflexBonus, SaveBonusQuality willBonus) {
        this.name = name;
        this.hitDie = hitDie;
        this.attackBonus = attackBonus;
        this.fortitudeBonus = fortitudeBonus;
        this.reflexBonus = reflexBonus;
        this.willBonus = willBonus;
    }

    public String getName () {
        return name;
    }

    public Dice getHitDie () {
        return hitDie;
    }

    public AttackBonusQuality getAttackBonus () {
        return attackBonus;
    }

    public String getAttackBonusName () {
        switch (attackBonus) {
            case POOR:
                return "poor";
            case AVERAGE:
                return "average";
            case GOOD:
                return "good";
        }
        return "";
    }

    public SaveBonusQuality getFortitudeBonus () {
        return fortitudeBonus;
    }

    public SaveBonusQuality getReflexBonus () {
        return reflexBonus;
    }

    public SaveBonusQuality getWillBonus () {
        return willBonus;
    }

    public String getFortitudeBonusName () {
        switch (fortitudeBonus) {
            case POOR:
                return "poor";
            case GOOD:
                return "good";
        }
        return "";
    }

    public String getReflexBonusName () {
        switch (reflexBonus) {
            case POOR:
                return "poor";
            case GOOD:
                return "good";
        }
        return "";
    }

    public String getWillBonusName () {
        switch (willBonus) {
            case POOR:
                return "poor";
            case GOOD:
                return "good";
        }
        return "";
    }
}