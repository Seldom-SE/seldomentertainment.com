class RangedWeapon extends Weapon {
    Item ammo;

    public RangedWeapon (String name, int value, int weight,
    Dice smallDamage, Dice mediumDamage, Item ammo) {
        super(name, value, weight);
        this.smallDamage = smallDamage;
        this.mediumDamage = mediumDamage;
        this.ammo = ammo;
    }

    public boolean canAttack (Creature bearer) {
        return bearer.has(ammo);
    }

    public void attack (Creature bearer, Creature target) {
        System.out.printf("%s attacks %s with a %s from their %s\n", bearer.getName(), target.getName(), ammo.getName(), name);
        bearer.expend(ammo);
        new RangedWeaponAttack(bearer, target, bearer.isAtLeastMedium() ? mediumDamage : smallDamage, bearer.getDexMod()).act();
    }
}