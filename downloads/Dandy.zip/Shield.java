class Shield extends Item {
    private int shieldBonus;

    public Shield (String name, int value, int weight, int shieldBonus) {
        super(name, value, weight);
        this.shieldBonus = shieldBonus;
    }

    public int getShieldBonus () {
        return shieldBonus;
    }
}