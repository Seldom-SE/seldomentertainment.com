enum SaveBonusQuality {
    POOR, GOOD;
}