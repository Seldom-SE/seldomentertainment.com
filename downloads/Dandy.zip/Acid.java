class Acid extends Item implements Consumable {
    public Acid () {
        super("acid", 1000, 10);
    }

    public void consume (Creature consumer) {
        Creature [] creatures = consumer.findCreatures();
        String [] creatureNames = new String [creatures.length];
        for (int i = 0; i < creatures.length; i++) creatureNames[i] = creatures[i].getName();
        Creature target = creatures[Prompt.prompt("Select a target", creatureNames)];
        System.out.printf("%s lobs a bottle of acid at %s\n", consumer.getName(), target.getName());
        (new ThrowSplashWeapon(consumer, target, new Dice(1, 6), 0, new Dice(0, 0), 1, null)).act();
    }

    public void consumeRandom (Creature consumer) {
        Creature [] creatures = consumer.findCreatures();
        String [] creatureNames = new String [creatures.length];
        for (int i = 0; i < creatures.length; i++) creatureNames[i] = creatures[i].getName();
        Creature target = creatures[(new Dice(1, creatureNames.length).roll()) - 1];
        System.out.printf("%s lobs a bottle of acid at %s\n", consumer.getName(), target.getName());
        (new ThrowSplashWeapon(consumer, target, new Dice(1, 6), 0, new Dice(0, 0), 1, null)).act();
    }
}