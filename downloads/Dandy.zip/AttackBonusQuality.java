enum AttackBonusQuality {
    POOR, AVERAGE, GOOD;
}