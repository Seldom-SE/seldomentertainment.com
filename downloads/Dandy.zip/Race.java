class Race {
    private String name;
    private Size size;
    private int naturalAC;

    private int strength;
    private int dexterity;
    private int constitution;
    private int intelligence;
    private int wisdom;
    private int charisma;

    public Race (String name, Size size) {
        this.name = name;
        this.size = size;
    }

    public Race (String name, Size size, int naturalAC,
    int strength, int dexterity, int constitution, int intelligence, int wisdom, int charisma) {
        this(name, size);
        this.strength = strength;
        this.dexterity = dexterity;
        this.constitution = constitution;
        this.intelligence = intelligence;
        this.wisdom = wisdom;
        this.charisma = charisma;
    }

    public String getName () {
        return name;
    }

    public Size getSize () {
        return size;
    }

    public String getSizeName () {
        switch (size) {
            case FINE:
                return "fine";
            case DIMINUTIVE:
                return "diminutive";
            case TINY:
                return "tiny";
            case SMALL:
                return "small";
            case MEDIUM:
                return "medium";
            case LARGE:
                return "large";
            case HUGE:
                return "huge";
            case GARGANTUAN:
                return "gargantuan";
            case COLOSSAL:
                return "colossal";
        }
        return "";
    }

    public int getNaturalAC () {
        return naturalAC;
    }

    public int getStrength () {
        return strength;
    }
    
    public int getDexterity () {
        return dexterity;
    }

    public int getConstitution () {
        return constitution;
    }

    public int getIntelligence () {
        return intelligence;
    }

    public int getWisdom () {
        return wisdom;
    }

    public int getCharisma () {
        return charisma;
    }
}