import java.util.ArrayList;

class PlayerCharacter extends Creature {
    private Class _class;
    private int level;
    private int maxHitPoints;

    private Weapon unarmedStrike = new MeleeWeapon("Unarmed Strike", 0, 0, new Dice(1, 2), new Dice(1, 3));

    public PlayerCharacter (ArrayList <Race> races, ArrayList <Class> classes, ArrayList <Item> items) {
        ArrayList <String> options = new ArrayList <String> ();
        String nameOption = "Choose name";
        String abilityScoresOption = "Roll ability scores";
        String raceOption = "Choose race";
        String levelOption = "Choose level";
        String classOption = "Choose class";
        String equipmentOption = "Choose equipment";
        options.add(nameOption);
        options.add(abilityScoresOption);
        options.add(raceOption);
        options.add(levelOption);
        options.add(classOption);
        options.add(equipmentOption);

        name = "this character";

        while (!options.isEmpty()) {
            int option = Prompt.prompt("Select a step", options.toArray(new String [0]));
            if (option == options.indexOf(nameOption)) {
                name = Prompt.promptString("What is this character's name?");
                options.remove(nameOption);
            } else if (option == options.indexOf(abilityScoresOption)) {
                System.out.println("House rule: ability scores are randomly assigned, and the lowest roll isn't dropped");
                System.out.println("This makes more interesting characters and parties");
                System.out.println("Current ability scores:");
                System.out.printf("Str: %d (%+d), Dex: %d (%+d), Con: %d (%+d), Int: %d (%+d), Wis: %d (%+d), Cha: %d (%+d)\n",
                    strength, getStrMod(), dexterity, getDexMod(), constitution, getConMod(), intelligence, getIntMod(), wisdom, getWisMod(), charisma, getChaMod());
                System.out.printf("Rolling %s's ability scores...\n", name);
                strength += (new Dice(3, 6)).roll();
                dexterity += (new Dice(3, 6)).roll();
                constitution += (new Dice(3, 6)).roll();
                intelligence += (new Dice(3, 6)).roll();
                wisdom += (new Dice(3, 6)).roll();
                charisma += (new Dice(3, 6)).roll();
                System.out.println("Current ability scores:");
                System.out.printf("Str: %d (%+d), Dex: %d (%+d), Con: %d (%+d), Int: %d (%+d), Wis: %d (%+d), Cha: %d (%+d)\n",
                    strength, getStrMod(), dexterity, getDexMod(), constitution, getConMod(), intelligence, getIntMod(), wisdom, getWisMod(), charisma, getChaMod());
                options.remove(abilityScoresOption);
            } else if (option == options.indexOf(raceOption)) {
                System.out.println("In this world, we don't get to choose our race");
                System.out.println("Just kidding, go ahead");
                String [] raceOptions = new String [races.size()];
                for (int i = 0; i < raceOptions.length; i++) raceOptions[i] = races.get(i).getName();
                race = races.get(Prompt.prompt("Select " + name + "'s race", raceOptions));
                strength += race.getStrength();
                dexterity += race.getDexterity();
                constitution += race.getConstitution();
                intelligence += race.getIntelligence();
                wisdom += race.getWisdom();
                charisma += race.getCharisma();
                System.out.println("Current ability scores:");
                System.out.printf("Str: %d (%+d), Dex: %d (%+d), Con: %d (%+d), Int: %d (%+d), Wis: %d (%+d), Cha: %d (%+d)\n",
                    strength, getStrMod(), dexterity, getDexMod(), constitution, getConMod(), intelligence, getIntMod(), wisdom, getWisMod(), charisma, getChaMod());
                System.out.printf("Size: %s\n", race.getSizeName());
                System.out.printf("Natural AC: %d\n", race.getNaturalAC());
                options.remove(raceOption);
            } else if (option == options.indexOf(levelOption)) {
                level = Prompt.promptIntRange("What is " + name + "'s level?", 1, 20);
                options.remove(levelOption);
            } else if (option == options.indexOf(classOption)) {
                String [] classOptions = new String [classes.size()];
                for (int i = 0; i < classOptions.length; i++) classOptions[i] = classes.get(i).getName();
                _class = classes.get(Prompt.prompt("Select " + name + "'s class", classOptions));
                System.out.printf("Hit die: d%d\n", _class.getHitDie().getFaces());
                System.out.printf("Base attack bonus: %s\n", _class.getAttackBonusName());
                System.out.printf("Base fortitude bonus: %s\n", _class.getFortitudeBonusName());
                System.out.printf("Base reflex bonus: %s\n", _class.getReflexBonusName());
                System.out.printf("Base will bonus: %s\n", _class.getWillBonusName());
                options.remove(classOption);
            } else if (option == options.indexOf(equipmentOption)) {
                int itemOption = -1;
                String [] itemOptions = new String[items.size() + 1];
                for (int i = 0; i < items.size(); i++) itemOptions[i] = items.get(i).getName();
                itemOptions[itemOptions.length - 1] = "EXIT";
                while (itemOption != items.size()) {
                    itemOption = Prompt.prompt("Select an item to give " + name, itemOptions);
                    if (itemOption == items.size()) break;
                    get(items.get(itemOption));
                }
                options.remove(equipmentOption);
            }
        }

        for (int i = 0; i < level; i++) maxHitPoints += _class.getHitDie().roll() + getConMod();
        hitPoints = maxHitPoints;

        System.out.println("Inventory");

        for (Item item : equipment) {
            System.out.println();
            System.out.printf("%s:\n", item.getName());
            if (item instanceof Weapon) {
                System.out.printf("Attack: %+d\n", getAttackBonus(1) + (item instanceof RangedWeapon ? getDexMod() : getStrMod()) + getSizeModifier());
                System.out.printf("Damage: %s%+d\n", isAtLeastMedium() ? ((Weapon) item).getMediumDamage().toString() : ((Weapon) item).getSmallDamage().toString(), item instanceof RangedWeapon ? getDexMod() : getStrMod());
            } else if (item instanceof Armor) {
                System.out.printf("Armor bonus: %+d\n", ((Armor) item).getArmorBonus());
            } else if (item instanceof Shield) {
                System.out.printf("Armor bonus: %+d\n", ((Shield) item).getShieldBonus());
            }
            System.out.printf("Value: %.2f gp\n", item.getValue() / 100f);
            System.out.printf("Weight: %.1f lb\n", item.getWeight() / 10f);
        }

        System.out.println();
        System.out.printf("%s:\n", name);
        System.out.printf("Level %d %s %s\n", level, race.getName(), _class.getName());
        System.out.printf("Hit Points: %d\n", hitPoints);
        System.out.printf("Str: %d (%+d), Dex: %d (%+d), Con: %d (%+d), Int: %d (%+d), Wis: %d (%+d), Cha: %d (%+d)\n",
            strength, getStrMod(), dexterity, getDexMod(), constitution, getConMod(), intelligence, getIntMod(), wisdom, getWisMod(), charisma, getChaMod());
        System.out.printf("AC: %d, Touch AC: %d\n", getAC(), getTouchAC());
        System.out.printf("Fortitude: %+d, Reflex: %+d, Will: %+d\n\n", getFortitude(), getReflex(), getWill());
        
    }

    public void takeTurn () {
        ArrayList <String> options = new ArrayList <String> ();

        int attackOption = options.size();
        options.add("Attack");

        int useItemOption = -1;
        ArrayList <Consumable> consumables = new ArrayList <Consumable> ();
        for (Item item : equipment) if (item instanceof Consumable) consumables.add((Consumable) item);
        if (consumables.size() > 0) {
            useItemOption = options.size();
            options.add("Use item");
        }

        int choice = Prompt.prompt("Select an action", options.toArray(new String[0]));
        if (choice == attackOption) attack();
        if (choice == useItemOption) useConsumable(consumables);
    }

    public boolean isUp () {
        return hitPoints > 0;
    }

    public boolean isAlive () {
        return hitPoints > -10;
    }

    public void replenishHitPoints () {
        hitPoints = maxHitPoints;
    }

    private void attack () {
        ArrayList <Weapon> weapons = new ArrayList <Weapon> ();
        weapons.add(unarmedStrike);
        for (Item item : equipment) if (item instanceof Weapon && !(item instanceof RangedWeapon && !((RangedWeapon) item).canAttack(this))) weapons.add((Weapon) item);
        String [] options = new String [weapons.size()];
        for (int i = 0; i < weapons.size(); i++) options[i] = ((Item) weapons.get(i)).getName();
        Creature [] creatures = Dandy.getCreatures();
        ArrayList <Creature> temp = new ArrayList <Creature> ();
        for (int i = 0; i < creatures.length; i++) if (creatures[i].isAlive()) temp.add(creatures[i]);
        creatures = temp.toArray(new Creature [0]);
        String [] targetOptons = new String [creatures.length];
        for (int i = 0; i < creatures.length; i++) targetOptons[i] = creatures[i].getName();
        weapons.get(Prompt.prompt("Select a weapon", options)).attack(this, creatures[Prompt.prompt("Select a target", targetOptons)]);
    }

    private void useConsumable (ArrayList <Consumable> consumables) {
        String [] options = new String [consumables.size()];
        for (int i = 0; i < consumables.size(); i++) options[i] = ((Item) consumables.get(i)).getName();
        Consumable consumable = consumables.get(Prompt.prompt("Select an item", options));
        consumable.consume(this);
        equipment.remove((Item) consumable);
    }

    public void takeDamage (int damage) {
        if (damage < 0) damage = 0;
        hitPoints -= damage;
        System.out.printf("%s took %d damage. They now have %d hit points.\n", name, damage, hitPoints);
        if (hitPoints <= 0) {
            System.out.printf("%s is fallen\n", name);
            if (hitPoints <= -10) {
                System.out.printf("%s is dead\n", name);
            }
        }
    }

    public int getAttackBonus (int attackCount) {
        int firstAttackBonus = 0;
        switch (_class.getAttackBonus()) {
            case POOR:
                firstAttackBonus = level / 2;
                break;
            case AVERAGE:
                firstAttackBonus = level * 3 / 4;
                break;
            case GOOD:
                firstAttackBonus = level;
        }
        return firstAttackBonus - 5 * (attackCount - 1);
    }

    public int getFortitudeBonus () {
        switch (_class.getFortitudeBonus()) {
            case POOR:
                return level / 3;
            case GOOD:
                return level / 2 + 2;
        }
        return 0;
    }

    public int getReflexBonus () {
        switch (_class.getReflexBonus()) {
            case POOR:
                return level / 3;
            case GOOD:
                return level / 2 + 2;
        }
        return 0;
    }

    public int getWillBonus () {
        switch (_class.getWillBonus()) {
            case POOR:
                return level / 3;
            case GOOD:
                return level / 2 + 2;
        }
        return 0;
    }

    public int getFortitude () {
        return getFortitudeBonus() + getConMod();
    }

    public int getReflex () {
        return getReflexBonus() + getDexMod();
    }

    public int getWill () {
        return getWillBonus() + getWisMod();
    }

    protected int getNaturalAC() {
        return race.getNaturalAC();
    }
}