abstract class Attack extends TargetAction {
    public abstract void attack (int attackBonus, int DC);
    protected abstract void hit (Dice damage, int damageBonus);
}