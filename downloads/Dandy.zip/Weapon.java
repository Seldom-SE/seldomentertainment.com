abstract class Weapon extends Item {
    Dice smallDamage;
    Dice mediumDamage;

    public Weapon (String name, int value, int weight) {
        super(name, value, weight);
    }

    public Dice getSmallDamage () {
        return smallDamage;
    }

    public Dice getMediumDamage () {
        return mediumDamage;
    }

    public abstract void attack (Creature bearer, Creature target);
}