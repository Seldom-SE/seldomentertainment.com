abstract class TargetAction extends Action {
    protected Creature target;
}