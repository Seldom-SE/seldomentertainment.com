import java.util.ArrayList;

abstract class Creature {
    protected String name;
    protected Race race;

    protected int hitPoints;

    protected int strength;
    protected int dexterity;
    protected int constitution;
    protected int intelligence;
    protected int wisdom;
    protected int charisma;

    protected ArrayList <StatusEffect> statusEffects = new ArrayList <StatusEffect> ();

    protected ArrayList <Item> equipment = new ArrayList <Item> ();

    public abstract void takeTurn ();

    public String getName () {
        return name;
    }

    public abstract boolean isUp ();
    public abstract boolean isAlive ();

    public int getHitPoints () {
        return hitPoints;
    }

    public abstract void takeDamage (int damage);

    public int getAC () {
        return getTouchAC() + getNaturalAC() + getArmorBonus() + getShieldBonus();
    }

    public int getTouchAC () {
        return 10 + getDexMod() + getSizeModifier();
    }

    protected abstract int getNaturalAC ();

    protected int getArmorBonus() {
        for (Item item : equipment) if (item instanceof Armor) return ((Armor) item).getArmorBonus();
        return 0;
    }

    protected int getShieldBonus() {
        for (Item item : equipment) if (item instanceof Shield) return ((Shield) item).getShieldBonus();
        return 0;
    }

    public int getStrMod () {
        return strength / 2 - 5;
    }

    public int getDexMod () {
        return dexterity / 2 - 5;
    }

    public int getConMod () {
        return constitution / 2 - 5;
    }

    public int getIntMod () {
        return intelligence / 2 - 5;
    }

    public int getWisMod () {
        return wisdom / 2 - 5;
    }

    public int getChaMod () {
        return charisma / 2 - 5;
    }

    public abstract int getAttackBonus (int attackCount);

    public abstract int getFortitude ();
    public abstract int getReflex ();
    public abstract int getWill ();

    public boolean isAtLeastMedium () {
        switch (race.getSize()) {
            case FINE:
                return false;
            case DIMINUTIVE:
                return false;
            case TINY:
                return false;
            case SMALL:
                return false;
            case MEDIUM:
                return true;
            case LARGE:
                return true;
            case HUGE:
                return true;
            case GARGANTUAN:
                return true;
            case COLOSSAL:
                return true;
        }
        return false;
    }

    public int getSizeModifier () {
        switch (race.getSize()) {
            case FINE:
                return 8;
            case DIMINUTIVE:
                return 4;
            case TINY:
                return 2;
            case SMALL:
                return 1;
            case MEDIUM:
                return 0;
            case LARGE:
                return -1;
            case HUGE:
                return -2;
            case GARGANTUAN:
                return -4;
            case COLOSSAL:
                return -8;
        }
        return 0;
    }

    public boolean inventoryIsEmpty () {
        return equipment.isEmpty();
    }

    public boolean has (Item item) {
        return equipment.contains(item);
    }

    public void get (Item item) {
        equipment.add(item);
    }

    public void get (StatusEffect effect) {
        statusEffects.add(effect);
    }

    public void expend (Item item) {
        equipment.remove(item);
    }

    protected void printInventory () {
        System.out.print("[");
        for (int i = 0; i < equipment.size() - 1; i++) System.out.printf("%s, ", equipment.get(i).getName());
        System.out.printf("%s]\n", equipment.get(equipment.size() - 1).getName());
    }

    public void doStatusEffects () {
        for (int i = 0; i < statusEffects.size(); i++) {
            statusEffects.get(i).effect();
            if (statusEffects.get(i) instanceof ResidualDamage) { 
                if (((ResidualDamage) statusEffects.get(i)).isComplete()) statusEffects.remove(i);
            }
        }
    }

    public Creature [] findCreatures () {
        return findCreatures(Dandy.getCreatures());
    }

    public Creature [] findCreatures (Creature [] creatures) {
        return creatures;
    }
}