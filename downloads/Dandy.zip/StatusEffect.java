abstract class StatusEffect {
    protected Creature affected;

    public abstract void effect ();
}