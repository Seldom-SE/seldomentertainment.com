import java.util.ArrayList;

public class Monster extends Creature {
    private int baseAttackBonus;
    private int naturalAC;

    private int fortitude;
    private int reflex;
    private int will;

    private Weapon unarmedStrike = new MeleeWeapon("Unarmed Strike", 0, 0, new Dice(1, 2), new Dice(1, 3));

    public Monster (String name, Race race, Dice hitDice, int hitBonus,
    int strength, int dexterity, int constitution, int intelligence, int wisdom, int charisma,
    int baseAttackBonus, int fortitude, int reflex, int will, int naturalAC) {
        this.name = name;
        this.race = race;
        this.hitPoints = hitDice.roll() + hitBonus;
        this.strength = strength;
        this.dexterity = dexterity;
        this.constitution = constitution;
        this.intelligence = intelligence;
        this.wisdom = wisdom;
        this.charisma = charisma;
        this.fortitude = fortitude;
        this.reflex = reflex;
        this.will = will;
        this.naturalAC = naturalAC;
    }

    public void takeTurn () {
        ArrayList <String> options = new ArrayList <String> ();

        int attackOption = options.size();
        options.add("Attack");

        int useItemOption = -1;
        ArrayList <Consumable> consumables = new ArrayList <Consumable> ();
        for (Item item : equipment) if (item instanceof Consumable) consumables.add((Consumable) item);
        if (consumables.size() > 0) {
            useItemOption = options.size();
            options.add("Use item");
        }

        int choice = (new Dice(1, options.size()).roll()) - 1;
        if (choice == attackOption) attack();
        if (choice == useItemOption) useConsumable(consumables);
    }

    private void attack () {
        ArrayList <Weapon> weapons = new ArrayList <Weapon> ();
        weapons.add(unarmedStrike);
        for (Item item : equipment) if (item instanceof Weapon && !(item instanceof RangedWeapon && !((RangedWeapon) item).canAttack(this))) weapons.add((Weapon) item);
        String [] options = new String [weapons.size()];
        for (int i = 0; i < weapons.size(); i++) options[i] = ((Item) weapons.get(i)).getName();
        Creature [] creatures = Dandy.getPCs();
        String [] targetOptons = new String [creatures.length];
        for (int i = 0; i < creatures.length; i++) targetOptons[i] = creatures[i].getName();
        weapons.get((new Dice(1, options.length).roll()) - 1).attack(this, creatures[(new Dice(1, targetOptons.length).roll()) - 1]);
    }

    private void useConsumable (ArrayList <Consumable> consumables) {
        String [] options = new String [consumables.size()];
        for (int i = 0; i < consumables.size(); i++) options[i] = ((Item) consumables.get(i)).getName();
        Consumable consumable = consumables.get((new Dice(1, options.length).roll()) - 1);
        consumable.consume(this);
        equipment.remove((Item) consumable);
    }

    public boolean isUp () {
        return isAlive();
    }

    public boolean isAlive () {
        return hitPoints > 0;
    }

    public void takeDamage (int damage) {
        hitPoints -= damage;
        if (hitPoints <= 0) {
            System.out.printf("%s dies\n", name);
        }
    }

    public int getAttackBonus (int attackCount) {
        return baseAttackBonus;
    }

    public int getFortitude() {
        return fortitude;
    }

    public int getReflex() {
        return reflex;
    }

    public int getWill() {
        return will;
    }

    protected int getNaturalAC () {
        return naturalAC;
    }

    public Creature [] findCreatures () {
        return findCreatures(Dandy.getPCs());
    }
}