abstract class Action {
    protected Creature actor;

    public abstract void act ();
}