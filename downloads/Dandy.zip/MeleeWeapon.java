class MeleeWeapon extends Weapon {
    public MeleeWeapon (String name, int value, int weight,
    Dice smallDamage, Dice mediumDamage) {
        super(name, value, weight);
        this.smallDamage = smallDamage;
        this.mediumDamage = mediumDamage;
    }

    public void attack (Creature bearer, Creature target) {
        System.out.printf("%s attacks %s with their %s\n", bearer.getName(), target.getName(), name);
        (new MeleeWeaponAttack(bearer,
        target, bearer.isAtLeastMedium() ? mediumDamage : smallDamage, bearer.getStrMod())).act();
    }
}