class Armor extends Item {
    private int armorBonus;

    public Armor (String name, int value, int weight, int armorBonus) {
        super(name, value, weight);
        this.armorBonus = armorBonus;
    }

    public int getArmorBonus () {
        return armorBonus;
    }
}