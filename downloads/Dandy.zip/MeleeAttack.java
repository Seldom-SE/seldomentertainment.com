abstract class MeleeAttack extends Attack {
    public void act () {
        attack(actor.getAttackBonus(1) + actor.getStrMod() + actor.getSizeModifier(), target.getAC());
    }
}