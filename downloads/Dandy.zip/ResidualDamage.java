class ResidualDamage extends StatusEffect {
    private boolean waited;
    private boolean complete;
    private String name;
    private Dice damage;
    private int damageMod;
    private int saveMod;
    private int DC;

    public ResidualDamage (String name, Creature affected, Dice damage, int damageMod, int saveMod, int DC) {
        this.name = name;
        this.affected = affected;
        this.damage = damage;
        this.damageMod = damageMod;
        this.saveMod = saveMod;
        this.DC = DC;
    }

    public boolean save () {
        if ((new Dice(1, 20)).roll() + saveMod >= DC) {
            System.out.printf("%s successfully douses themself of %s\n", affected.getName(), name);
            return true;
        }
        System.out.printf("%s failed to prevent %s. After all, %s is inevitable.\n", affected.getName(), name, name);
        return false;
    }

    public void effect () {
        if (waited) {
            System.out.printf("%s gets hurt by %s\n", affected.getName(), name);
            affected.takeDamage(damage.roll() + damageMod);
            complete = true;
        } else {
            waited = true;
        }
    }

    public boolean isComplete () {
        return complete;
    }
}