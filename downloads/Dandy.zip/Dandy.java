import java.util.ArrayList;
import java.util.Scanner;

class Dandy {
    public static Scanner scanner = new Scanner(System.in);
    private static ArrayList <Creature> creatures;
    private static ArrayList <PlayerCharacter> PCs = new ArrayList <PlayerCharacter> ();

    public static void main (String [] args) {
        ArrayList <Race> races = new ArrayList <Race> ();
        races.add(new Race("human", Size.MEDIUM, 0, 0, 0, 0, 0, 0, 0));
        races.add(new Race("dwarf", Size.MEDIUM, 0, 0, 0, 2, 0, 0, -2));
        races.add(new Race("elf", Size.MEDIUM, 0, 0, 2, -2, 0, 0, 0));
        races.add(new Race("gnome", Size.SMALL, 0, -2, 0, 2, 0, 0, 0));
        races.add(new Race("half-elf", Size.MEDIUM, 0, 0, 0, 0, 0, 0, 0));
        races.add(new Race("half-orc", Size.SMALL, 0, 2, 0, 0, -2, 0, -2));
        races.add(new Race("halfling", Size.SMALL, 0, -2, 2, 0, 0, 0, 0));

        ArrayList <Class> classes = new ArrayList <Class> ();
        classes.add(new Class("barbarian", new Dice(1, 12), AttackBonusQuality.GOOD, SaveBonusQuality.GOOD, SaveBonusQuality.POOR, SaveBonusQuality.POOR));
        classes.add(new Class("bard", new Dice(1, 6), AttackBonusQuality.AVERAGE, SaveBonusQuality.POOR, SaveBonusQuality.GOOD, SaveBonusQuality.GOOD));
        classes.add(new Class("cleric", new Dice(1, 8), AttackBonusQuality.AVERAGE, SaveBonusQuality.GOOD, SaveBonusQuality.POOR, SaveBonusQuality.GOOD));
        classes.add(new Class("druid", new Dice(1, 8), AttackBonusQuality.AVERAGE, SaveBonusQuality.GOOD, SaveBonusQuality.POOR, SaveBonusQuality.GOOD));
        classes.add(new Class("fighter", new Dice(1, 10), AttackBonusQuality.GOOD, SaveBonusQuality.GOOD, SaveBonusQuality.POOR, SaveBonusQuality.POOR));
        classes.add(new Class("monk", new Dice(1, 8), AttackBonusQuality.AVERAGE, SaveBonusQuality.GOOD, SaveBonusQuality.GOOD, SaveBonusQuality.GOOD));
        classes.add(new Class("paladin", new Dice(1, 10), AttackBonusQuality.GOOD, SaveBonusQuality.GOOD, SaveBonusQuality.POOR, SaveBonusQuality.POOR));
        classes.add(new Class("ranger", new Dice(1, 8), AttackBonusQuality.GOOD, SaveBonusQuality.GOOD, SaveBonusQuality.GOOD, SaveBonusQuality.POOR));
        classes.add(new Class("rogue", new Dice(1, 6), AttackBonusQuality.AVERAGE, SaveBonusQuality.POOR, SaveBonusQuality.GOOD, SaveBonusQuality.POOR));
        classes.add(new Class("sorcerer", new Dice(1, 4), AttackBonusQuality.POOR, SaveBonusQuality.POOR, SaveBonusQuality.POOR, SaveBonusQuality.GOOD));
        classes.add(new Class("wizard", new Dice(1, 4), AttackBonusQuality.POOR, SaveBonusQuality.POOR, SaveBonusQuality.POOR, SaveBonusQuality.GOOD));

        Item crossbowBolt = new Item("crossbow bolt", 10, 80);
        Item slingBullet = new Item("sling bullet", 1, 50);
        Item arrow = new Item("arrow", 5, 2);
        ArrayList <Item> items = new ArrayList <Item> ();
        items.add(new Acid());
        items.add(new AlchemistsFire());
        items.add(new MeleeWeapon("gauntlet", 200, 10, new Dice(1, 2), new Dice(1, 3)));
        items.add(new MeleeWeapon("dagger", 200, 10, new Dice(1, 3), new Dice(1, 4)));
        items.add(new MeleeWeapon("sickle", 600, 20, new Dice(1, 4), new Dice(1, 6)));
        items.add(new MeleeWeapon("club", 0, 30, new Dice(1, 4), new Dice(1, 6)));
        items.add(new MeleeWeapon("morningstar", 800, 30, new Dice(1, 4), new Dice(1, 6)));
        items.add(new MeleeWeapon("quarterstaff", 0, 40, new Dice(1, 4), new Dice(1, 6)));
        items.add(new MeleeWeapon("spear", 200, 60, new Dice(1, 6), new Dice(1, 8)));
        items.add(new MeleeWeapon("handaxe", 600, 30, new Dice(1, 4), new Dice(1, 6)));
        items.add(new MeleeWeapon("short sword", 1000, 20, new Dice(1, 4), new Dice(1, 6)));
        items.add(new MeleeWeapon("battleaxe", 1000, 60, new Dice(1, 6), new Dice(1, 8)));
        items.add(new MeleeWeapon("flail", 800, 50, new Dice(1, 6), new Dice(1, 8)));
        items.add(new MeleeWeapon("longsword", 1500, 40, new Dice(1, 6), new Dice(1, 8)));
        items.add(new MeleeWeapon("rapier", 2000, 20, new Dice(1, 4), new Dice(1, 6)));
        items.add(new MeleeWeapon("scimitar", 1500, 40, new Dice(1, 4), new Dice(1, 6)));
        items.add(new MeleeWeapon("trident", 1500, 40, new Dice(1, 6), new Dice(1, 8)));
        items.add(new MeleeWeapon("warhammer", 1200, 50, new Dice(1, 6), new Dice(1, 8)));
        items.add(new MeleeWeapon("glaive", 800, 100, new Dice(1, 8), new Dice(1, 10)));
        items.add(new MeleeWeapon("greataxe", 2000, 80, new Dice(1, 10), new Dice(1, 12)));
        items.add(new MeleeWeapon("greatclub", 500, 80, new Dice(1, 8), new Dice(1, 10)));
        items.add(new MeleeWeapon("greatsword", 5000, 80, new Dice(1, 8), new Dice(1, 10)));
        items.add(new MeleeWeapon("halberd", 1000, 120, new Dice(1, 8), new Dice(1, 10)));
        items.add(new MeleeWeapon("lance", 1000, 100, new Dice(1, 6), new Dice(1, 8)));
        items.add(new MeleeWeapon("scythe", 1800, 100, new Dice(1, 6), new Dice(2, 4)));
        items.add(new MeleeWeapon("whip", 100, 20, new Dice(1, 2), new Dice(1, 3)));
        items.add(new RangedWeapon("crossbow", 5000, 80, new Dice(1, 8), new Dice(1, 10), crossbowBolt));
        items.add(new RangedWeapon("sling", 0, 0, new Dice(1, 3), new Dice(1, 4), slingBullet));
        items.add(new RangedWeapon("longbow", 7500, 30, new Dice(1, 6), new Dice(1, 8), arrow));
        items.add(new RangedWeapon("shortbow", 3000, 20, new Dice(1, 4), new Dice(1, 6), arrow));
        items.add(crossbowBolt);
        items.add(slingBullet);
        items.add(arrow);
        items.add(new Armor("padded", 500, 100, 1));
        items.add(new Armor("leather", 1000, 150, 2));
        items.add(new Armor("hide", 1500, 250, 3));
        items.add(new Armor("scale mail", 5000, 300, 4));
        items.add(new Armor("chainmail", 15000, 400, 5));
        items.add(new Armor("splint mail", 20000, 450, 6));
        items.add(new Armor("half-plate", 60000, 500, 7));
        items.add(new Armor("full plate", 150000, 500, 8));
        items.add(new Shield("light shield", 900, 50, 1));
        items.add(new Shield("heavy shield", 2000, 150, 2));

        int PCCount = Prompt.promptIntRange("How many characters are in your party?", 1, 12);
        ArrayList <Monster> monsters = new ArrayList <Monster> ();
        for (int i = 0; i < PCCount; i++) PCs.add(new PlayerCharacter(races, classes, items));

        int round = 1;
        for (; !PCs.isEmpty(); round++) {
            System.out.printf("\nROUND %d\n\n", round);

            creatures = new ArrayList <Creature> ();
            monsters = new ArrayList <Monster> ();

            for (int i = 0; i < round; i++) {
                Monster monster = new Monster("monster " + (i + 1), races.get((new Dice(1, races.size()).roll() - 1)), new Dice(round, round), (new Dice(1, round)).roll(),
                    (new Dice(3, 6)).roll() + round, (new Dice(3, 6)).roll() + round, (new Dice(3, 6)).roll() + round, (new Dice(3, 6)).roll() + round, (new Dice(3, 6)).roll() + round, (new Dice(3, 6)).roll() + round,
                    (new Dice(1, round)).roll(), (new Dice(1, round)).roll(), (new Dice(1, round)).roll(), (new Dice(1, round)).roll(), (new Dice(1, round)).roll());
                for (int j = 0; j < round; j++) {
                    monster.get(items.get((new Dice(1, items.size()).roll() - 1)));
                }
                monsters.add(monster);
            }

            int min = 0;
            int max = 0;
            int [] PCInitiative = new int [PCs.size()];
            int [] monsterInitiative = new int [monsters.size()];
            for (int i = 0; i < PCInitiative.length; i++) {
                PCInitiative[i] = (new Dice(1, 20)).roll() + PCs.get(i).getDexMod();
                min = Math.min(PCInitiative[i], min);
                max = Math.max(PCInitiative[i], max);
            }
            for (int i = 0; i < monsterInitiative.length; i++) {
                monsterInitiative[i] = (new Dice(1, 20)).roll() + monsters.get(i).getDexMod();
                min = Math.min(monsterInitiative[i], min);
                max = Math.max(monsterInitiative[i], max);
            }
            
            for (int i = max; i >= min; i--) {
                for (int j = 0; j < PCInitiative.length; j++) if (i == PCInitiative[j]) creatures.add(PCs.get(j));
                for (int j = 0; j < monsterInitiative.length; j++) if (i == monsterInitiative[j]) creatures.add(monsters.get(j));
            }

            boolean PCsDead;
            while (true) {
                for (int i = 0; i < creatures.size(); i++) {
                    PCsDead = true;
                    for (PlayerCharacter PC : PCs) PCsDead &= !PC.isAlive();
                    if (PCsDead) break;
                    boolean monstersDead = true;
                    for (Monster monster : monsters) monstersDead &= !monster.isAlive();
                    if (monstersDead) break;
                    creatures.get(i).doStatusEffects();
                    if (!creatures.get(i).isUp()) continue;
                    System.out.printf("%s's turn \n", creatures.get(i).getName());
                    creatures.get(i).takeTurn();
                }
                PCsDead = true;
                for (PlayerCharacter PC : PCs) PCsDead &= !PC.isAlive();
                if (PCsDead) break;
                boolean monstersDead = true;
                for (Monster monster : monsters) monstersDead &= !monster.isAlive();
                if (monstersDead) break;
            }
            for (Creature creature : creatures) if (creature instanceof PlayerCharacter && !creature.isAlive()) PCs.remove((PlayerCharacter) creature);
            monsters = new ArrayList <Monster> ();
        }

        System.out.printf("\n\nGAME OVER\n");
        System.out.printf("SCORE: %d\n", round - 1);
    }

    public static Creature [] getCreatures () {
        return creatures.toArray(new Creature [0]);
    }

    public static Creature [] getPCs () {
        return PCs.toArray(new Creature [0]);
    }
}