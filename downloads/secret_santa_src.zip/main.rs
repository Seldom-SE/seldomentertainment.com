// secret_santa by Seldom 2019
// for brakenym

extern crate rand;

use std::io;
use rand::Rng;

struct Gift<'a> {
    santa: &'a String,
    recipient: &'a String,
}

impl std::fmt::Display for Gift<'_> {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{} -> {}", self.santa, self.recipient)
    }
}

fn main() {
    welcome();
    let players = get_players();
    let gifts = gen_gifts(copy_ref(&players));
    print(gifts);
}

fn welcome() {
    println!("secret_santa by sage 2019");
    println!("for Seldom");
    println!("Enter all of the players' names");
    println!("Enter an empty line to end the list");
}

fn get_players() -> Vec<String> {
    let mut players: Vec<String> = Vec::new();
    let mut input = String::new();

    loop {
        match io::stdin().read_line(&mut input) {
            Ok(_ok) => {},
            Err(e) => println!("Error taking input: {}", e),
        }
        if input.trim() == "" {break;}
        players.push(input.trim().to_string());
        input = String::new();
    }

    players
}

fn copy_ref<T>(vec: &Vec<T>) -> Vec<&T> {
    let mut copy: Vec<&T> = Vec::new();

    for el in vec.iter() {
        copy.push(el);
    }

    copy
}

fn gen_gifts(mut players: Vec<&String>) -> Vec<Gift> {
    let mut gifts: Vec<Gift> = Vec::new();
    let mut current_i = rand::thread_rng().gen_range(0, players.len());
    let first = players[current_i];
    let last: &String;

    loop {
        let current = players[current_i];
        players.remove(current_i);
        if players.len() == 0 {
            last = current;
            break;
        }
        let next_i = rand::thread_rng().gen_range(0, players.len());
        gifts.push(Gift {
            santa: current,
            recipient: players[next_i],
        });
        current_i = next_i;
    }

    gifts.push(Gift {
        santa: last,
        recipient: first,
    });
    gifts
}

fn print<T: std::fmt::Display>(vec: Vec<T>) {
    for el in vec {
        println!("{}", el);
    }
}
