# dodger.py (c) sage 2018
# For Vitridax. Happy birthday.

# Everything in this game is mine except for the sound effects which are by Juhani Junkala
# See the variables below to customize your experience

import pygame
import math
import random

pygame.init()

TAU = 6.283185307179586
# 0, TAU / 8, TAU / 4, 3 * TAU / 8, etc.
def ANGLES_FN():
    angles = []
    for i in range(0, 9):
        angles.append(TAU / 8 * i)
    angles.append(-1)
    return angles
ANGLES = ANGLES_FN()

BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
PG_BLACK = pygame.Color(0, 0, 0)

# Window resolution. Adjust as is fit. It is 1366, 768 by default.
WINDOW_X = 1366
WINDOW_Y = 768
WINDOW_COLOR = BLACK

# Usually 60
FPS = 60

PLAYER_X = WINDOW_X / 2
PLAYER_Y = WINDOW_Y / 2
PLAYER_SIZE = 128
PLAYER_OFFSET = PLAYER_SIZE / 2
# 6 by default
PLAYER_SPEED = 6
# 64 by default
PLAYER_SPEED_DASH = 64
# The program uses these speeds with the directional ennumeration as an index. It changes position by speed indexed by direction.
COS = 0
NEG_SIN = 1
def SPEED_FN(speed, function):
    speed_dimension = []
    for angle in ANGLES[0:8]:
        if function == 0:
            speed_dimension.append(speed * math.cos(angle))
        else:
            speed_dimension.append(speed * -math.sin(angle))
    speed_dimension.append(0)
    return speed_dimension
# In a curve: 1, sqrt 2, 0, -sqrt 2, -1, -sqrt 2, 0, sqrt 2. Last is 0 as a default
PLAYER_SPEED_X = SPEED_FN(PLAYER_SPEED, COS)
# 0, -sqrt 2, -1, -sqrt 2, 0, sqrt 2, 1, sqrt 2, 0
PLAYER_SPEED_Y = SPEED_FN(PLAYER_SPEED, NEG_SIN)
# Works like PLAYER_SPEED_X, but faster
PLAYER_SPEED_DASH_X = SPEED_FN(PLAYER_SPEED_DASH, COS)
# Like speed y, you get the idea
PLAYER_SPEED_DASH_Y = SPEED_FN(PLAYER_SPEED_DASH, NEG_SIN)
PLAYER_DASH_FRAMES = 8
PLAYER_DASH_COOLDOWN = 32
PLAYER_COLLISION_COOLDOWN_MULT = 2
PLAYER_HIT_COOLDOWN_MULT = 2
PLAYER_COLOR = WHITE

PLAYER_WINDOW_EDGE = PLAYER_SIZE / 2
PLAYER_WINDOW_EDGE_X = WINDOW_X - PLAYER_WINDOW_EDGE
PLAYER_WINDOW_EDGE_Y = WINDOW_Y - PLAYER_WINDOW_EDGE

# Ennumeration of acceleration type
CARDINAL = 0
DIAGONAL = 1
REALISTIC = 2

ENEMY_SIZE = 96
ENEMY_OFFSET = ENEMY_SIZE / 2
# Best variable to adjust to adjust difficulty. Default is 0.25.
ENEMY_ACCELERATION = 0.75
# If it accelerates cardinally, it accelerates in the nearest cardinal direction to the player
# When the enemy accelerates diagonally, it accelerates in the diagonal of the quadrant the player is in relative to the enemy
# If it accelerates realistically, it accelerates directly towards the player, which is harder, but more predictable
# Takes CARDINAL, DIAGONAL or REALISTIC. REALISTIC is default.
ENEMY_ACCELERATION_TYPE = REALISTIC
ENEMY_COLOR = WHITE

ENEMY_1_X = 0 + ENEMY_SIZE / 2
ENEMY_1_Y = 0 + ENEMY_SIZE / 2

ENEMY_2_X = WINDOW_X - ENEMY_SIZE / 2
ENEMY_2_Y = WINDOW_Y - ENEMY_SIZE / 2

ENEMY_WINDOW_EDGE = ENEMY_SIZE / 2
ENEMY_WINDOW_EDGE_X = WINDOW_X - ENEMY_WINDOW_EDGE
ENEMY_WINDOW_EDGE_Y = WINDOW_Y - ENEMY_WINDOW_EDGE

HITBOX_SIZE = PLAYER_SIZE / 2 + ENEMY_SIZE / 2

# Collision Particles are kind of ugly, but this option is here in case you want them
SHOW_COLLISION_PARTICLES = False

COLLISION_PARTICLE_COLOR = WHITE
COLLISION_PARTICLE_SPREAD = 1
COLLISION_PARTICLE_VELOCITY_MAX = 32
COLLISION_PARTICLE_ACCELERATION = 0.125
COLLISION_PARTICLE_SIZE = 16
COLLISION_PARTICLE_OFFSET = COLLISION_PARTICLE_SIZE / 2
COLLISION_PARTICLE_WALL_AMOUNT = 4

COLLISION_PARTICLE_WINDOW_EDGE = COLLISION_PARTICLE_OFFSET
COLLISION_PARTICLE_WINDOW_EDGE_X = WINDOW_X - COLLISION_PARTICLE_WINDOW_EDGE
COLLISION_PARTICLE_WINDOW_EDGE_Y = WINDOW_Y - COLLISION_PARTICLE_WINDOW_EDGE

TRAIL_PARTICLE_COLOR = WHITE
TRAIL_PARTICLE_RANDOM_DECAY_NUM = 32
TRAIL_PARTICLE_JITTER = 8
ENEMY_TRAIL_TIMER = 8

# Dash particles are also quite ugly
SHOW_DASH_PARTICLES = False

DASH_PARTICLE_COLOR = WHITE
DASH_PARTICLE_COLOR_INTERIOR = BLACK
DASH_PARTICLE_LIFE = 8
DASH_PARTICLE_SIZE = PLAYER_SPEED_DASH
DASH_PARTICLE_SIZE_INTERIOR = DASH_PARTICLE_SIZE * 7 / 8
DASH_PARTICLE_OFFSET = DASH_PARTICLE_SIZE / 2
DASH_PARTICLE_OFFSET_INTERIOR = DASH_PARTICLE_SIZE_INTERIOR / 2

SCREENSHAKE_MULT = 1.5

INTENSITY_INC = 128
INTENSITY_DEC = -16

REFRACTION_POSITION_RATIO_CAP = 0.0625
INTEGER_MULT = 100000

# Trail particle sizes
LARGE_SIZE = 32
MEDIUM_SIZE = 16
SMALL_SIZE = 8

# Keybindings. Adjust if necessary.
KEY_UP = pygame.K_w
KEY_LEFT = pygame.K_a
KEY_DOWN = pygame.K_s
KEY_RIGHT = pygame.K_d
KEY_DASH = pygame.K_SPACE

# Player states
CONTROL = 0
DASH = 1

# An enumeration of directions. Used as an index for player speed, etc.
MIDDLE = -1
RIGHT = 0
UP_RIGHT = 1
UP = 2
UP_LEFT = 3
LEFT = 4
DOWN_LEFT = 5
DOWN = 6
DOWN_RIGHT = 7

# Trail particle size enumeration
LARGE = 0
MEDIUM = 1
SMALL = 2

# Sound effects. These aren't mine. Credits are at the top of the program.
HIT_SOUND = pygame.mixer.Sound("sfx_exp_shortest_hard3.wav")
WALL_SOUND = pygame.mixer.Sound("sfx_sounds_impact1.wav")
DASH_SOUND = pygame.mixer.Sound("sfx_sounds_powerup17.wav")
#SNAP_SOUND = pygame.mixer.Sound("sfx_sounds_interaction21.wav")

class Player:
    def __init__(self):
        self.x = PLAYER_X
        self.y = PLAYER_Y
        # Either under control or dashing
        self.state = CONTROL
        # Direction used when dashing
        self.direction = MIDDLE
        # When this timer times out while dashing, it switches to being under control. When it does while under control, the dash ability has cooled down.
        self.state_timer = 0

    def move(self, direction, speed_x, speed_y):
        self.x += speed_x[direction]
        self.y += speed_y[direction]

    # If the player is stuck in a wall, it forces itself in the opposite direction. Used to force that and to cancel a dash when the player hits a wall.
    def detect_edge_collisions(self, up, left, down, right):
        force_right, force_left, collision_x = self.check_edge_bounds(self.x, PLAYER_WINDOW_EDGE, PLAYER_WINDOW_EDGE_X)
        force_down, force_up, collision_y = self.check_edge_bounds(self.y, PLAYER_WINDOW_EDGE, PLAYER_WINDOW_EDGE_Y)

        up = up or force_up
        left = left or force_left
        down = down or force_down
        right = right or force_right
        collision = collision_x or collision_y

        return up, left, down, right, collision

    def check_edge_bounds(self, position, min, max):
        under = False
        above = False
        collision = False
        if position < min:
            under = True
            collision = True
        elif position > max:
            above = True
            collision = True
        return under, above, collision

    # Functions as two timers: dash timer and dash cooldown
    def update_state_timer(self):
        if self.state == CONTROL:
            if self.state_timer > 0:
                self.state_timer -= 1
        if self.state == DASH:
            if self.state_timer > 0:
                self.state_timer -= 1
                if self.state_timer <= 0:
                    self.state = CONTROL
                    self.state_timer = PLAYER_DASH_COOLDOWN

class Enemy:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.velocity_x = 0
        self.velocity_y = 0
        # Adds another trail particle when it times out
        self.trail_timer = ENEMY_TRAIL_TIMER

    def move(self):
        self.x += self.velocity_x
        self.y += self.velocity_y

    def accelerate_cardinally(self, player_x, player_y):
        if abs(self.x - player_x) > abs(self.y - player_y):
            if self.x > player_x:
                self.velocity_x -= ENEMY_ACCELERATION
            elif self.x < player_x:
                self.velocity_x += ENEMY_ACCELERATION
        elif (self.x - player_x) < abs(self.y - player_y):
            if self.y > player_y:
                self.velocity_y -= ENEMY_ACCELERATION
            elif self.y < player_y:
                self.velocity_y += ENEMY_ACCELERATION

    def accelerate_diagonally(self, player_x, player_y):
        self.velocity_x += self.accelerate_along_axis(self.x, player_x)
        self.velocity_y += self.accelerate_along_axis(self.y, player_y)

    def accelerate_along_axis(self, enemy_position, player_position):
        acceleration = 0
        if enemy_position > player_position:
            acceleration = -ENEMY_ACCELERATION
        elif enemy_position < player_position:
            acceleration = ENEMY_ACCELERATION
        
        return acceleration

    # Trigonometry finds direction of player
    def accelerate_realistically(self, player_x, player_y):
        arctangent = math.atan2(player_y - self.y, player_x - self.x)
        self.velocity_x += ENEMY_ACCELERATION * math.cos(arctangent)
        self.velocity_y += ENEMY_ACCELERATION * math.sin(arctangent)

    # When an enemy hits a wall, its velocity in that direction is inverted and halved. Halving it prevents it from gaining an indefinite velocity over time.
    def detect_collisions(self, player_x, player_y, player_state):
        self.velocity_x = self.detect_axis_collision(self.x, ENEMY_WINDOW_EDGE, ENEMY_WINDOW_EDGE_X, self.velocity_x)
        self.velocity_y = self.detect_axis_collision(self.y, ENEMY_WINDOW_EDGE, ENEMY_WINDOW_EDGE_Y, self.velocity_y)

        hit = False
        if abs(player_x - self.x) < HITBOX_SIZE and abs(player_y - self.y) < HITBOX_SIZE and player_state != DASH:
            hit = True

        return hit

    def detect_axis_collision(self, position, min, max, velocity):
        if position < min:
            velocity = abs(velocity) / 2
        elif position > max:
            velocity = -abs(velocity) / 2

        return velocity

    def update_trail_timer(self):
        spawn = False
        self.trail_timer -= 1
        if self.trail_timer == 0:
            self.trail_timer = ENEMY_TRAIL_TIMER
            spawn = True
        return spawn

class Collision_Particle:
    def __init__(self, x, y, velocity, angle):
        self.x = x
        self.y = y
        self.velocity = velocity
        self.angle = angle
        self.destroy = False

    def move(self):
        self.x += self.velocity * math.cos(self.angle)
        self.y += self.velocity * math.sin(self.angle)

    def accelerate(self):
        self.velocity -= COLLISION_PARTICLE_ACCELERATION
        if self.velocity <= 0:
            self.destroy = True

    def detect_collisions(self):
        if self.x < COLLISION_PARTICLE_WINDOW_EDGE:
            self.angle = TAU / 2 - self.angle
        elif self.x > COLLISION_PARTICLE_WINDOW_EDGE_X:
            self.angle = TAU / 2 - self.angle
        if self.y < COLLISION_PARTICLE_WINDOW_EDGE:
            self.angle = -self.angle
        elif self.y > COLLISION_PARTICLE_WINDOW_EDGE_Y:
            self.angle = -self.angle

class Trail_Particle:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.state = LARGE
        self.size = LARGE_SIZE
        self.offset = self.size / 2

    def drift(self):
        drift = random.randint(0,3)
        if drift == 0:
            self.x += TRAIL_PARTICLE_JITTER
        elif drift == 1:
            self.x -= TRAIL_PARTICLE_JITTER
        elif drift == 2:
            self.y += TRAIL_PARTICLE_JITTER
        elif drift == 3:
            self.y -= TRAIL_PARTICLE_JITTER

    # This function randomly decreases particle size and flags it for destruction when it decays past the smallest size
    # The particle is destroyed outside of this function
    def decay(self):
        destroy = False
        if random.randint(0, TRAIL_PARTICLE_RANDOM_DECAY_NUM) == 0:
            if self.state == LARGE:
                self.state = MEDIUM
                self.size = MEDIUM_SIZE
            elif self.state == MEDIUM:
                self.state = SMALL
                self.size = SMALL_SIZE
            elif self.state == SMALL:
                destroy = True
        self.offset = self.size / 2
        return destroy

class Dash_Particle:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.life = DASH_PARTICLE_LIFE

    def decay(self):
        self.life -=1
        destroy = False
        if self.life <= 0:
            destroy = True
        return destroy

class Rectangle:
    def __init__(self, x, y, width, height, color):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.color = color

    def move(self, x, y):
        self.x += x
        self.y += y

    def refract(self, refraction):
        rectangle_1 = Rectangle(self.x + refraction.x, self.y + refraction.y, self.width, self.height, (refraction.red, refraction.green, refraction.blue))
        rectangle_2 = Rectangle(self.x - refraction.x, self.y - refraction.y, self.width, self.height, (255 - refraction.red, 255 - refraction.green, 255 - refraction.blue))
        return rectangle_1, rectangle_2

# Screenshake that adds intensity when there is collision or dashing
# shake_x and shake_y are general rendering offsets in the form of a list
# Each element of the list represents a frame and each frame, the previous frame's element is deleted
# When screenshake is added, the soonest elements are changed
class Screenshake:
    def __init__(self, shake_x, shake_y):
        self.shake_x = shake_x
        self.shake_y = shake_y

    def do_collision_shake(self, direction):
        self.add_shake(SCREENSHAKE_WALL_COLLISION[direction].shake_x, SCREENSHAKE_WALL_COLLISION[direction].shake_y)

    def do_dash_shake(self, direction):
        self.add_shake(SCREENSHAKE_DASH[direction].shake_x, SCREENSHAKE_DASH[direction].shake_y)

    def add_shake(self, x, y):
        self.shake_x = self.add_dimension(self.shake_x, x)
        self.shake_y = self.add_dimension(self.shake_y, y)

    # If the added screenshake is longer in length, a different algorithm is used to start addending values
    def add_dimension(self, dimension, addend):
        if len(dimension) >= len(addend):
            for i in range(0, len(addend)):
                dimension[i] += addend[i]
        else:
            for i in range(0, len(dimension)):
                dimension[i] += addend[i]
            for i in range(len(dimension), len(addend)):
                dimension.append(addend[i])
        
        return dimension

    # Advance the frame
    def scroll(self):
        self.shake_x = self.scroll_axis(self.shake_x)
        self.shake_y = self.scroll_axis(self.shake_y)

    def scroll_axis(self, axis):
        if len(axis) == 1:
            axis = [0]
        else:
            axis.pop(0)
        
        return axis

# The actual screenshake values

def DIMENSION_FN(start, length, alternating, divisor_exponent):
    dimension = [start]
    for i in range(0, length):
        dimension.append(dimension[-1] / 2 ** divisor_exponent)
        if alternating:
            dimension[-1] = -dimension[-1]
    return dimension

SCREENSHAKE_ENEMY_HIT = Screenshake(DIMENSION_FN(256, 17, True, 0.5), DIMENSION_FN(-6, 32, True, 0))

SCREENSHAKE_DASH_RIGHT = Screenshake(DIMENSION_FN(-64, 13, False, 0.5), [0])
SCREENSHAKE_DASH_UP_RIGHT = Screenshake(DIMENSION_FN(-64, 13, False, 0.5), DIMENSION_FN(64, 13, False, 0.5))
SCREENSHAKE_DASH_UP = Screenshake([0], DIMENSION_FN(64, 13, False, 0.5))
SCREENSHAKE_DASH_UP_LEFT = Screenshake(DIMENSION_FN(64, 13, False, 0.5), DIMENSION_FN(64, 13, False, 0.5))
SCREENSHAKE_DASH_LEFT = Screenshake(DIMENSION_FN(64, 13, False, 0.5), [0])
SCREENSHAKE_DASH_DOWN_LEFT = Screenshake(DIMENSION_FN(64, 13, False, 0.5), DIMENSION_FN(-64, 13, False, 0.5))
SCREENSHAKE_DASH_DOWN = Screenshake([0], DIMENSION_FN(-64, 13, False, 0.5))
SCREENSHAKE_DASH_DOWN_RIGHT = Screenshake(DIMENSION_FN(-64, 13, False, 0.5), DIMENSION_FN(-64, 13, False, 0.5))

SCREENSHAKE_DASH = [SCREENSHAKE_DASH_RIGHT, SCREENSHAKE_DASH_UP_RIGHT, SCREENSHAKE_DASH_UP, SCREENSHAKE_DASH_UP_LEFT, SCREENSHAKE_DASH_LEFT, SCREENSHAKE_DASH_DOWN_LEFT, SCREENSHAKE_DASH_DOWN, SCREENSHAKE_DASH_DOWN_RIGHT]

SCREENSHAKE_WALL_COLLISION_RIGHT = Screenshake(DIMENSION_FN(-256, 9, False, 1), DIMENSION_FN(3, 12, True, 0))
SCREENSHAKE_WALL_COLLISION_UP_RIGHT = Screenshake(DIMENSION_FN(-256, 9, False, 1), DIMENSION_FN(256, 9, False, 1))
SCREENSHAKE_WALL_COLLISION_UP = Screenshake(DIMENSION_FN(3, 12, True, 0), DIMENSION_FN(256, 9, False, 1))
SCREENSHAKE_WALL_COLLISION_UP_LEFT = Screenshake(DIMENSION_FN(256, 9, False, 1), DIMENSION_FN(256, 9, False, 1))
SCREENSHAKE_WALL_COLLISION_LEFT = Screenshake(DIMENSION_FN(256, 9, False, 1), DIMENSION_FN(3, 12, True, 0))
SCREENSHAKE_WALL_COLLISION_DOWN_LEFT = Screenshake(DIMENSION_FN(256, 9, False, 1), DIMENSION_FN(-256, 9, False, 1))
SCREENSHAKE_WALL_COLLISION_DOWN = Screenshake(DIMENSION_FN(3, 12, True, 0), DIMENSION_FN(-256, 9, False, 1))
SCREENSHAKE_WALL_COLLISION_DOWN_RIGHT = Screenshake(DIMENSION_FN(-256, 9, False, 1), DIMENSION_FN(-256, 9, False, 1))

SCREENSHAKE_WALL_COLLISION = [SCREENSHAKE_WALL_COLLISION_RIGHT, SCREENSHAKE_WALL_COLLISION_UP_RIGHT, SCREENSHAKE_WALL_COLLISION_UP, SCREENSHAKE_WALL_COLLISION_UP_LEFT, SCREENSHAKE_WALL_COLLISION_LEFT, SCREENSHAKE_WALL_COLLISION_DOWN_LEFT, SCREENSHAKE_WALL_COLLISION_DOWN, SCREENSHAKE_WALL_COLLISION_DOWN_RIGHT]

SCREENSHAKE_SNAP = Screenshake(DIMENSION_FN(64, 4, True, 0.25), [0])

class Refraction:
    def __init__(self):
        self.x = 0
        self.y = 0
        self.red = 0
        self.green = 0
        self.blue = 0
        self.randomized = False
        self.x_ratio = 0
        self.y_ratio = 0
        self.red_ratio = 0
        self.green_ratio = 0
        self.blue_ratio = 0

    def update_color(self, intensity):
        if intensity == 0 and self.randomized == False:
            angle = random.randint(0, INTEGER_MULT) * TAU / INTEGER_MULT
            self.x_ratio = math.cos(angle) * REFRACTION_POSITION_RATIO_CAP
            self.y_ratio = math.sin(angle) * REFRACTION_POSITION_RATIO_CAP
            self.red_ratio = random.randint(0, 10) / 10
            self.green_ratio = random.randint(0, 10) / 10
            self.blue_ratio = random.randint(0, 10) / 10
            self.randomized = True

        if intensity > 0:
            self.randomized = False

        color_intensity = intensity
        if color_intensity > 255:
            color_intensity = 255

        self.x = intensity * self.x_ratio
        self.y = intensity * self.y_ratio
        self.red = color_intensity * self.red_ratio
        self.green = color_intensity * self.green_ratio
        self.blue = color_intensity * self.blue_ratio

def main():
    screen = pygame.display.set_mode((WINDOW_X, WINDOW_Y))
    clock = pygame.time.Clock()
    pygame.display.set_caption("Dodger")

    running = True

    player = Player()
    enemies = [Enemy(ENEMY_1_X, ENEMY_1_Y), Enemy(ENEMY_2_X, ENEMY_2_Y)]

    collision_particles = []
    trail_particles = []
    dash_particles = []

    screenshake = Screenshake([0], [0])
    refraction = Refraction()
    intensity = 0

    while running:
        running, dash = check_events()

        # For when the player is not dashing
        update_player_control(player, screenshake, dash)
        update_player_dash(player, collision_particles, dash_particles, screenshake)

        accelerate_enemies(enemies, player.x, player.y)
        move_enemies(enemies)
        # Collisions with the screen and player
        intensity = detect_enemy_collisions(player, enemies, collision_particles, screenshake, intensity)

        # Update the state machine
        player.update_state_timer()
        intensity = update_intensity(intensity, screenshake)
        update_collision_particles(collision_particles)
        # Jitter and decay
        update_trails(trail_particles, enemies)
        update_dash_particles(dash_particles)
        refraction.update_color(intensity)

        screen.fill(WINDOW_COLOR)
        render(screen, player, enemies, collision_particles, trail_particles, dash_particles, screenshake, refraction)
        # Advance the offset
        screenshake.scroll()
        pygame.display.flip()

        clock.tick(FPS)

def check_events():
    running = True
    dash = False

    for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN and event.key == KEY_DASH:
                dash = True

    return running, dash

def update_player_control(player, screenshake, dash):
    if player.state == CONTROL:
        up, left, down, right = get_key_presses()
        # Whether a collision with the wall has been detected is discarded
        up, left, down, right, trash = player.detect_edge_collisions(up, left, down, right)
        direction = get_direction(up, left, down, right)
        if dash and player.state_timer <= 0 and direction != MIDDLE:
            # The player has started dashing
            player.state = DASH
            player.state_timer = PLAYER_DASH_FRAMES
            player.direction = direction
            screenshake.do_dash_shake(direction)
            DASH_SOUND.play()
        else:
            player.move(direction, PLAYER_SPEED_X, PLAYER_SPEED_Y)

def update_player_dash(player, collision_particles, dash_particles, screenshake):
    if player.state == DASH:
        player.move(player.direction, PLAYER_SPEED_DASH_X, PLAYER_SPEED_DASH_Y)
        # The direction the player should be forced is discarded
        dash_particles.append(Dash_Particle(player.x, player.y))
        trash_0, trash_1, trash_2, trash_3, collision = player.detect_edge_collisions(False, False, False, False)
        if collision:
            # The player has dashed into a wall
            player.state_timer = PLAYER_DASH_COOLDOWN * PLAYER_COLLISION_COOLDOWN_MULT
            player.state = CONTROL
            add_collision_particles(collision_particles, player.x, player.y, player.direction)
            screenshake.do_collision_shake(player.direction)
            WALL_SOUND.play()

def get_key_presses():
    pressed = pygame.key.get_pressed()

    up = pressed[KEY_UP]
    left = pressed[KEY_LEFT]
    down = pressed[KEY_DOWN]
    right = pressed[KEY_RIGHT]

    return up, left, down, right

# Convert the binary direction to the annumerated direction. Xor, so oppisite directions cancel.
def get_direction(up, left, down, right):
    direction = MIDDLE

    if up and not(down):
        if left and not(right):
            direction = UP_LEFT
        elif not(left) and right:
            direction = UP_RIGHT
        else:
            direction = UP
    elif not(up) and down:
        if left and not(right):
            direction = DOWN_LEFT
        elif not(left) and right:
            direction = DOWN_RIGHT
        else:
            direction = DOWN
    else:
        if left and not(right):
            direction = LEFT
        elif not(left) and right:
            direction = RIGHT

    return direction

def accelerate_enemies(enemies, player_x, player_y):
    if ENEMY_ACCELERATION_TYPE == CARDINAL:
        for enemy in enemies:
            enemy.accelerate_cardinally(player_x, player_y)
    elif ENEMY_ACCELERATION_TYPE == DIAGONAL:
        for enemy in enemies:
            enemy.accelerate_diagonally(player_x, player_y)
    elif ENEMY_ACCELERATION_TYPE == REALISTIC:
        for enemy in enemies:
            enemy.accelerate_realistically(player_x, player_y)

def move_enemies(enemies):
    for enemy in enemies:
        enemy.move()

def detect_enemy_collisions(player, enemies, collision_particles, screenshake, intensity):
    for enemy in enemies:
        hit = enemy.detect_collisions(player.x, player.y, player.state)
        if hit:
            player.state_timer = PLAYER_DASH_COOLDOWN * PLAYER_HIT_COOLDOWN_MULT
            add_collision_particles(collision_particles, player.x, player.y, MIDDLE)
            screenshake.add_shake(SCREENSHAKE_ENEMY_HIT.shake_x, SCREENSHAKE_ENEMY_HIT.shake_y)
            intensity += INTENSITY_INC
            HIT_SOUND.play()
    return intensity

def update_intensity(intensity, screenshake):
    positive = False
    if intensity > 0:
        positive = True

    intensity += INTENSITY_DEC
    if intensity <= 0:
        intensity = 0
        if positive == True:
            #SNAP_SOUND.play()
            screenshake.add_shake(SCREENSHAKE_SNAP.shake_x, SCREENSHAKE_SNAP.shake_y)

    return intensity

def add_collision_particles(collision_particles, x, y, direction):
    base_angle = ANGLES[direction]
    if base_angle == -1:
        base_angle = 0
        spread = 3.1
        amount = 1
    else:
        spread = COLLISION_PARTICLE_SPREAD
        amount = COLLISION_PARTICLE_WALL_AMOUNT
    for i in range(0, amount):
        collision_particles.append(Collision_Particle(x, y, random.randint(0, COLLISION_PARTICLE_VELOCITY_MAX), base_angle + random.randint(-spread * 10, spread * 10) / 10))

def update_collision_particles(collision_particles):
    to_destroy = []
    for i in range(0, len(collision_particles)):
        collision_particles[i].accelerate()
        collision_particles[i].move()
        collision_particles[i].detect_collisions()
        if collision_particles[i].destroy:
            to_destroy.insert(0, i)
    for i in to_destroy:
        collision_particles.pop(i)

# Spawn, jitter, decay, and destroy
def update_trails(trail_particles, enemies):
    for enemy in enemies:
        spawn = enemy.update_trail_timer()
        if spawn:
            trail_particles.append(Trail_Particle(enemy.x, enemy.y))
    to_destroy = []
    for i in range (0, len(trail_particles)):
        trail_particles[i].drift()
        destroy = trail_particles[i].decay()
        if destroy:
            to_destroy.insert(0, i)
    for i in to_destroy:
        trail_particles.pop(i)

def update_dash_particles(dash_particles):
    to_destroy = []
    for i in range(0, len(dash_particles)):
        if dash_particles[i].decay():
            to_destroy.insert(0, i)
    for i in to_destroy:
        dash_particles.pop(i)

def render(screen, player, enemies, collision_particles, trail_particles, dash_particles, screenshake, refraction):
    rectangles = create_rectangles(player, enemies, collision_particles, trail_particles, dash_particles)
    shake(rectangles, screenshake.shake_x[0] * SCREENSHAKE_MULT, screenshake.shake_y[0] * SCREENSHAKE_MULT)
    refracted_rectangles_1, refracted_rectangles_2 = refract(rectangles, refraction)
    rectangles = collide(refracted_rectangles_1, refracted_rectangles_2)
    draw(screen, rectangles)

def create_rectangles(player, enemies, collision_particles, trail_particles, dash_particles):
    rectangles = []
    if SHOW_COLLISION_PARTICLES:
        for particle in collision_particles:
            rectangles.append(Rectangle(particle.x - COLLISION_PARTICLE_OFFSET, particle.y - COLLISION_PARTICLE_OFFSET, COLLISION_PARTICLE_SIZE, COLLISION_PARTICLE_SIZE, COLLISION_PARTICLE_COLOR))
    for particle in trail_particles:
        rectangles.append(Rectangle(particle.x - particle.offset, particle.y - particle.offset, particle.size, particle.size, TRAIL_PARTICLE_COLOR))
    if SHOW_DASH_PARTICLES:
        for particle in dash_particles:
            rectangles.append(Rectangle(particle.x - DASH_PARTICLE_OFFSET, particle.y - DASH_PARTICLE_OFFSET, DASH_PARTICLE_SIZE, DASH_PARTICLE_SIZE, DASH_PARTICLE_COLOR))
            rectangles.append(Rectangle(particle.x - DASH_PARTICLE_OFFSET_INTERIOR, particle.y - DASH_PARTICLE_OFFSET_INTERIOR, DASH_PARTICLE_SIZE_INTERIOR, DASH_PARTICLE_SIZE_INTERIOR, DASH_PARTICLE_COLOR_INTERIOR))
    for enemy in enemies:
        rectangles.append(Rectangle(enemy.x - ENEMY_OFFSET, enemy.y - ENEMY_OFFSET, ENEMY_SIZE, ENEMY_SIZE, ENEMY_COLOR))
    rectangles.append(Rectangle(player.x - PLAYER_OFFSET, player.y - PLAYER_OFFSET, PLAYER_SIZE, PLAYER_SIZE, PLAYER_COLOR))
    return rectangles

def shake(rectangles, shake_x, shake_y):
    for rectangle in rectangles:
        rectangle.move(shake_x, shake_y)

def refract(rectangles, refraction):
    refracted_rectangles_1 = []
    refracted_rectangles_2 = []
    for rectangle in rectangles:
        refracted_rectangle_1, refracted_rectangle_2 = rectangle.refract(refraction)
        refracted_rectangles_1.append(refracted_rectangle_1)
        refracted_rectangles_2.append(refracted_rectangle_2)
    return refracted_rectangles_1, refracted_rectangles_2

# Here is a more intuitive version of the giant if construct below.
# I'll include a more extensive explanation later when I make my commenting more accesible.
#
# if rectangle_2.x > rectangle_1.x:
#     if rectangle_2.y > rectangle_1.y:
#         if rectangle_2.x + rectangle_2.width < rectangle_1.x + rectangle_1.width:
#             if rectangle_2.y + rectangle_2.height < rectangle_1.y + rectangle_1.height:
#                 if True:
#                     collisions.append(Rectangle(rectangle_2.x, rectangle_2.y, rectangle_2.width, rectangle_2.height, WHITE))
#             else:
#                 if rectangle_2.y <= rectangle_1.y + rectangle_1.height:
#                     collisions.append(Rectangle(rectangle_2.x, rectangle_2.y, rectangle_2.width, rectangle_1.y + rectangle_1.height - int(rectangle_2.y), WHITE))
#         else:
#             if rectangle_2.y + rectangle_2.height <= rectangle_1.y + rectangle_1.height:
#                 if rectangle_2.x <= rectangle_1.x + rectangle_1.width:
#                     collisions.append(Rectangle(rectangle_2.x, rectangle_2.y, rectangle_1.x + rectangle_1.width - int(rectangle_2.x), rectangle_2.height, WHITE))
#             else:
#                 if rectangle_2.x <= rectangle_1.x + rectangle_1.width and rectangle_2.y <= rectangle_1.y + rectangle_1.height:
#                     collisions.append(Rectangle(rectangle_2.x, rectangle_2.y, rectangle_1.x + rectangle_1.width - int(rectangle_2.x), rectangle_1.y + rectangle_1.height - int(rectangle_2.y), WHITE))
#     else:
#         if rectangle_2.x + rectangle_2.width < rectangle_1.x + rectangle_1.width:
#             if True:
#                 if rectangle_2.y + rectangle_2.height >= rectangle_1.y:
#                     collisions.append(Rectangle(rectangle_2.x, rectangle_1.y, rectangle_2.width, rectangle_2.y + rectangle_2.height - int(rectangle_1.y), WHITE))
#             else:
#                 if False:
#                     pass
#         else:
#             if rectangle_2.y + rectangle_2.height < rectangle_1.y + rectangle_1.height:
#                 if rectangle_2.x <= rectangle_1.x + rectangle_1.width and rectangle_2.y + rectangle_2.height >= rectangle_1.y:
#                     collisions.append(Rectangle(rectangle_2.x, rectangle_1.y, rectangle_1.x + rectangle_1.width - int(rectangle_2.x), rectangle_2.y + rectangle_2.height - int(rectangle_1.y), WHITE))
#             else:
#                 if rectangle_2.x <= rectangle_1.x + rectangle_1.width:
#                     collisions.append(Rectangle(rectangle_2.x, rectangle_1.y, rectangle_1.x + rectangle_1.width - int(rectangle_2.x), rectangle_1.height, WHITE))
# else:
#     if rectangle_2.y > rectangle_1.y:
#         if rectangle_2.x + rectangle_2.width < rectangle_1.x + rectangle_1.width:
#             if rectangle_2.y + rectangle_2.height < rectangle_1.y + rectangle_1.height:
#                 if rectangle_2.x + rectangle_2.width >= rectangle_1.x:
#                     collisions.append(Rectangle(rectangle_1.x, rectangle_2.y, rectangle_2.x + rectangle_2.width - int(rectangle_1.x), rectangle_2.height, WHITE))
#             else:
#                 if rectangle_2.x + rectangle_2.width >= rectangle_1.x and rectangle_2.y <= rectangle_1.y + rectangle_1.height:
#                     collisions.append(Rectangle(rectangle_1.x, rectangle_2.y, rectangle_2.x + rectangle_2.width - int(rectangle_1.x), rectangle_1.y + rectangle_1.height - int(rectangle_2.y), WHITE))
#         else:
#             if False:
#                 if False:
#                     pass
#             else:
#                 if rectangle_2.y <= rectangle_1.y + rectangle_1.height:
#                     collisions.append(Rectangle(rectangle_1.x, rectangle_2.y, rectangle_1.width, rectangle_1.y + rectangle_1.height - int(rectangle_2.y), WHITE))
#     else:
#         if rectangle_2.x + rectangle_2.width < rectangle_1.x + rectangle_1.width:
#             if rectangle_2.y + rectangle_2.height < rectangle_1.y + rectangle_1.height:
#                 if rectangle_2.x + rectangle_2.width >= rectangle_1.x and rectangle_2.y + rectangle_2.height >= rectangle_1.y:
#                     collisions.append(Rectangle(rectangle_1.x, rectangle_1.y, rectangle_2.x + rectangle_2.width - int(rectangle_1.x), rectangle_2.y + rectangle_2.height - int(rectangle_1.y), WHITE))
#             else:
#                 if rectangle_2.x + rectangle_2.width >= rectangle_1.x:
#                     collisions.append(Rectangle(rectangle_1.x, rectangle_1.y, rectangle_2.x + rectangle_2.width - int(rectangle_1.x), rectangle_1.height, WHITE))
#         else:
#             if rectangle_2.y + rectangle_2.height <= rectangle_1.y + rectangle_1.height:
#                 if rectangle_2.y + rectangle_2.height > rectangle_1.y:
#                     collisions.append(Rectangle(rectangle_1.x, rectangle_1.y, rectangle_1.width, rectangle_2.y + rectangle_2.height - int(rectangle_1.y), WHITE))
#             else:
#                 if True:
#                     collisions.append(Rectangle(rectangle_1.x, rectangle_1.y, rectangle_1.width, rectangle_1.height, WHITE))
#
# The code below very unclear. To edit, paste the code in this comment, edit that, and recompress.

def collide(rectangles_1, rectangles_2):
    collisions = []
    for rectangle_1 in rectangles_1:
        for rectangle_2 in rectangles_2:
            if rectangle_2.x > rectangle_1.x:
                if rectangle_2.y > rectangle_1.y:
                    if rectangle_2.x + rectangle_2.width < rectangle_1.x + rectangle_1.width:
                        if rectangle_2.y + rectangle_2.height < rectangle_1.y + rectangle_1.height:
                            collisions.append(Rectangle(rectangle_2.x, rectangle_2.y, rectangle_2.width, rectangle_2.height, WHITE))
                        elif rectangle_2.y <= rectangle_1.y + rectangle_1.height:
                            collisions.append(Rectangle(rectangle_2.x, rectangle_2.y, rectangle_2.width, rectangle_1.y + rectangle_1.height - int(rectangle_2.y), WHITE))
                    elif rectangle_2.y + rectangle_2.height <= rectangle_1.y + rectangle_1.height:
                        if rectangle_2.x <= rectangle_1.x + rectangle_1.width:
                            collisions.append(Rectangle(rectangle_2.x, rectangle_2.y, rectangle_1.x + rectangle_1.width - int(rectangle_2.x), rectangle_2.height, WHITE))
                    elif rectangle_2.x <= rectangle_1.x + rectangle_1.width and rectangle_2.y <= rectangle_1.y + rectangle_1.height:
                        collisions.append(Rectangle(rectangle_2.x, rectangle_2.y, rectangle_1.x + rectangle_1.width - int(rectangle_2.x), rectangle_1.y + rectangle_1.height - int(rectangle_2.y), WHITE))
                elif rectangle_2.x + rectangle_2.width < rectangle_1.x + rectangle_1.width:
                    if rectangle_2.y + rectangle_2.height >= rectangle_1.y:
                        collisions.append(Rectangle(rectangle_2.x, rectangle_1.y, rectangle_2.width, rectangle_2.y + rectangle_2.height - int(rectangle_1.y), WHITE))
                elif rectangle_2.y + rectangle_2.height < rectangle_1.y + rectangle_1.height:
                    if rectangle_2.x <= rectangle_1.x + rectangle_1.width and rectangle_2.y + rectangle_2.height >= rectangle_1.y:
                        collisions.append(Rectangle(rectangle_2.x, rectangle_1.y, rectangle_1.x + rectangle_1.width - int(rectangle_2.x), rectangle_2.y + rectangle_2.height - int(rectangle_1.y), WHITE))
                elif rectangle_2.x <= rectangle_1.x + rectangle_1.width:
                    collisions.append(Rectangle(rectangle_2.x, rectangle_1.y, rectangle_1.x + rectangle_1.width - int(rectangle_2.x), rectangle_1.height, WHITE))
            elif rectangle_2.y > rectangle_1.y:
                if rectangle_2.x + rectangle_2.width < rectangle_1.x + rectangle_1.width:
                    if rectangle_2.y + rectangle_2.height < rectangle_1.y + rectangle_1.height:
                        if rectangle_2.x + rectangle_2.width >= rectangle_1.x:
                            collisions.append(Rectangle(rectangle_1.x, rectangle_2.y, rectangle_2.x + rectangle_2.width - int(rectangle_1.x), rectangle_2.height, WHITE))
                    elif rectangle_2.x + rectangle_2.width >= rectangle_1.x and rectangle_2.y <= rectangle_1.y + rectangle_1.height:
                        collisions.append(Rectangle(rectangle_1.x, rectangle_2.y, rectangle_2.x + rectangle_2.width - int(rectangle_1.x), rectangle_1.y + rectangle_1.height - int(rectangle_2.y), WHITE))
                elif rectangle_2.y <= rectangle_1.y + rectangle_1.height:
                    collisions.append(Rectangle(rectangle_1.x, rectangle_2.y, rectangle_1.width, rectangle_1.y + rectangle_1.height - int(rectangle_2.y), WHITE))
            elif rectangle_2.x + rectangle_2.width < rectangle_1.x + rectangle_1.width:
                if rectangle_2.y + rectangle_2.height < rectangle_1.y + rectangle_1.height:
                    if rectangle_2.x + rectangle_2.width >= rectangle_1.x and rectangle_2.y + rectangle_2.height >= rectangle_1.y:
                        collisions.append(Rectangle(rectangle_1.x, rectangle_1.y, rectangle_2.x + rectangle_2.width - int(rectangle_1.x), rectangle_2.y + rectangle_2.height - int(rectangle_1.y), WHITE))
                elif rectangle_2.x + rectangle_2.width >= rectangle_1.x:
                    collisions.append(Rectangle(rectangle_1.x, rectangle_1.y, rectangle_2.x + rectangle_2.width - int(rectangle_1.x), rectangle_1.height, WHITE))
            elif rectangle_2.y + rectangle_2.height <= rectangle_1.y + rectangle_1.height:
                if rectangle_2.y + rectangle_2.height > rectangle_1.y:
                    collisions.append(Rectangle(rectangle_1.x, rectangle_1.y, rectangle_1.width, rectangle_2.y + rectangle_2.height - int(rectangle_1.y), WHITE))
            else:
                collisions.append(Rectangle(rectangle_1.x, rectangle_1.y, rectangle_1.width, rectangle_1.height, WHITE))

    rectangles = []
    for rectangle in rectangles_1:
        rectangles.append(rectangle)
    for rectangle in rectangles_2:
        rectangles.append(rectangle)
    for rectangle in collisions:
        rectangles.append(rectangle)
    return rectangles

def draw(screen, rectangles):
    for rectangle in rectangles:
        pygame.draw.rect(screen, rectangle.color, pygame.Rect(rectangle.x, rectangle.y, rectangle.width, rectangle.height))

main()
pygame.quit()