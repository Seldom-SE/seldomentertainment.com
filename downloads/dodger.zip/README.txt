dodger.py (c) sage 2017-2018
Public domain sound effects by Juhani Junkala