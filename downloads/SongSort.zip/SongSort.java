import java.util.ArrayList;
import java.util.Scanner;

class SongSort {
    public static void main (String [] args) {
        Scanner scan = new Scanner(System.in);

        String [] songs = getSongList(scan);
        mergeSort(songs, scan);
        print(songs);

        scan.close();
    }

    static String [] getSongList (Scanner scan) {
        String in = " ";
        ArrayList <String> songs = new ArrayList <String> ();

        System.out.println("Enter the list of songs to sort. Enter an empty string to continue.");
        while (!in.equals("")) {
            songs.add(in);
            in = scan.nextLine();
        }
        songs.remove(0);

        return songs.toArray(new String [0]);
    }

    static void print (String [] arr) {
        System.out.println("Your songs are:");
        for (String el : arr) {
            System.out.println(el);
        }
    }

    static void mergeSort (String [] arr, Scanner scan) {
        // Split into 2 arrays
        String [] L = new String [arr.length / 2];
        String [] R = new String [arr.length - arr.length / 2];
        // Fill the new arrays
        for (int i = 0; i < L.length; i++) L[i] = arr[i];
        for (int i = 0; i < R.length; i++) R[i] = arr[i + arr.length / 2];
        // If an array is larger than 1 mergeSort it
        if (L.length > 1) mergeSort(L, scan);
        if (R.length > 1) mergeSort(R, scan);
        // Make running indices for the arrays
        int l = 0;
        int r = 0;
        for (int i = 0; i < arr.length; i++) {
            // If either index is out of bounds, the other array should be used
            if (l == L.length) arr[i] = R[r++];
            else if (r == R.length) arr[i] = L[l++];
            // Fill the array with the lesser current value
            else {
                System.out.printf("Which is better: %s (z) or %s? (x)\n", L[l], R[r]);
                String in = scan.nextLine();
                if (in.toLowerCase().charAt(0) == 'z') arr[i] = L[l++];
                else arr[i] = R[r++];
            }
        }
    }
}