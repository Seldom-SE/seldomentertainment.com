// ptg4 by sage

use std::io::stdin;

fn main() {
    let mut row: Vec<i128> = Vec::new();
    row.push(1);
    let _in = &mut String::new();

    loop {
        println!("{:?}", row);
        row = (0..row.len() + 1).map(|a| (a, a + 1))
            .map(|(l, r)| if l == 0 {0} else {row[l - 1]} + if r == row.len() + 1 {0} else {row[r - 1]})
            .collect();
        stdin().read_line(_in).unwrap();
    }
}
