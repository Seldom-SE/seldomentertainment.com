# exercise10.py
# Author: Thomas Hansen

import pygame
import random

pygame.init()

screen = pygame.display.set_mode((1366,768))
pygame.display.set_caption("Exercise 10")

playing = True

screen.fill((random.randint(0,255),random.randint(0,255),random.randint(0,255)))
while playing:
    screen.fill((random.randint(0,255),random.randint(0,255),random.randint(0,255)))
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            playing = False
    pygame.display.flip()
pygame.quit()
