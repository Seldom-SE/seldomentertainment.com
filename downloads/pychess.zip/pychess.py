# pychess.py by sage

_ = 0
P = 1
N = 2
B = 3
R = 4
Q = 5
K = 6

CHAR_P0_PIECES = ['-']
CHAR_P1_PIECES = ['-','P','N','B','R','Q','K']
CHAR_P2_PIECES = ['-','p','n','b','r','q','k']
PIECES = [CHAR_P0_PIECES, CHAR_P1_PIECES, CHAR_P2_PIECES]

ROWS = ['8','7','6','5','4','3','2','1']
COLS = ['a','b','c','d','e','f','g','h']

class Piece:
    def __init__(self, owner, rank, moved):
        self.owner = owner
        self.rank  = rank
        self.moved = moved

class Move:
    def __init__(self, move):
        for space in range(0,8):
            if move[0] == COLS[space]: self.fm_col = space
            if move[1] == ROWS[space]: self.fm_row = space
            if move[2] == COLS[space]: self.to_col = space
            if move[3] == ROWS[space]: self.to_row = space
    
    def move(self, board, player):
        results = self.check_move(board, player, False)
        if results[0] != "":
            return results
        self.force_move(board)
        return results

    def check_move(self, board, player, recur):
        fm_owner = board.board[self.fm_row][self.fm_col].owner
        to_owner = board.board[self.to_row][self.to_col].owner
        fm_rank  = board.board[self.fm_row][self.fm_col].rank
        fm_moved = board.board[self.fm_row][self.fm_col].moved

        if player == 1:
            enemy = 2
            direction_mod = 1
            home = 7
        else:
            enemy = 1
            direction_mod = -1
            home = 0

        # Checking whether the move is valid; return True means there's an error

        if fm_owner != player: # Only move your own piece
            return ["You can only move your own piece", ""]
        if to_owner == player: # Can't move onto your own pieces
            return ["Pieces cannot move onto allied pieces", ""]
        
        if fm_rank == P:
            if self.fm_row == 3.5 + 2.5 * direction_mod and self.to_row == self.fm_row - 2 * direction_mod: # Pawns that haven't moved moving forward 2 spaces
                if self.fm_col != self.to_col: # Can't move outside the column
                    return ["Pawns must stay in their own column in a double advance", ""]
                if board.board[self.fm_row - 1 * direction_mod][self.fm_col].owner != 0: # Can't jump over a piece
                    return ["Pawns cannot jump over pieces", ""]
                if to_owner == enemy:
                    return ["Pawns cannot take other pieces in a double advance", ""]
            else:
                if self.to_row != self.fm_row - 1 * direction_mod: # Must move forward 1
                    return ["Pawns must move forward", ""]
                if to_owner == enemy:
                    if not(self.fm_col == self.to_col - 1 or self.fm_col == self.to_col + 1): # Must move diagonally
                        return ["Pawns must capture diagonally", ""]
                else:
                    if self.fm_col != self.to_col: # Must move directly forward
                        return ["Pawns must move directly forward", ""]
            if self.to_row == 0 or self.to_row == 7:
                board.board[self.fm_row][self.fm_col].rank = Q
        elif fm_rank == N:
            if not((abs(self.fm_row - self.to_row) == 1 and abs(self.fm_col - self.to_col) == 2)   # Vertical L moves
                or (abs(self.fm_row - self.to_row) == 2 and abs(self.fm_col - self.to_col) == 1)): # Horizntl L moves
                return ["Knights must move in an L", ""]
        elif fm_rank == B:
            if abs(self.fm_row - self.to_row) == abs(self.fm_col - self.to_col): # Moving diagonally
                if self.fm_row > self.to_row: vert_mod = -1
                else:                         vert_mod =  1
                if self.fm_col > self.to_col: horz_mod = -1
                else:                         horz_mod =  1
                for space_mod in range(1, abs(self.fm_row - self.to_row)): # Can't jump over other pieces
                    if board.board[self.fm_row + space_mod * vert_mod][self.fm_col + space_mod * horz_mod].rank != _:
                        return ["Bishops cannot jump over pieces", ""]
            else:
                return ["Bishops must move diagonally", ""]
        elif fm_rank == R:
            if self.fm_row == self.to_row: # Moving horizontally
                if self.fm_col > self.to_col: horz_mod = -1
                else:                         horz_mod = 1
                vert_mod = 0
                space_mods = range(1, abs(self.fm_col - self.to_col))
            elif self.fm_col == self.to_col: # Moving vertically
                if self.fm_row > self.to_row: vert_mod = -1
                else:                         vert_mod = 1
                horz_mod = 0
                space_mods = range(1, abs(self.fm_row - self.to_row))
            else:
                return ["Rooks must move orthogonally", ""]
            for space_mod in space_mods:
                if board.board[self.fm_row + space_mod * vert_mod][self.fm_col + space_mod * horz_mod].rank != _:
                    return ["Rooks cannot jump over pieces", ""]
        elif fm_rank == Q:
            if abs(self.fm_row - self.to_row) == abs(self.fm_col - self.to_col): # Moving diagonally
                if self.fm_row > self.to_row: vert_mod = -1
                else:                         vert_mod =  1
                if self.fm_col > self.to_col: horz_mod = -1
                else:                         horz_mod =  1
                space_mods = range(1, abs(self.fm_row - self.to_row))
            elif self.fm_row == self.to_row: # Moving horizontally
                if self.fm_col > self.to_col: horz_mod = -1
                else:                         horz_mod = 1
                vert_mod = 0
                space_mods = range(1, abs(self.fm_col - self.to_col))
            elif self.fm_col == self.to_col: # Moiving vertically
                if self.fm_row > self.to_row: vert_mod = -1
                else:                         vert_mod = 1
                horz_mod = 0
                space_mods = range(1, abs(self.fm_row - self.to_row))
            else:
                return ["Queens must move diagonally or orthogonally", ""]
            for space_mod in space_mods:
                if board.board[self.fm_row + space_mod * vert_mod][self.fm_col + space_mod * horz_mod].rank != _:
                    return ["Queens cannot jump over pieces", ""]
        elif fm_rank == K:
            if self.fm_row == home and self.to_row == home and self.fm_col == 4 and (self.to_col == 2 or self.to_col == 6):
                if fm_moved == True:
                    return ["Kings cannot castle after moving", ""]
                if self.to_col == 2:
                    rook_col = 0
                elif self.to_col == 6:
                    rook_col = 7
                if board.board[home][rook_col].rank != R:
                    return ["Kings cannot castle without a rook", ""]
                if board.board[home][rook_col].moved == True:
                    return ["Kings cannot castle after the rook moved", ""]
                if (self.to_col == 2 and (board.board[home][1].rank != _ or board.board[home][2].rank != _ or board.board[home][3].rank != _)) or (self.to_col == 6 and (board.board[home][5].rank != _ or board.board[home][6].rank != _)):
                    return ["Kings cannot castle over pieces", ""]
                for row in range(0,8):
                    for col in range(0,8):
                        if Move(COLS[col] + ROWS[row] + COLS[self.fm_col] + ROWS[self.fm_row]).check_move(board, enemy, False)[0] == "":
                            return ["Kings cannot castle out of check", ""]
                hyp_board = board.copy()
                Move(COLS[self.fm_col] + ROWS[self.fm_row] + COLS[self.to_col] + ROWS[self.to_row]).force_move(hyp_board)
                for row in range(0,8):
                    for col in range(0,8):
                        if Move(COLS[col] + ROWS[row] + COLS[self.fm_col] + ROWS[self.fm_row]).check_move(board, enemy, False)[0] == "":
                            return ["Kings cannot castle into check", ""]
                hyp_board = board.copy()
                if self.to_col == 2:
                    move = Move(COLS[4] + ROWS[home] + COLS[3] + ROWS[home])
                elif self.to_col == 6:
                    move = Move(COLS[4] + ROWS[home] + COLS[5] + ROWS[home])
                if move.check_move(board, player, False)[0] != "":
                    return ["Kings cannot castle through check", ""]
            elif abs(self.fm_row - self.to_row) > 1 or abs(self.fm_col - self.to_col) > 1:
                return ["Kings cannot move more than 1 space", ""]
        
        if not recur:
            hyp_board = board.copy()
            Move(COLS[self.fm_col] + ROWS[self.fm_row] + COLS[self.to_col] + ROWS[self.to_row]).force_move(hyp_board)
            for K_row in range(0,8):
                for K_col in range(0,8):
                    if hyp_board.board[K_row][K_col].rank == K and hyp_board.board[K_row][K_col].owner == player:
                        for row in range(0,8):
                            for col in range(0,8):
                                if Move(COLS[col] + ROWS[row] + COLS[K_col] + ROWS[K_row]).check_move(hyp_board, enemy, True)[0] == "":
                                    if fm_rank == K:
                                        return ["Kings cannot move into check", ""]
                                    else:
                                        return ["Cannot end turn in check", ""]

            check = False
            for K_row in range(0,8):
                for K_col in range(0,8):
                    if hyp_board.board[K_row][K_col].rank == K and hyp_board.board[K_row][K_col].owner == enemy:
                        for row in range(0,8):
                            for col in range(0,8):
                                if Move(COLS[col] + ROWS[row] + COLS[K_col] + ROWS[K_row]).check_move(hyp_board, player, True)[0] == "":
                                    check = True
                        if check:
                            checkmate = True
                            for hyp_to_row in range(0,8):
                                for hyp_to_col in range(0,8):
                                    for hyp_fm_row in range(0,8):
                                        for hyp_fm_col in range(0,8):
                                            if Move(COLS[hyp_fm_col] + ROWS[hyp_fm_row] + COLS[hyp_to_col] + ROWS[hyp_to_row]).check_move(hyp_board, enemy, False)[0] == "":
                                                checkmate = False
                            if checkmate:
                                return ["", "checkmate"]
                            return ["", "check"]

        return ["", ""]

    def force_move (self, board):
        board.board[self.to_row][self.to_col] = board.board[self.fm_row][self.fm_col]
        board.board[self.to_row][self.to_col].moved = True
        board.board[self.fm_row][self.fm_col] = Piece(0,_,False)
        if board.board[self.to_row][self.to_col].rank == K and self.fm_col - self.to_col > 1:
            board.board[self.to_row][3] = board.board[self.fm_row][0]
            board.board[self.to_row][3].moved = True
            board.board[self.fm_row][0] = Piece(0,_,False)
        elif board.board[self.to_row][self.to_col].rank == K and self.fm_col - self.to_col < -1:
            board.board[self.to_row][5] = board.board[self.fm_row][7]
            board.board[self.to_row][5].moved = True
            board.board[self.fm_row][7] = Piece(0,_,False)
        for piece in board.board[0]:
            if piece.rank == P:
                piece.rank = Q
        for piece in board.board[7]:
            if piece.rank == P:
                piece.rank = Q

class Board:
    def __init__(self, char_board):
        self.board = [[],[],[],[],[],[],[],[]]
        for row in range(0,8):
            for col in range(0,8):
                if char_board[row][col] == '-':
                    owner = 0
                    rank = _
                else:
                    owner = 2
                    for p1_piece in CHAR_P1_PIECES:
                        if char_board[row][col] == p1_piece:
                            owner = 1
                if   owner == 1:
                    if   char_board[row][col] == 'P': rank = P
                    elif char_board[row][col] == 'N': rank = N
                    elif char_board[row][col] == 'B': rank = B
                    elif char_board[row][col] == 'R': rank = R
                    elif char_board[row][col] == 'Q': rank = Q
                    elif char_board[row][col] == 'K': rank = K
                elif owner == 2:
                    if   char_board[row][col] == 'p': rank = P
                    elif char_board[row][col] == 'n': rank = N
                    elif char_board[row][col] == 'b': rank = B
                    elif char_board[row][col] == 'r': rank = R
                    elif char_board[row][col] == 'q': rank = Q
                    elif char_board[row][col] == 'k': rank = K
                self.board[row].append(Piece(owner, rank, False))

    def copy (self):
        char_board = [[],[],[],[],[],[],[],[]]
        for row in range(0, 8):
            for col in range(0, 8):
                char_board[row].append(self.get_char(row, col))
        return Board(char_board)
    
    def get_char(self, row, col):
        return PIECES[self.board[row][col].owner][self.board[row][col].rank]

class Status:
    def __init__(self, running, results, player):
        self.running = running
        self.results = results
        self.player = player

def main():
    board = Board([
        ['r','n','b','q','k','b','n','r'],
        ['p','p','p','p','p','p','p','p'],
        ['-','-','-','-','-','-','-','-'],
        ['-','-','-','-','-','-','-','-'],
        ['-','-','-','-','-','-','-','-'],
        ['-','-','-','-','-','-','-','-'],
        ['P','P','P','P','P','P','P','P'],
        ['R','N','B','Q','K','B','N','R']])
    status = Status(True, ["", ""], 1)
    while status.running:
        status = print_ui(board, status)
        if status.running:
            move = take_turn()
            board, status = update_board(board, move, status.player)

def print_ui(board, status):
    if status.results[0] != "":
        print("==!ERROR!== >>> " + status.results[0])
    if status.results[1] == "checkmate":
        print("= Checkmate! =")
        winner = status.player - 1
        if winner == 0:
            winner = 2
        print("= Player " + str(winner) + " wins! =")
        return Status(False, status.results, status.player)
    print()
    print("= player " + str(status.player) + " =")
    print()
    print("   a b c d e f g h")
    print()
    for row in range(0, 8):
        char_row = str(8 - row) + ' '
        for col in range(0, 8):
            char_row += ' ' + board.get_char(row, col)
        print(char_row)
    print()
    if status.results[1] == "check":
        print("= Check! =")
        print()
    return status

def take_turn():
    return input("Make a move: ")

def update_board(board, move, player):
    if move == "exit":
        return board, Status(False, ["", ""], player)

    valid = True
    if len(move) != 4:
        valid = False
    else:
        found = False
        for col in COLS:
            if move[0] == col:
                found = True
        valid = valid and found

        found = False
        for row in ROWS:
            if move[1] == row:
                found = True
        valid = valid and found

        found = False
        for col in COLS:
            if move[2] == col:
                found = True
        valid = valid and found

        found = False
        for row in ROWS:
            if move[3] == row:
                found = True
        valid = valid and found

    if not(valid):
        return board, Status(True, ["Invalid command. Enter the source column and row, then the destination column and row (ex. e2e4).", ""], player)

    move = Move(move)
    results = move.move(board, player)

    if results[0] == "":
        player += 1
        if player == 3: player = 1
    return board, Status(True, results, player)

main()