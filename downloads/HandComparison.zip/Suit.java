class Suit {
    public static final int DIAMONDS = 0;
    public static final int CLUBS = 1;
    public static final int HEARTS = 2;
    public static final int SPADES = 3;
    public static final String[] SUITS = {"Diamonds", "Clubs", "Hearts", "Spades"};
    
    int suit;

    public Suit (int suit) {
        this.suit = suit;
    }

    public Suit (Suit suit) {
        this.suit = suit.get_suit_val();
    }

    public static int to_int (String suit) {
        for (int i = 0; i < SUITS.length; i++) if (suit.equals(SUITS[i])) return i;
        return -1;
    }

    public String get_suit() {
        return SUITS[suit];
    }

    public int get_suit_val() {
        return suit;
    }

    public boolean equals (Suit suit) {
        return suit.equals(this.suit);
    }

    public boolean equals (int suit) {
        return this.suit == suit;
    }
}