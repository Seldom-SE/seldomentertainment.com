class Rank {
    public static final int TWO = 2;
    public static final int THREE = 3;
    public static final int FOUR = 4;
    public static final int FIVE = 5;
    public static final int SIX = 6;
    public static final int SEVEN = 7;
    public static final int EIGHT = 8;
    public static final int NINE = 9;
    public static final int TEN = 10;
    public static final int JACK = 11;
    public static final int QUEEN = 12;
    public static final int KING = 13;
    public static final int ACE = 14;
    public static final String[] RANKS = {"", "", "Two", "Three", "Four", "Five", "Six", "Seven",
                                            "Eight", "Nine", "Ten", "Jack", "Queen", "King", "Ace"};

    int rank;

    public Rank (int rank) {
        this.rank = rank;
    }

    public Rank (Rank rank) {
        this.rank = rank.get_rank_val();
    }

    public static int to_int (String rank) {
        for (int i = 2; i < RANKS.length; i++) if (rank.equals(RANKS[i])) return i;
        return -1;
    }

    public String get_rank() {
        return RANKS[rank];
    }

    public int get_rank_val() {
        return rank;
    }

    public boolean equals (Rank rank) {
        return rank.equals(this.rank);
    }

    public boolean equals (int rank) {
        return this.rank == rank;
    }

    public boolean is_greater_than (Rank rank) {
        return this.rank > rank.get_rank_val();
    }
}