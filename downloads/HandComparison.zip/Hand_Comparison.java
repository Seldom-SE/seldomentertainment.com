// Hand_Comparison.java by sage 2018
// For Ryland

// Integer.parseInt(String);
// Double.parseDouble(String);
// String.getValueOf(int); etc
// AKQJ098765432

import java.util.Scanner;

class Hand_Comparison {
    public static void main (String[] args) {
        Scanner scan = new Scanner(System.in);
        
        System.out.println();
        System.out.println("Enter the first hand:");
        Hand hand1 = fill(scan);
        hand1.sort();
        Hand_Rank rank1 = hand1.get_rank();

        System.out.println();
        System.out.println("Enter the second hand:");
        Hand hand2 = fill(scan);
        System.out.println();
        hand2.sort();
        Hand_Rank rank2 = hand2.get_rank();

        if (!rank1.is_greater_than(rank2))
            System.out.printf("The first hand (%s) beats the second hand (%s)!\n", rank1, rank2);
        else
            System.out.printf("The second hand (%s) beats the first hand (%s)!\n", rank2, rank1);

        scan.close();
    }

    public static Hand fill (Scanner scan) {
        String type;
        int rank_end;
        Hand hand = new Hand();
        
        for (int i = 0; i < hand.get_hand().length; i++) {
            System.out.printf("Card %d: ", i);
            type = scan.nextLine();
            rank_end = type.indexOf(" of ");
            hand.set_card(i, new Card(Rank.to_int(type.substring(0, rank_end)), Suit.to_int(type.substring(rank_end + 4))));
        }
        return hand;
    }

    public static void display (Hand hand) {
        System.out.println();
        for (int i = 0; i < hand.get_hand().length; i++) System.out.printf("Card %d: %s of %s\n", i, hand.get_hand()[i].get_rank().get_rank(), hand.get_hand()[i].get_suit().get_suit());
    }
}