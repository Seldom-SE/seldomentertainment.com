class Hand_Rank {
    public enum Type {
        STRAIGHT_FLUSH  (0),
        FOUR_OF_A_KIND  (1),
        FULL_HOUSE      (2),
        FLUSH           (3),
        STRAIGHT        (4),
        THREE_OF_A_KIND (5),
        TWO_PAIR        (6),
        ONE_PAIR        (7),
        HIGH_CARD       (8);

        public int rank;

        Type(int rank) {
            this.rank = rank;
        }
    }

    public static class TypeRank {
        public Type type;
        public Rank rank;
        public Rank nextRank;

        public TypeRank (Type type, Rank rank, Rank nextRank) {
            this.type = type;
            this.rank = rank;
            this.nextRank = nextRank;
        }
    }

    private TypeRank typeRank;
    private Card high_card;

    public Hand_Rank (TypeRank typeRank, Card high_card) {
        this.typeRank = typeRank;
        this.high_card = high_card;
    }

    public static TypeRank type_of (Hand hand) {
        int[] ranks = new int[15];
        int[] suits = new int[4];

        for (Card card : hand.hand) {
            ranks[card.get_rank_val()]++;
            suits[card.get_suit_val()]++;
        }

        int[] ranks_amt = new int[13];

        for (int i = 2; i < 15; i++) {
            ranks_amt[i - 2] = ranks[i];
        }

        boolean straight = false;
        int consec_incs = ranks_amt[12] == 1 ? 1 : 0;
        int max_rank = 0; // Highest rank overall
        int max_amt = 0;  // Count of rank with highest count
        int max_amt_rank = 0; // Rank with highest count
        int next_max_amt = 0; // Count of rank with second highest count
        int next_max_amt_rank = 0; // Rank with the second highest count

        for (int i = 0; i < ranks_amt.length; i++) {
            if (ranks_amt[i] >= max_amt) {
                max_rank = i;
                next_max_amt = max_amt;
                max_amt = ranks_amt[i];
                next_max_amt_rank = max_amt_rank;
                max_amt_rank = i;
            }
            
            if (ranks_amt[i] == 1) {
                consec_incs += 1;
                if (consec_incs == 5) {
                    straight = true;
                    break;
                }
            }
            else {
                consec_incs = 0;
            }
        }

        boolean flush = false;
        
        for (int suit : suits) {
            if (suit == 5) {
                flush = true;
                break;
            }
        }

        /*
        for (int i = 0; i < 15; i++) {
            System.out.printf("ranks[%d] = %d\n", i, ranks[i]);
        }
        for (int i = 0; i < 4; i++) {
            System.out.printf("suits[%d] = %d\n", i, suits[i]);
        }
        for (int i = 0; i < 13; i++) {
            System.out.printf("ranks_amt[%d] = %d\n", i, ranks_amt[i]);
        }
        System.out.printf("straight = %b\n", straight);
        System.out.printf("consec_incs = %d\n", consec_incs);
        System.out.printf("max_amt = %d\n", max_amt);
        System.out.printf("max_amt_rank = %d\n", max_amt_rank);
        System.out.printf("next_max_amt = %d\n", next_max_amt);
        System.out.printf("next_max_amt_rank = %d\n", next_max_amt_rank);
        System.out.printf("flush = %b\n", flush);
        */

        if (straight     && flush)             return new TypeRank(Type.STRAIGHT_FLUSH , new Rank(max_rank     + 2), new Rank(max_rank          + 2));
        if (max_amt >= 4)                      return new TypeRank(Type.FOUR_OF_A_KIND , new Rank(max_amt_rank + 2), new Rank(max_amt_rank      + 2));
        if (max_amt == 3 && next_max_amt == 2) return new TypeRank(Type.FULL_HOUSE     , new Rank(max_amt_rank + 2), new Rank(next_max_amt_rank + 2));
        if (flush)                             return new TypeRank(Type.FLUSH          , new Rank(max_rank     + 2), new Rank(max_rank          + 2));
        if (straight)                          return new TypeRank(Type.STRAIGHT       , new Rank(max_rank     + 2), new Rank(max_rank          + 2));
        if (max_amt == 3)                      return new TypeRank(Type.THREE_OF_A_KIND, new Rank(max_amt_rank + 2), new Rank(max_amt_rank      + 2));
        if (max_amt == 2 && next_max_amt == 2) return new TypeRank(Type.TWO_PAIR       , new Rank(max_amt_rank + 2), new Rank(next_max_amt_rank + 2));
        if (max_amt == 2)                      return new TypeRank(Type.ONE_PAIR       , new Rank(max_amt_rank + 2), new Rank(max_amt_rank      + 2));
                                               return new TypeRank(Type.HIGH_CARD      , new Rank(max_rank     + 2), new Rank(max_rank          + 2));
    }

    public static Card high_card_of (Hand hand) {
        Card high = hand.hand[0];
        for (Card card : hand.hand) high = high.compare(card) ? high : card;
        return high;
    }

    public boolean is_greater_than (Hand_Rank other) {
        if (other.equals(typeRank)) return !other.is_greater_than(high_card);
        return !other.is_greater_than(typeRank);
    }

    public boolean is_greater_than (TypeRank typeRank) {
        // TypeRank type
        // TypeRank rank
        // TypeRank nextRank
        // High Card
        if (this.typeRank.type.rank == typeRank.type.rank) {
            if (this.typeRank.rank.equals(typeRank.rank)) {
                return this.typeRank.nextRank.is_greater_than(typeRank.nextRank);
            }
            return this.typeRank.rank.is_greater_than(typeRank.rank);
        }
        return this.typeRank.type.rank > typeRank.type.rank;
    }

    public boolean is_greater_than (Card high_card) {
        return this.high_card.compare(high_card);
    }

    public boolean equals (TypeRank typeRank) {
        return this.typeRank.type.rank == typeRank.type.rank && this.typeRank.rank.equals(typeRank.rank) && this.typeRank.nextRank.equals(typeRank.nextRank);
    }

    public String toString () {
        switch (typeRank.type) {
            case STRAIGHT_FLUSH:
                return "Straight flush of with a high of " + high_card;
            case FOUR_OF_A_KIND:
                return "Four of a kind of " + typeRank.rank.get_rank() + "s";
            case FULL_HOUSE:
                return "Full house of " + typeRank.rank.get_rank() + "s and " + typeRank.nextRank.get_rank() + "s";
            case FLUSH:
                return "Flush with a high of " + high_card;
            case STRAIGHT:
                return "Straight with a high of " + high_card;
            case THREE_OF_A_KIND:
                return "Three of a kind of " + typeRank.rank.get_rank() + "s";
            case TWO_PAIR:
                return "Two pair of " + typeRank.rank.get_rank() + "s and " + typeRank.nextRank.get_rank() + "s with a high card of " + high_card;
            case ONE_PAIR:
                return "Pair of " + typeRank.rank.get_rank() + "s with a high card of " + high_card;
            case HIGH_CARD:
                return "High of " + high_card;
        }
        return "No rank found";
    }
}