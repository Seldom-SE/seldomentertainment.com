class Hand {
    Card[] hand;

    public Hand () {
        hand = new Card[5];
    }

    public Hand (Card[] hand) {
        this.hand = new Card[5];
        for (int i = 0; i < hand.length; i++) {
            this.hand[i] = new Card(hand[i].get_rank(), hand[i].get_suit());
        }
    }

    public Card[] get_hand() {
        return hand;
    }

    public void set_hand (Card[] hand) {
        this.hand = hand;
    }

    public void set_card (int i, Card card) {
        hand[i] = card;
    }

    public void sort() {
        for (int i = 1; i < hand.length; i++) {
            Card temp = hand[i];
            int j = i - 1;
            for (; j >= 0 && !hand[j].compare(temp); j--) hand[j + 1] = hand[j];
            hand[j + 1] = temp;
        }
    }

    public boolean compare (Hand other) {
        return get_rank().is_greater_than(other.get_rank());
    }

    public Hand_Rank get_rank() {
        return new Hand_Rank(Hand_Rank.type_of(this), Hand_Rank.high_card_of(this));
    }
}