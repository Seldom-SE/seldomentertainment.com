class Card {
    Rank rank;
    Suit suit;

    public Card (int rank, int suit) {
        this.rank = new Rank(rank);
        this.suit = new Suit(suit);
    }

    public Card (Rank rank, Suit suit) {
        this.rank = new Rank(rank);
        this.suit = new Suit(suit);
    }

    public boolean compare (Card comp) {
        return this.get_rank_val() == comp.get_rank_val() ? this.get_suit_val() > comp.get_suit_val() : this.get_rank_val() > comp.get_rank_val();
    }

    public int get_rank_val() {
        return rank.get_rank_val();
    }

    public int get_suit_val() {
        return suit.get_suit_val();
    }

    public Rank get_rank() {
        return rank;
    }

    public Suit get_suit() {
        return suit;
    }

    public String toString() {
        return rank.get_rank() + " of " + suit.get_suit();
    }
}