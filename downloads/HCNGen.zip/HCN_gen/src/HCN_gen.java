import java.util.Scanner;

public class HCN_gen {
    public static void main (String[] args) {
        Scanner scan = new Scanner(System.in);
        int most = 0;
        int facts;
        for (double num = 1;; num++) {
            facts = 0;
            for (double i = 1; i <= num; i++) {
                if (num / i == (int)(num / i)) {
                    facts++;
                }
            }
            if (facts > most) {
                System.out.printf("%.0f\n", num);
                most = facts;
            }
        }
    }
}

// 1
// 2
// 4
// 6
// 12
// 24
// 36
// 48
// 60
// 120
// 180
// 240
// 360
// 720
// 840
// 1260
// 1680
// 2520
// 5040
// 7560
// 10080
// 15120
// 20160
// 25200
// 27720
// 45360
// 50400
// 55440
// 83160
// 110880
// 166320
// 221760
// 277200
// 332640
// 498960
// 554400
// 665280
// 720720
// 1081080
// 1441440