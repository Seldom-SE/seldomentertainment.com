// hcn_gen.c
// Tom Hansen 2019

#include <stdlib.h>
#include <stdio.h>

void free_2d_array (int** arr, unsigned long long rows) {
    for (unsigned long long i = 0; i < rows; i++)
        free(arr[i]);
    free(arr);
}

int power (int base, int exponent) {
    int power = 1;
    for (int i = 0; i < exponent; i++)
        power *= base;
    return power;
}

// Factorial optimized for tail call optimization
unsigned long long running_factorial (int n, unsigned long long running) {
    if (n == 0)
        return running;
    return running_factorial(n - 1, running * n);
}

unsigned long long factorial (int n) {
    return running_factorial(n, 1);
}

// Slightly optimized prime checker. No need to completely optimize, since primes very rarely need to be generated.
int is_prime(int n) {
    if (n <= 1)
        return 0;
    if (n <= 3) // 2 and 3 are prime
        return 1;

    if (n % 2 == 0 || n % 3 == 0)
        return 0;

    for (int i = 5; i * i <= n; i += 6)
        if (n % i == 0 || n % (i + 2) == 0)
            return 0;

    return 1;
}

int next_prime (int n) {
    while (1)
        if (is_prime(++n))
            break;
    return n;
}

// Numbers as expressed as arrays of powers of primes. Ex 24 = [3, 1]. Convert from array for to int form.
unsigned long evaluate (int* num, int size, int* primes) {
    unsigned long value = 1;
    for (int i = 0; i < size; i++)
        value *= power(primes[i], num[i]);
    return value;
}

// Evaluate as if the two given arrays were appended into one.
unsigned long split_evaluate (int* part_1, int size_1, int* part_2, int size_2, int* primes) {
    unsigned long value = evaluate(part_1, size_1, primes);
    for (int i = 0; i < size_2; i++)
        value *= power(primes[i + size_1], part_2[i]);
    return value;
}

// Count the number of unique factors. From math, we know, given powers of primes p, the number of factors is (p0 + 1)(p1 + 1)...(pn + 1).
int factors (int* num, int size) {
    int factors = 1;
    for (int i = 0; i < size; i++)
        factors *= num[i] + 1;
    return factors;
}

// As above, but given two array, which are treated as one appended.
int split_factors (int* part_1, int size_1, int* part_2, int size_2) {
    return factors(part_1, size_1) * factors(part_2, size_2);
}

int main() {
    // Get number of highly composite numbers to generate
    printf("Enter the number of highly composite numbers that should be generated: ");
    int to_gen;
    scanf("%d", &to_gen);

    // Declare hcn list and initialize primes
    int** hcns = malloc(to_gen * sizeof(int*)); // List of hcns to fill
    int hcns_pfs[to_gen]; // For each hcn, the number of prime factors it has a power greater than 0 for. This should be the size of its list.
    // In general "pfs" stands for prime factors, and represents the size of a list representation of a number.

    // Primes. The first three are hardcoded, because the first two are necessary to represent the first 7 hcns.
    // The third prime is hardcoded because the program assumes there is always an extra, yet unused prime, so that it never has generate one on the fly.
    // Better to have it generated beforehand.
    int num_primes = 3;
    int* primes = malloc(num_primes * sizeof(int));
    primes[0] = 2;
    primes[1] = 3;
    primes[2] = 5;

    // The earlier hcns are very unpredictable in behavior, and the algorithm would be much less efficient if it had to account for them.
    // So, the first 7 are hardcoded.
    hcns[0] = (int*) malloc(sizeof(int));
    hcns[0][0] = 0;
    hcns_pfs[0] = 1;

    hcns[1] = (int*) malloc(sizeof(int));
    hcns[1][0] = 1;
    hcns_pfs[1] = 1;

    hcns[2] = (int*) malloc(sizeof(int));
    hcns[2][0] = 2;
    hcns_pfs[2] = 1;

    hcns[3] = (int*) malloc(2 * sizeof(int));
    hcns[3][0] = 1;
    hcns[3][1] = 1;
    hcns_pfs[3] = 2;

    hcns[4] = (int*) malloc(2 * sizeof(int));
    hcns[4][0] = 2;
    hcns[4][1] = 1;
    hcns_pfs[4] = 2;

    hcns[5] = (int*) malloc(2 * sizeof(int));
    hcns[5][0] = 3;
    hcns[5][1] = 1;
    hcns_pfs[5] = 2;

    // This is the last hcn whose last prime factor's power is not 1
    hcns[6] = (int*) malloc(2 * sizeof(int));
    hcns[6][0] = 2;
    hcns[6][1] = 2;
    hcns_pfs[6] = 2;

    // Generate hcns
    for (int i = 7; i < to_gen; i++) {
        printf("GENERATING HCN NUMBER %d\n", i + 1);

        // Separate the previous hcn into a variable part and static part
        // The variable part is all of the primes whose powers are greater than 1, and the two 1s afterward
        // These primes (and by that, I mean their exponents) are known to change in value
        // The rest of the prime factors are of the static part, which never change in value, except for gaining or losing a prime on the end
        // The objective of this section is to count the number of primes in the variable part, and the number in the static part.
        int var_pfs = -1; // Size of the variable part
        int count_1 = 0; // The number of 1s that have showed up so far
        for (int j = 0; j < hcns_pfs[i - 1]; j++) { // For every prime in the previous hcn
            if (hcns[i - 1][j] == 1)
                count_1++;
            if (count_1 == 2) { // Once we have seen 2 1s, the variable part has ended
                var_pfs = j;
                break;
            }
        }
        if (var_pfs == -1) // If this is still -1, the loop ended before finding 2 1s
            var_pfs = hcns_pfs[i - 1]; // So, the whole thing is the variable part
        int stat_pfs = hcns_pfs[i - 1] - var_pfs; // The rest of the number is static. Static pfs = pfs - variable pfs.

        // Now, let's copy the previous hcn into 2 separate arrays representing the variable and static parts, for convenience
        int prev_var_part[var_pfs];
        int prev_stat_part[stat_pfs];

        // Copy values into respective parts
        for (int j = 0; j < hcns_pfs[i - 1]; j++) {
            if (j < var_pfs) // Earlier primes
                prev_var_part[j] = hcns[i - 1][j];
            else // Later primes
                prev_stat_part[j - var_pfs] = hcns[i - 1][j];
        }

        // Generate list of all potential variable parts for the new hcn
        // We know that the variable part is non-increasing
        // Otherwise, we could swap two primes and create a lesser number with the same number of factors
        // We know that the first prime is the greatest, and it can increase more, so we need to account for variations in that number
        // So, let's generate a list of all numbers whose primes' exponents do not increase and are capped at a certain amount above the last's greatest
        const int PRECISION = 3; // That cap is this many above.
        // If you decrease that value, the numbers will be inaccurate
        // If you increase it, the algorithm will have to check more values, and it will overflow earlier
        // By trial and error, we know the exponent doesn't increase by more than a factor of 3.
        unsigned long long num_ptl_var_parts = factorial(prev_var_part[0] + PRECISION + var_pfs - 1)
                    / factorial(prev_var_part[0] + PRECISION - 1) / factorial(var_pfs); // Number of values to generate
        // We know how many values to generate because it follows the formula for n-dimensional triangular numbers, which are based on combinations
        // This will overflow once the value get high enough.
        int** ptl_var_parts = (int**) malloc(num_ptl_var_parts * sizeof(int*)); // List of potential variable parts
        int ptl_var_part[var_pfs]; // Current
        for (int j = 0; j < var_pfs; j++)
            ptl_var_part[j] = prev_var_part[0] + PRECISION; // We initialize the list with the greatest possible value and count down
        for (int j = 0; j < num_ptl_var_parts; j++) {
            ptl_var_parts[j] = (int*) malloc(var_pfs * sizeof(int));
            for (int k = 0; k < var_pfs; k++) // Add current potential variable part to the list
                ptl_var_parts[j][k] = ptl_var_part[k];
            // Generate the next potential variable part
            // We are counting down, so once a prime's power reaches 1, we need to 'round'.
            // Ex: [3, 3, 1, 1] -> [3, 2, 2, 2]
            for (int k = var_pfs - 1; k >= 0; k--) { // Iterate from the last power
                if (ptl_var_part[k] == 1) // If this power is 1, then we need to look at the previous one and try to round
                    continue;
                ptl_var_part[k] -= 1; // Once we find a power that is greater than 1, decrement it
                for (int l = k + 1; l < var_pfs; l++) // Carry to all of the powers after this one
                    ptl_var_part[l] = ptl_var_part[k]; // Then, the max value of the rest of the powers is that decremented value since it's non-increasing
                break;
            }
        }

        // Generate the potential static parts
        // The static part can only change in two ways: gain a prime or lose a prime
        // Since the powers are all 1, this is easy to generate
        int** ptl_stat_parts = (int**) malloc(3 * sizeof(int*)); // Potential static parts
        // Static part loses a prime
        ptl_stat_parts[0] = (int*) malloc((stat_pfs - 1) * sizeof(int));
        for (int j = 0; j < stat_pfs - 1; j++)
            ptl_stat_parts[0][j] = 1;
        // Static part doesn't change
        ptl_stat_parts[1] = (int*) malloc(stat_pfs * sizeof(int));
        for (int j = 0; j < stat_pfs; j++)
            ptl_stat_parts[1][j] = 1;
        // Static part gains a prime
        ptl_stat_parts[2] = (int*) malloc((stat_pfs + 1) * sizeof(int));
        for (int j = 0; j < stat_pfs + 1; j++)
            ptl_stat_parts[2][j] = 1;
        
        // Generate list of all potential hcns
        // This is done by finding every combination of variable and static parts, and checking whether it's an eligible hcn
        // The number is eligible if it (1) has more factors than the previous, and it (2) is greater than previous hcn
        // We also know that this hcn will be at most twice the size of the previous
        // (2) is actually not strictly necessary, but it is an important shortcut
        int** ptl_hcns = (int**) malloc(0); // Potential hcns
        int** old_ptl_hcns; // We don't know how many potential hcns there are, so this is used to hold the values while the list resizes
        int num_ptl_hcns = 0; // Number of potential hcns
        int* ptl_hcns_pfs = (int*) malloc(0); // Parallel list to ptl_hcns. Represents the number of prime factors in each element of ptl_hcns.
        int* old_ptl_hcns_pfs; // Used to resize ptl_hcns_pfs
        int min_factors = factors(hcns[i - 1], hcns_pfs[i - 1]);
        long min_val = evaluate(hcns[i - 1], hcns_pfs[i - 1], primes);
        long max_val = min_val * 2;
        for (int j = 0; j < 3; j++) { // For each static part. We can use j - 1 as the change in the number of prime factors.
            if (stat_pfs + j == 0) // Skip if the static part is of a negative size. This happens when a static part of 0 size decreases in length.
                continue;
            for (int k = 0; k < num_ptl_var_parts; k++) { // For each variable part
                int ptl_hcn_factors = split_factors(ptl_var_parts[k], var_pfs, ptl_stat_parts[j], stat_pfs + j - 1); // Number of factors
                if (ptl_hcn_factors <= min_factors) // We know it's not an hcn if it doesn't have more factors than the last
                    continue;
                long ptl_hcn_val = split_evaluate(ptl_var_parts[k], var_pfs, ptl_stat_parts[j], stat_pfs + j - 1, primes); // Value
                if (ptl_hcn_val <= min_val || ptl_hcn_val > max_val) // We know it's not a new hcn if it's less than or equal the last, of more than twice
                    continue;
                // We have found a potential hcn!
                num_ptl_hcns += 1;
                // Increase the size of the lists by 1
                old_ptl_hcns = ptl_hcns;
                old_ptl_hcns_pfs = ptl_hcns_pfs;
                ptl_hcns = (int**) malloc(num_ptl_hcns * sizeof(int*));
                ptl_hcns_pfs = (int*) malloc(num_ptl_hcns * sizeof(int*));
                for (int l = 0; l < num_ptl_hcns - 1; l++) {
                    ptl_hcns[l] = old_ptl_hcns[l];
                    ptl_hcns_pfs[l] = old_ptl_hcns_pfs[l];
                }
                free(old_ptl_hcns);
                free(old_ptl_hcns_pfs);
                ptl_hcns_pfs[num_ptl_hcns - 1] = var_pfs + stat_pfs + j - 1; // Size of potential hcn
                ptl_hcns[num_ptl_hcns - 1] = (int*) malloc(ptl_hcns_pfs[num_ptl_hcns - 1] * sizeof(int)); // Potential hcn
                for (int l = 0; l < var_pfs; l++) { // Copy in variable part
                    ptl_hcns[num_ptl_hcns - 1][l] = ptl_var_parts[k][l];
                }
                for (int l = 0; l < stat_pfs + j - 1; l++) { // Copy in static part
                    ptl_hcns[num_ptl_hcns - 1][var_pfs + l] = ptl_stat_parts[j][l];
                }
            }
        }

        // We don't need the potential variable parts and static parts anymore.
        free_2d_array(ptl_var_parts, num_ptl_var_parts);
        free_2d_array(ptl_stat_parts, 3);

        // Find the hcn!
        // These all qualify for hcn, because they have more factors than the previous
        // So, the actual hcn is the one with the smallest value
        int hcn_i = 0; // Index in ptl_hcns of current smallest
        int hcn_pfs = ptl_hcns_pfs[0]; // Number of prime factors of the smallest
        unsigned long hcn_val = evaluate(ptl_hcns[0], hcn_pfs, primes); // Its value
        for (int j = 1; j < num_ptl_hcns; j++) { // For every potential hcn
            int ptl_hcn_size = ptl_hcns_pfs[j];
            unsigned long ptl_hcn_val = evaluate(ptl_hcns[j], ptl_hcn_size, primes);
            if (ptl_hcn_val > hcn_val) // If it's greater in value, then it's not a valid hcn
                continue;
            // We've found a better hcn!
            hcn_i = j;
            hcn_pfs = ptl_hcn_size;
            hcn_val = ptl_hcn_val;
        }

        // Add the hcn to the list
        hcns[i] = (int*) malloc(hcn_pfs * sizeof(int));
        for (int j = 0; j < hcn_pfs; j++)
            hcns[i][j] = ptl_hcns[hcn_i][j];
        hcns_pfs[i] = hcn_pfs;

        // The hcn has been generated. We don't need the values of the potential hcns anymore.
        free_2d_array(ptl_hcns, num_ptl_hcns);
        free(ptl_hcns_pfs);

        // If the new hcn has as many primes as we've generated so far, we need to generate a new prime as a buffer.
        if (num_primes <= hcn_pfs) {
            num_primes += 1;
            // Make the list longer by 1
            int* old_primes = primes;
            primes = (int*) malloc(num_primes * sizeof(int));
            for (int j = 0; j < num_primes - 1; j++)
                primes[j] = old_primes[j];
            free(old_primes);
            primes[num_primes - 1] = next_prime(primes[num_primes - 2]); // Generate the next prime!
        }
    }

    // Print the hcns
    for (int i = 0; i < to_gen; i++)
        printf("%lu\n", evaluate(hcns[i], hcns_pfs[i], primes));

    // Delete the hcns and primes
    free_2d_array(hcns, to_gen);
    free(primes);
}