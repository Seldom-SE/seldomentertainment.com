% hcn_gen.pl
% Tom Hansen 2019

% Example:
% ?- generate_hcns(20, H).

divisible_over(A, B) :-
    0 =:= A mod B,
    !.
divisible_over(A, B) :-
    A > B + 1,
    divisible_over(A, B + 1).

composite(A) :-
    divisible_over(A, 2).

prime(A) :-
    not(composite(A)).

next_prime(A, P) :-
	P is A + 1,
    prime(P),
    !.
next_prime(A, P) :-
    A0 is A + 1,
    next_prime(A0, P).

first_n_primes_rev(1, [2]).
first_n_primes_rev(N, [PH | PT]) :-
    N > 1,
    PT = [PTH | _],
    N0 is N - 1,
    first_n_primes_rev(N0, PT),
    next_prime(PTH, PH).

first_n_primes(N, P) :-
    first_n_primes_rev(N, R),
    reverse(R, P).

evaluate([], 1, _).
evaluate([H | T], A, [PH | PT]) :-
    evaluate(T, A0, PT),
    A is PH ^ H * A0.

evaluate_all([], [], _).
evaluate_all([H | T], [VH | VT], P) :-
    evaluate(H, VH, P),
    evaluate_all(T, VT, P).

least([A], A, _).
least([H | T], L, P) :-
    least(T, L0, P),
    evaluate(H, HV, P),
    evaluate(L0, L0V, P),
    (	L0V =< HV
    ->  L = L0
    ;   L = H
   	).

factors([], 1).
factors([H | T], F) :-
    factors(T, F0),
    F is (H + 1) * F0.

split_last([], [], []).
split_last([1 | T], [1], T).

split([], [], []).
split([1 | T], V, S) :-
    split_last(T, V0, S),
    append([1], V0, V).
split([H | T], V, S) :-
    H \= 1,
    split(T, V0, S),
	append([H], V0, V).

fill([], 0, _).
fill([A | T], S, A) :-
    S > 0,
    S0 is S - 1,
    fill(T, S0, A).

non_increasing_decrement([A0], [A1], 0, _) :-
    A0 > 1,
    A1 is A0 - 1.
non_increasing_decrement([1], [UV], 1, UV).
non_increasing_decrement([H0 | T0], [H0 | T1], 0, _) :-
    NUV is H0 - 1,
    non_increasing_decrement(T0, T1, 0, NUV).
non_increasing_decrement([H0 | T0], [H1 | T1], 0, _) :-
    H0 > 1,
    NUV is H0 - 1,
    non_increasing_decrement(T0, T1, 1, NUV),
    H1 is H0 - 1.
non_increasing_decrement([1 | T0], [UV | T1], 1, UV) :-
    non_increasing_decrement(T0, T1, 1, UV).

next_variable_parts(V0, [V | T]) :-
    non_increasing_decrement(V0, V, 0, 1),
    next_variable_parts(V, T).
next_variable_parts(V0, []) :-
    non_increasing_decrement(V0, _, 1, 1).

variable_parts_from([VH | VT], S, M) :-
    fill(VH, S, M),
    next_variable_parts(VH, VT).

variable_parts_from(L, V) :-
    length(L, S),
    L = [H | _],
    M is H + 3,
    variable_parts_from(V, S, M).
    
static_parts_from([], [[], [1]]).
static_parts_from(L, S) :-
    append(LD, [1], L),
    append(L, [1], LI),
    S = [LD, L, LI].

potential_hcns([], [], [_ | []], _, _).
potential_hcns(H, [], [_ | ST], F, VC) :-
    potential_hcns(H, VC, ST, F, VC).
potential_hcns([HH | HT], [VH | VT], S, F, VC) :-
    S = [SH | _],
    append(VH, SH, HH),
    factors(HH, HF),
    HF > F,
    potential_hcns(HT, VT, S, F, VC).
potential_hcns(H, [VH | VT], S, F, VC) :-
    S = [SH | _],
    append(VH, SH, PHH),
    factors(PHH, HF),
    HF =< F,
    potential_hcns(H, VT, S, F, VC).
    
next_hcn(P, H, PM) :-
    length(P, N),
    N0 is N + 1,
    first_n_primes(N0, PM),
    factors(P, F),
    split(P, V, S),
    variable_parts_from(V, PV),
    static_parts_from(S, PS),
    potential_hcns(PH, PV, PS, F, PV),
    least(PH, H, PM).
    
first_n_hcns(7, [[2, 2], [3, 1], [2, 1], [1, 1], [2], [1], []], [2, 3]).
first_n_hcns(N, H, P) :-
    N > 7,
    N0 is N - 1,
    first_n_hcns(N0, H0, PO),
    H0 = [H0H | _],
    next_hcn(H0H, NH, PN),
    length(PO, POL),
    length(PN, PNL),
    (	POL > PNL
    ->  P = PO
    ;   P = PN
   	),
    H = [NH | H0].
    
% Run this
generate_hcns(N, H) :-
    first_n_hcns(N, H0, P),
    reverse(H0, H1),
    evaluate_all(H1, H, P).