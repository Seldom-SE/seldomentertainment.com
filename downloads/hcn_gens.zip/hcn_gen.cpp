// hcn_gen.cpp
// Tom Hansen 2019-2020

#include <iostream>
#include <vector>
#include <initializer_list>
#include <tuple>

#define PRECISION 3

unsigned long power (int, int);
unsigned long long factorial (int);
unsigned long long divide_factorials (int, int);

class Primes {
    private:
        inline static std::vector<int> primes;

    public:
        static void init () {
            primes.push_back(2);
            primes.push_back(3);
            primes.push_back(5);
        }

        static bool is_prime (int n) {
            if (n <= 1)
                return false;
            if (n <= 3)
                return true;

            if (n % 2 == 0 || n % 3 == 0)
                return false;

            for (int i = 5; i * i <= n; i += 6)
                if (n % i == 0 || n % (i + 2) == 0)
                    return false;

            return true;
        }

        static int next_prime (int n) {
            while (true)
                if (is_prime(++n))
                    break;
            return n;
        }

        static int get_prime (int i) {
            if (i >= primes.size()) {
                primes.push_back(next_prime(primes.at(i - 1)));
            }
            return primes.at(i);
        }
};

class Number {
    private:
        int* powers;
        int prime_factors;

        int get_static_index () {
            bool found1 = false;
            for (int i = 0; i < prime_factors; i++)
                if (powers[i] == 1) {
                    if (found1)
                        return i + 1;
                    else
                        found1 = true;
                }
            return prime_factors;
        }

        std::tuple<Number*, Number*> split (int index) {
            int* powers1 = new int[index];
            int* powers2 = new int[prime_factors - index];
            for (int i = 0; i < index; i++)
                powers1[i] = powers[i];
            for (int i = 0; i < prime_factors - index; i++)
                powers2[i] = powers[index + i];
            return std::make_tuple(new Number(powers1, index), new Number(powers2, prime_factors - index));
        }

    public:
        Number (Number &number) {
            prime_factors = number.get_prime_factors();
            powers = new int[prime_factors];
            for (int i = 0; i < prime_factors; i++)
                powers[i] = number.get_power(i);
        }

        Number (int fill, int prime_factors) {
            this->prime_factors = prime_factors;
            powers = new int[this->prime_factors];
            for (int i = 0; i < prime_factors; i++)
                powers[i] = fill;
        }

        Number (int powers[], int prime_factors) {
            this->prime_factors = prime_factors;
            this->powers = powers;
        }

        Number (std::initializer_list<int> powers) {
            prime_factors = static_cast<int>(powers.size());
            this->powers = new int[this->prime_factors];
            int i = 0;
            for (int power : powers)
                this->powers[i++] = power;
        }

        Number (Number* part1, Number* part2) {
            prime_factors = part1->get_prime_factors() + part2->get_prime_factors();
            powers = new int[prime_factors];
            for (int i = 0; i < part1->get_prime_factors(); i++)
                powers[i] = part1->get_power(i);
            for (int i = 0; i < part2->get_prime_factors(); i++)
                powers[part1->get_prime_factors() + i] = part2->get_power(i);
        }

        int get_power_of_2 () {
            return powers[0];
        }

        int get_power (int power) {
            return powers[power];
        }

        int get_prime_factors () {
            return prime_factors;
        }

        int get_factors () {
            int factors = 1;
            for (int i = 0; i < prime_factors; i++)
                factors *= powers[i] + 1;
            return factors;
        }

        unsigned long evaluate () {
            unsigned long val = 1;
            for (int i = 0; i < prime_factors; i++) {
                val *= power(Primes::get_prime(i), powers[i]);
            }
            return val;
        }

        std::tuple<Number*, Number*> get_parts () {
            return split(get_static_index());
        }

        int next_potentials () {
            return divide_factorials(powers[0] + PRECISION + prime_factors - 1, powers[0] + PRECISION - 1) / factorial(prime_factors);
        }

        void decrement () {
            for (int i = prime_factors - 1; i >= 0; i--) {
                if (powers[i] == 1)
                    continue;
                powers[i] -= 1;
                for (int j = i + 1; j < prime_factors; j++)
                    powers[j] = powers[i];
                break;
            }
        }

        ~Number () {
            delete powers;
        }
};

class NumberList {
    private:
        Number** numbers;
        int size;
        int curr;

    public:
        NumberList (int size) {
            numbers = new Number*[size];
            this->size = size;
            curr = 0;
        }

        int get_size () {
            return size;
        }

        int get_curr () {
            return curr;
        }

        Number* get_number (int i) {
            return numbers[i];
        }

        void add (Number* number) {
            numbers[curr++] = number;
        }

        void add (std::initializer_list<int> powers) {
            numbers[curr++] = new Number(powers);
        }

        bool full () {
            return curr == size;
        }

        int get_prev_factors () {
            return numbers[curr - 1]->get_factors();
        }

        unsigned long get_prev_val () {
            return numbers[curr - 1]->evaluate();
        }

        std::tuple<Number*, Number*> get_prev_parts () {
            return numbers[curr - 1]->get_parts();
        }

        Number* smallest () {
            Number* smallest = numbers[0];
            unsigned long smallest_val = smallest->evaluate();
            for (int i = 1; i < curr; i++) {
                unsigned long val = numbers[i]->evaluate();
                if (val > smallest_val)
                    continue;
                smallest = numbers[i];
                smallest_val = val;
            }
            return smallest;
        }

        void from_variable_part (Number* variable_part) {
            Number potential_variable_part(variable_part->get_power_of_2() + PRECISION, variable_part->get_prime_factors());
            while (!full()) {
                add(new Number(potential_variable_part));
                potential_variable_part.decrement();
            }
        }

        void from_static_part (Number* static_part) {
            if (static_part->get_prime_factors() - 1 >= 0)
                add(new Number(1, static_part->get_prime_factors() - 1));
            else
                add(new Number(1, static_part->get_prime_factors()));
            add(new Number(1, static_part->get_prime_factors()));
            add(new Number(1, static_part->get_prime_factors() + 1));
        }

        void from_parts (NumberList* variable_parts, NumberList* static_parts, int prev_factors, unsigned long prev_val) {
            for (int i = 0; i < static_parts->get_size(); i++)
                for (int j = 0; j < variable_parts->get_size(); j++) {
                    Number* candidate = new Number(variable_parts->get_number(j), static_parts->get_number(i));
                    if (candidate->get_factors() <= prev_factors) {
                        delete candidate;
                        continue;
                    }
                    unsigned long candidate_val = candidate->evaluate();
                    if (candidate_val <= prev_val || candidate_val > 2 * prev_val) {
                        delete candidate;
                        continue;
                    }
                    add(candidate);
                }
        }

        void print () {
            for (int i = 0; i < curr; i++)
                std::cout << numbers[i]->evaluate() << std::endl;
        }

        ~NumberList () {
            delete[] numbers;
        }
};

unsigned long power (int base, int exponent) {
    int power = 1;
    for (int i = 0; i < exponent; i++)
        power *= base;
    return power;
}

unsigned long long factorial (int n) {
    if (n == 0)
        return 1;
    return n * factorial(n - 1);
}

unsigned long long divide_factorials (int n, int m) {
    if (n == m)
        return 1;
    return n * divide_factorials(n - 1, m);
}

int main () {
    std::cout << "Enter the number of highly composite numbers that should be generated: ";
    int to_gen;
    std::cin >> to_gen;

    NumberList hcns(to_gen);
    Primes::init();

    hcns.add({0});
    hcns.add({1});
    hcns.add({2});
    hcns.add({1, 1});
    hcns.add({2, 1});
    hcns.add({3, 1});
    hcns.add({2, 2});

    while (!hcns.full()) {
        std::cout << "Generating HCN number " << hcns.get_curr() << std::endl;

        std::tuple<Number*, Number*> parts = hcns.get_prev_parts();
        Number* variable_part = std::get<0>(parts);
        Number* static_part = std::get<1>(parts);

        NumberList potential_variable_parts(variable_part->next_potentials());
        potential_variable_parts.from_variable_part(variable_part);

        NumberList potential_static_parts(3);
        potential_static_parts.from_static_part(static_part);

        NumberList potential_hcns(potential_variable_parts.get_size() * 3);
        potential_hcns.from_parts(&potential_variable_parts, &potential_static_parts, hcns.get_prev_factors(), hcns.get_prev_val());

        hcns.add(new Number(*potential_hcns.smallest()));
    }

    hcns.print();
}