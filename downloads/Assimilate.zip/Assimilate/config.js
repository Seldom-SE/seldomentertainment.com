//this is the config file.
var config = {
    circleRadius: 30,
    numCircles: 50,
    baseStats: {
        strength: 0.02,
        regen: 0.005,
        speed: 1
    },
    stats: {//all these values are in percent (of the base stats)
        red: {
            strength: 100,
            regen: 50,
            speed: 50
        },
        green: {
            strength: 50,
            regen: 100,
            speed: 50
        },
        blue: {
            strength: 50,
            regen: 50,
            speed: 100
        }
    },
    gameWidth: 1500,
    gameHeight: 700
};