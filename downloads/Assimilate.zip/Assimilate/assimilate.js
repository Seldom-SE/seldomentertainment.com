var canvas;
var context;
var circles = [];
//var config.circleRadius = 30;
var gameWidth = 1500;
var gameHeight = 700;
var paused = false;

//default config values
var config = config || {};

var defaultConfig = {
    circleRadius: 30,
    numCircles: 50,
    baseStats: {
        strength: 0.02,
        regen: 0.005,
        speed: 1
    },
    stats: {//all these values are in percent (of the base stats)
        red: {
            strength: 100,
            regen: 50,
            speed: 50
        },
        green: {
            strength: 50,
            regen: 100,
            speed: 50
        },
        blue: {
            strength: 50,
            regen: 50,
            speed: 100
        }
    },
    gameWidth: 1500,
    gameHeight: 700
};

(function checkConfig (defaultCfg, cfg) {
    for(var i in defaultCfg) {
        if(defaultCfg[i] instanceof Object) {
            cfg[i] = cfg[i] || {};
            checkConfig(defaultCfg[i], cfg[i]);
        } else if(!cfg[i]) {
            cfg[i] = defaultCfg[i];
        }
    }
})(defaultConfig, config);

var colorEnums = {
    RED: {name: 'red', RGBPercent: [1, 0, 0]},
    YELLOW: {name: 'yellow', RGBPercent: [0.5, 0.5, 0]},//dark green
    GREEN: {name: 'green', RGBPercent: [0, 1, 0]},
    CYAN: {name: 'cyan', RGBPercent: [0, 0.5, 0.5]},//turquoise
    BLUE: {name: 'blue', RGBPercent: [0, 0, 1]},
    MAGENTA: {name: 'magenta', RGBPercent: [0.5, 0, 0.5]}//purple
};
var mouse = {
    x: 0,
    y: 0
};

var Circle = function(colType, x, y) {
    this.color = [colType.RGBPercent[0], colType.RGBPercent[1], colType.RGBPercent[2]];
    this.x = x;
    this.y = y;
    this.colliding = false;
    this.colorType = colType;
};

Circle.prototype.move = function(xAmnt, yAmnt) {
    this.x += xAmnt;
    this.y += yAmnt;
    
    if(this.x - config.circleRadius < 0) {
        this.x = config.circleRadius;
    }
    if(this.x + config.circleRadius > gameWidth) {
        this.x = gameWidth - config.circleRadius;
    }
    if(this.y - config.circleRadius < 0) {
        this.y = config.circleRadius;
    }
    if(this.y + config.circleRadius > gameHeight) {
        this.y = gameHeight - config.circleRadius;
    }
};

Circle.prototype.update = function() {
    //check for collision
    this.colliding = false;
    for(var i in circles) {
        var circle = circles[i];
        if(circle === this) continue;
        var dist = getDist(this.x, this.y, circle.x, circle.y);
        if(dist < 2 * config.circleRadius) {
            //the circles are colliding
            var ang = Math.atan((this.y - circle.y) / (this.x - circle.x));
            if(this.x >= circle.x) ang += Math.PI;
            var mag = 2 * config.circleRadius - dist;
            this.move(-mag * Math.cos(ang), -mag * Math.sin(ang));
//            this.x -= mag * Math.cos(ang);
//            this.y -= mag * Math.sin(ang);
            this.colliding = true;
            
//            continue; 
            var myColor = this.color;
            var hisColor = circle.color;
//            var myChange = [0, 0, 0];
            var hisChange = [0, 0, 0];
            for(var j in myColor) {
                var strength = this.getStat('strength');
                var dist = hisColor[j] - myColor[j];
//                var amount = /*this.color[0] * 0.5*/0.01;
                if(dist < 0) {
                    strength = -strength;
                }
                if(Math.abs(dist) < Math.abs(strength)) {
                    strength = dist;
                }
                hisChange[j] -= strength;
            }
//            this.changeColor(myChange);
            circle.changeColor(hisChange);
        }
    }
    
    //move
    if(this.x !== mouse.x && this.y !== mouse.y/* && circles.indexOf(this) === 0*/) {
           var speed = this.getStat('speed');
//           console.log(speed);
           var xdir = (mouse.x > this.x) ? speed : -speed;
           var ydir = (mouse.y > this.y) ? speed : -speed;
           this.move(xdir, ydir);
    }
    
    //regenerate
    //amount is based off of green value. More green = regenerate (all colors) more
    for(var i in this.color) {
        var regen = this.getStat('regen');
        var dist = this.colorType.RGBPercent[i] - this.color[i];
        if(dist < 0) {
            regen = -regen;
        }
        if(Math.abs(dist) < Math.abs(regen)) {
            regen = dist;
        }

        this.color[i] += regen;
    }
//    console.log(this.color);
};

//returns the value of a stat. It calculates the percentages for each color, finds
//the average of the percentages to get total percent, and multiplies that by the
//base stat.
Circle.prototype.getStat = function(stat) {
    var colorNames = ['red', 'green', 'blue'];
    var totalPercent = 0;
    for(var i = 0; i < colorNames.length; i++) {
        var colorName = colorNames[i];
        //divide by 100 cuz config stats are in percent
        totalPercent += config.stats[colorName][stat] / 100 * this.color[i];
    }
    return totalPercent /*/ colorNames.length*/ * config.baseStats[stat];
};

function getColor(percents) {
//	var numColors = 0;
//	for(var i in this.color) {
//		if(this.color[i] > 0) {
//			numColors++;
//		}
//	}
//	
//	if(numColors === 0) {
//		return 'rgb(0,0,0)';
//	}
//	
//	var values = [];
//	for(var i in this.color) {
//		if(this.color[i] < 1/numColors) {
//			values[i] = Math.round(255*numColors*this.color[i]);
//		} else {
//			values[i] = 255;
//		}
//	}
//	
//	return 'rgb(' + values.join(', ') + ")";
    var rgbValue = [];
    for(var i in percents) {
        rgbValue[i] = Math.round(255 * percents[i]);
    }
    
    return 'rgb(' + rgbValue.join(', ') + ")";
};

Circle.prototype.draw = function() {
    context.beginPath();
    context.arc(this.x, this.y, config.circleRadius, 0, 2 * Math.PI);
    context.closePath();
    context.fillStyle = getColor(this.color);
    context.fill();
    context.strokeStyle = getColor(this.colorType.RGBPercent);
    context.lineWidth = 0.15 * config.circleRadius;
    context.stroke();
};

Circle.prototype.changeColor = function(changeAmount) {
    //change the color:
    //TODO: This allows for the colors to go over 100%, and to have negative color.
    
    for(var i in changeAmount) {
        this.color[i] += changeAmount[i];
    }
    
    //recalculate type:
    
    //this is the array we sort to find which color(s) is highest
    var sortedColors = [];
    for(var i = 0; i < this.color.length; i++) {
        sortedColors[i] = i;
    }
    //go through array
    for(var i = 0; i < sortedColors.length - 1; i++) {
        //compare it to the rest of the array
        for(var j = i + 1; j < sortedColors.length; j++ ) {
            if(this.color[sortedColors[i]] < this.color[sortedColors[j]]) {
                //switch color if latter is smaller than former (sort in descending order)
                var temp = sortedColors[i];
                sortedColors[i] = sortedColors[j];
                sortedColors[j] = temp;
            }
        }
    }
    
    var first = sortedColors[0];
    var second = sortedColors[1];
    var third = sortedColors[2];
    this.colorType = null;
    //array to find matched enum
    var newColorType = [0, 0, 0];
    //if distance > average
    if(this.color[first] - this.color[second] > (this.color[first] + this.color[second]) / 2) {
        newColorType[first] = 1;
    } else {
        newColorType[first] = 0.5;
        newColorType[second] = 0.5;
    }
    
    for(var i in colorEnums) {
        //compare arrays with looping cuz == doesn't work with arrays
        for(var j = 0; j < newColorType.length; j++) {
//            console.log(colorEnums[i].RGBPercent[j] !== newColorType[j]);
            if(colorEnums[i].RGBPercent[j] !== newColorType[j]) {
//                j = newColorType.length;
                break;
            }
//            //all values are equal
            if(j === newColorType.length - 1) {
                this.colorType = colorEnums[i];
                return;
            }
        }
    }
    
    //red if no matching type
    if(this.colorType === null) {
        this.colorType = colorEnums.RED;
    }
};

function sortArray(arr) {
    var sortedColors = [];
    for(var i in arr) {
        sortedColors[i] = i;
    }
    //go through array
    for(var i = 0; i < sortedColors.length - 1; i++) {
        //compare it to the rest of the array
        for(var j = i + 1; j < sortedColors.length; j++ ) {
            if(this.color[sortedColors[i]] < this.color[sortedColors[j]]) {
                //switch color if latter is smaller than former (sort in descending order)
                var temp = sortedColors[i];
                sortedColors[i] = sortedColors[j];
                sortedColors[j] = temp;
            }
        }
    }
    return index;
}

function getDist(x1, y1, x2, y2) {
    return Math.sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
}

function getRandInt(min, max) {
  return Math.floor(Math.random() * (max + 1 - min)) + min;
}

function getRandCircle() {
    var colorChoices = ['RED','YELLOW','GREEN','CYAN','BLUE','MAGENTA'];
    var enumColor = colorEnums[colorChoices[getRandInt(0, colorChoices.length - 1)]];
    //clone enum
    var rgbPercent = [];
    for(var i in enumColor.RGBPercent) {
        rgbPercent[i] = enumColor.RGBPercent[i];
    }
    circleColor = {name: enumColor.name, RGBPercent: rgbPercent};
    //make circle
    return new Circle(circleColor, gameWidth * Math.random(), gameHeight * Math.random());
}

function start() {
    canvas = document.getElementById('game-canvas');
    canvas.width = config.gameWidth;
    canvas.height = config.gameHeight;
    context = canvas.getContext('2d');
    window.requestAnimationFrame(update);
    
//    var stillCirc = new Circle([0,0,0], 700, 300);
//    circles.push(stillCirc);
    
    for(var i = 0; i < config.numCircles; i++) {
        circles.push(getRandCircle());
    }
        
    for(var i in circles) {
        circles[i].move(0,0);
    }
};

function update() {
    if(paused) {
        window.requestAnimationFrame(update);
        return;
    }
    context.fillStyle = 'rgb(127, 127, 127)';
    context.fillRect(0, 0, gameWidth, gameHeight);
    for(var i in circles) {
        var circle = circles[i];
        circle.draw();
        circle.update();
    }
    
    window.requestAnimationFrame(update);
}

document.addEventListener('mousemove', function(event) {
    mouse.x = event.pageX - canvas.offsetLeft;
    mouse.y = event.pageY - canvas.offsetTop;
});

document.addEventListener('DOMContentLoaded', start);

function test() {
    for(var j = 0; j < 10; j++) {
        console.log(j);
        for(var i = 0; i < 10; i++) {
            console.log(i);
            if(true) {
                break;
            }
        }
    }
}

//dummy circles never spawned into world for test purposes.
var redCircle = new Circle(colorEnums.RED, 0, 0);
var yellowCircle = new Circle(colorEnums.YELLOW, 0, 0);
var greenCircle = new Circle(colorEnums.GREEN, 0, 0);
var cyanCircle = new Circle(colorEnums.CYAN, 0, 0);
var blueCircle = new Circle(colorEnums.BLUE, 0, 0);
var magentaCircle = new Circle(colorEnums.MAGENTA, 0, 0);