# cthulhu.py by sage 2018

# Cthulhu v1.0 by sage 2018
# Some notes:
# Construction is faster with more barracks in the world
# Only 21 barracks may be cosntructed
# You can only construct adjacent to barracks and roads
# Drills can only be constructed on top of stone
# You can only construct twice the number of turrets as you have drills
# Enemies are attracted to visible tiles
# You'll know when the game's over - you'll know for sure

import random
import pygame
pygame.init()

DIRT = 0
ROCK = 1
SCORCHED = 2

NOTHING = 0
RADAR = 1
BARRACKS = 2
ROAD = 3
TURRET = 4
DRILL = 5

DIRT_PNG = pygame.image.load("dirt.png")
ROCK_PNG = pygame.image.load("rock.png")
SCORCHED_PNG = pygame.image.load("scorched.png")
NOTHING_PNG = pygame.image.load("nothing.png")
RADAR_PNG = pygame.image.load("radar.png")
BARRACKS_PNG = pygame.image.load("barracks.png")
ROAD_PNG = pygame.image.load("road.png")
TURRET_PNG = pygame.image.load("turret.png")
DRILL_PNG = pygame.image.load("drill.png")
CONSTRUCTION_PNG = pygame.image.load("construction.png")
RADAR_BTN_PNG = pygame.image.load("radar_button.png")
BARRACKS_BTN_PNG = pygame.image.load("barracks_button.png")
ROAD_BTN_PNG = pygame.image.load("road_button.png")
TURRET_BTN_PNG = pygame.image.load("turret_button.png")
DRILL_BTN_PNG = pygame.image.load("drill_button.png")
NOTHING_BTN_PNG = pygame.image.load("nothing_button.png")
WORKER_PNG = pygame.image.load("worker.png")
MINION_PNG = pygame.image.load("minion.png")
RAGOR_PNG = pygame.image.load("ragor.png")
TITLE_SCREEN_PNG = pygame.image.load("title_screen.png")

GROUND_PNGS = [DIRT_PNG, ROCK_PNG, SCORCHED_PNG]
CONSTRUCT_PNGS = [NOTHING_PNG, RADAR_PNG, BARRACKS_PNG, ROAD_PNG, TURRET_PNG, DRILL_PNG]

WORLD_SIZE = 32
RADAR_RANGE = 6

TIMER = 0


class Camera:
    def __init__(self):
        self.x = 176
        self.y = 16
        self.zoom = 14


class World:
    def __init__(self):
        self.world = self.generate()

    def generate(self):
        world = []
        for x in range(0, WORLD_SIZE):
            col = []
            for y in range(0, WORLD_SIZE):
                col.append(Tile(DIRT, NOTHING))
            world.append(col)
        world = self.add_resource(world, ROCK, 3, 2, 0.4, 4)
        first_barracks = Construct(BARRACKS)
        first_barracks.built = True
        first_barracks.inhabitants = 1
        first_barracks.view_range = 1
        world[int(WORLD_SIZE / 2)][int(WORLD_SIZE / 2)].construct = first_barracks
        return world

    def add_resource(self, world, resource, birth_num, death_num, chance, iterations):
        resources = []
        for x in range(0, WORLD_SIZE):
            col = []
            for y in range(0, WORLD_SIZE):
                if random.random() < chance:
                    col.append(True)
                else:
                    col.append(False)
            resources.append(col)
        for i in range(0, iterations):
            resources = self.iterate(resources, birth_num, death_num)
        self.merge(world, resources, resource)
        return world

    def iterate(self, old, birth_num, death_num):
        new = []
        for x in range(0, WORLD_SIZE):
            col = []
            for y in range(0, WORLD_SIZE):
                neighbors = 0
                for dx in range(-1, 2):
                    for dy in range(-1, 2):
                        if not(dx == 0 and dy == 0) and x + dx >= 0 and y + dy >= 0 and x + dx < WORLD_SIZE and y + dy < WORLD_SIZE:
                            if old[x + dx][y + dy]:
                                neighbors += 1
                if old[x][y]:
                    if neighbors < death_num:
                        col.append(False)
                    else:
                        col.append(True)
                else:
                    if neighbors > birth_num:
                        col.append(True)
                    else:
                        col.append(False)
            new.append(col)
        return new

    def merge(self, world, resources, resource):
        for x in range(0, WORLD_SIZE):
            for y in range(0, WORLD_SIZE):
                if not(resources[x][y]):
                    world[x][y] = Tile(resource, NOTHING)


class Tile:
    def __init__(self, ground, construct):
        self.ground = ground
        self.construct = Construct(construct)


class Construct:
    def __init__(self, construct):
        self.construct = construct
        if construct == NOTHING:
            self.built = True
        else:
            self.built = False
        self.view_range = -1
        self.inhabitants = 0
        self.inhabitant_pointer_x = -1
        self.inhabitant_pointer_y = -1
        self.has_built = False
        self.connected_barracks = 0
        if construct == RADAR:
            self.timer = 150
        elif construct == BARRACKS:
            self.timer = 300
        elif construct == ROAD:
            self.timer = 30
        elif construct == TURRET:
            self.timer = 5000
        elif construct == DRILL:
            self.timer = 800
        else:
            self.timer = 0


class Worker:
    def __init__(self, x, y):
        self.x = x
        self.y = y


class Minion:
    def __init__(self, x, y):
        self.x = x
        self.y = y


class Ragor:
    def __init__(self):
        self.x = 0
        self.y = WORLD_SIZE / 2
        self.awake = False


def main():
    screen = pygame.display.set_mode((800, 480))
    pygame.display.set_caption("Cthulhu")

    clock = pygame.time.Clock()

    proceed = False
    running = True

    while not(proceed) and running:
        running, proceed = check_events()

        screen.fill((0, 0, 0))
        display_title_screen(screen)
        pygame.display.flip()
        clock.tick(60)

    camera = Camera()
    world = World()
    visible = []

    minions = []
    workers = []
    ragor = Ragor()

    global TIMER
    spawn_timer = 2560
    worker_coords = (-1, -1)
    inhabitants = 1
    selection = Construct(RADAR)

    while running:
        running, mouse_press = check_events()
        selection = get_selection(mouse_press, selection)
        x_tile_press, y_tile_press = get_mouse_tile(mouse_press, camera)

        place_tile(world, x_tile_press, y_tile_press, visible, selection)

        worker_coords, inhabitants = update_constructs(world, inhabitants)
        fire_turrets(world, minions)
        scorch(world)

        spawn_worker(worker_coords, workers)
        respawn_workers(world, workers)
        despawn_workers(world, workers)

        spawn_timer = update_spawn_timer(spawn_timer)
        spawn_minions(spawn_timer, minions)
        update_minions(minions, visible)

        spawn_ragor(ragor)
        update_ragor(ragor, visible)
        wreck_terrain(ragor, world)

        workers, minions = workers_fight_minions(workers, minions, world)

        visible, l_bound, r_bound, u_bound, d_bound = get_visible(world)
        align_camera(camera, l_bound, r_bound, u_bound, d_bound)

        screen.fill((0, 0, 0))
        display_world(screen, camera, world, visible)
        display_workers(screen, camera, workers)
        display_minions(screen, camera, minions, visible)
        display_ragor(screen, camera, ragor)
        display_ui(screen, selection)
        pygame.display.flip()

        TIMER += 1
        clock.tick(60)


def display_title_screen(screen):
    screen.blit(TITLE_SCREEN_PNG, (0, 0))


def check_events():
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            return False, False
        if event.type == pygame.MOUSEBUTTONUP:
            return True, True
    return True, False


def get_selection(mouse_press, selection):
    if mouse_press:
        x = pygame.mouse.get_pos()[0]
        y = pygame.mouse.get_pos()[1]
        if x >= 624:
            if y > 176 and y < 208:
                return Construct(RADAR)
            if y >= 208 and y < 240:
                return Construct(BARRACKS)
            if y >= 240 and y < 272:
                return Construct(ROAD)
            if y >= 272 and y < 304:
                return Construct(TURRET)
            if y >= 304 and y < 336:
                return Construct(DRILL)
            if y >= 448:
                return Construct(NOTHING)
    return Construct(selection.construct)


def get_mouse_tile(mouse_press, camera):
    if mouse_press:
        x = pygame.mouse.get_pos()[0]
        y = pygame.mouse.get_pos()[1]
        return int((x - camera.x) / camera.zoom), int((y - camera.y) / camera.zoom)
    return -1, -1


def place_tile(world, x, y, visible, tile):
    placable = True
    if tile.construct == BARRACKS:
        barracks = 0
        for world_x in range(0, len(world.world)):
            for world_y in range(0, len(world.world[world_x])):
                if world.world[world_x][world_y].construct.construct == BARRACKS:
                    barracks += 1
        if barracks > 20:
            placable = False
    elif tile.construct == DRILL:
        if x >= 0 and x < WORLD_SIZE and y >= 0 and y < WORLD_SIZE:
            if world.world[x][y].ground != ROCK:
                placable = False
    elif tile.construct == TURRET:
        turrets = 0
        drills = 0
        for world_x in range(0, len(world.world)):
            for world_y in range(0, len(world.world[world_x])):
                if world.world[world_x][world_y].construct.construct == TURRET:
                    turrets += 1
                if world.world[world_x][world_y].construct.construct == DRILL and world.world[world_x][world_y].construct.built:
                    drills += 1
        if turrets >= drills * 2:
            placable = False
    if placable:
        if x >= 0 and x < WORLD_SIZE and y >= 0 and y < WORLD_SIZE:
            if visible[x][y]:
                world.world[x][y].construct = tile


def update_constructs(world, inhabitants):
    building = True
    new_inhabitants = 0
    worker_coords = (-1, -1)
    for x in range(0, len(world.world)):
        for y in range(0, len(world.world[x])):
            if world.world[x][y].construct.construct == BARRACKS:
                new_inhabitants += world.world[x][y].construct.inhabitants
            if not(world.world[x][y].construct.built):
                constructable = False
                if x > 0:
                    if (world.world[x - 1][y].construct.construct == BARRACKS or world.world[x - 1][y].construct.construct == ROAD) and world.world[x - 1][y].construct.built:
                        constructable = True
                if x + 1 < WORLD_SIZE:
                    if (world.world[x + 1][y].construct.construct == BARRACKS or world.world[x + 1][y].construct.construct == ROAD) and world.world[x + 1][y].construct.built:
                        constructable = True
                if y > 0:
                    if (world.world[x][y - 1].construct.construct == BARRACKS or world.world[x][y - 1].construct.construct == ROAD) and world.world[x][y - 1].construct.built:
                        constructable = True
                if y + 1 < WORLD_SIZE:
                    if (world.world[x][y + 1].construct.construct == BARRACKS or world.world[x][y + 1].construct.construct == ROAD) and world.world[x][y + 1].construct.built:
                        constructable = True
                if constructable and building:
                    world.world[x][y].construct.timer -= inhabitants
                    if world.world[x][y].construct.timer <= 0:
                        world.world[x][y].construct.timer = 400
                        world.world[x][y].construct.built = True
                        if world.world[x][y].construct.construct == RADAR:
                            world.world[x][y].construct.view_range = RADAR_RANGE
                        elif world.world[x][y].construct.construct == BARRACKS:
                            world.world[x][y].construct.view_range = 1
                            world.world[x][y].construct.inhabitants = 1
                        elif world.world[x][y].construct.construct == ROAD:
                            world.world[x][y].construct.view_range = 0
                        elif world.world[x][y].construct.construct == TURRET:
                            world.world[x][y].construct.view_range = 2
                        elif world.world[x][y].construct.construct == DRILL:
                            world.world[x][y].construct.view_range = 0
                    building = False
            elif world.world[x][y].construct.construct == BARRACKS and world.world[x][y].construct.inhabitants < 4:
                world.world[x][y].construct.timer -= 1
                if world.world[x][y].construct.timer <= 0:
                    world.world[x][y].construct.inhabitants += 1
                    world.world[x][y].construct.timer = 400
                    if world.world[x][y].construct.inhabitants == 4:
                        worker_coords = (x, y)
    return worker_coords, new_inhabitants


def fire_turrets(world, minions):
    for x in range(0, len(world.world)):
        for y in range(0, len(world.world[x])):
            if world.world[x][y].construct.construct == TURRET:
                world.world[x][y].construct.timer -= 1
                if world.world[x][y].construct.timer == 0:
                    world.world[x][y].construct.timer = 60
                    for minion in minions:
                        if abs(int(minion.x) - x) < 2 and abs(int(minion.y) - y) < 2:
                            minions.remove(minion)
                            break


def scorch(world):
    for x in range(0, len(world.world)):
        for y in range(0, len(world.world[x])):
            if world.world[x][y].ground == SCORCHED:
                if random.randint(0, 1000) == 0:
                    world.world[x][y] = Tile(SCORCHED, NOTHING)
                    if x + 1 < WORLD_SIZE:
                        world.world[x + 1][y] = Tile(SCORCHED, NOTHING)
                    if x - 1 >= 0:
                        world.world[x - 1][y] = Tile(SCORCHED, NOTHING)
                    if y + 1 < WORLD_SIZE:
                        world.world[x][y + 1] = Tile(SCORCHED, NOTHING)
                    if y - 1 >= 0:
                        world.world[x][y - 1] = Tile(SCORCHED, NOTHING)


def spawn_worker(worker_coords, workers):
    if worker_coords[0] != -1:
        workers.append(Worker(worker_coords[0], worker_coords[1]))


def respawn_workers(world, workers):
    barracks = []
    for x in range(0, len(world.world)):
        for y in range(0, len(world.world[x])):
            if world.world[x][y].construct.construct == BARRACKS and world.world[x][y].construct.inhabitants == 4:
                barracks.append({"x": x, "y": y, "barracks": world.world[x][y], "ignore": False})
    for barrack in barracks:
        for worker in workers:
            if worker.x == barrack["x"] and worker.y == barrack["y"]:
                barrack["ignore"] = True
    for barrack in barracks:
        if not(barrack["ignore"]):
            if barrack["barracks"].construct.timer == 1:
                barrack["barracks"].construct.timer = 0
                workers.append(Worker(barrack["x"], barrack["y"]))
            elif barrack["barracks"].construct.timer == 0:
                barrack["barracks"].construct.timer = 400
            else:
                barrack["barracks"].construct.timer -= 1


def despawn_workers(world, workers):
    for worker in workers:
        if world.world[worker.x][worker.y].construct.construct != BARRACKS:
            workers.remove(worker)


def update_spawn_timer(spawn_timer):
    if spawn_timer > 0:
        spawn_timer -= 1
    else:
        spawn_timer = random.randint(0, 1280)
    return spawn_timer


def spawn_minions(spawn_timer, minions):
    if spawn_timer == 0:
        for minion in range(0, random.randint(0, 16)):
            side = random.randint(0, 3)
            if side == 0:
                minions.append(Minion(0, random.randint(0, WORLD_SIZE)))
            elif side == 1:
                minions.append(Minion(random.randint(0, WORLD_SIZE), 0))
            elif side == 2:
                minions.append(Minion(WORLD_SIZE, random.randint(0, WORLD_SIZE)))
            elif side == 3:
                minions.append(Minion(random.randint(0, WORLD_SIZE), WORLD_SIZE))


def update_minions(minions, visible):
    visible_list = []
    for x in range(0, len(visible)):
        for y in range(0, len(visible[x])):
            if visible[x][y]:
                visible_list.append((x, y))
    for minion in minions:
        target = visible_list[random.randint(0, len(visible_list) - 1)]
        if minion.x < target[0]:
            minion.x += 0.1
        else:
            minion.x -= 0.1
        if minion.y < target[1]:
            minion.y += 0.1
        else:
            minion.y -= 0.1


def spawn_ragor(ragor):
    global TIMER
    if TIMER > 10800:
        ragor.awake = True
    elif TIMER > 1800:
        if random.randint(0, 10000) == 0:
            ragor.awake = True


def update_ragor(ragor, visible):
    if ragor.awake:
        visible_list = []
        for x in range(0, len(visible)):
            for y in range(0, len(visible[x])):
                if visible[x][y]:
                    visible_list.append((x, y))
        target = visible_list[random.randint(0, len(visible_list) - 1)]
        if ragor.x < target[0]:
            ragor.x += 0.01
        else:
            ragor.x -= 0.01
        if ragor.y < target[1]:
            ragor.y += 0.01
        else:
            ragor.y -= 0.01


def wreck_terrain(ragor, world):
    if ragor.awake:
        world.world[int(ragor.x)][int(ragor.y)] = Tile(SCORCHED, NOTHING)
        if ragor.x >= 1:
            world.world[int(ragor.x) - 1][int(ragor.y)] = Tile(SCORCHED, NOTHING)
        world.world[int(ragor.x) + 1][int(ragor.y)] = Tile(SCORCHED, NOTHING)
        world.world[int(ragor.x)][int(ragor.y) - 1] = Tile(SCORCHED, NOTHING)
        world.world[int(ragor.x)][int(ragor.y) + 1] = Tile(SCORCHED, NOTHING)


def workers_fight_minions(workers, minions, world):
    worker_amounts = []
    minion_amounts = []
    for x in range(0, WORLD_SIZE):
        col = []
        for y in range(0, WORLD_SIZE):
            col.append({"amount": 0, "examples": []})
        worker_amounts.append(col)
    for x in range(0, WORLD_SIZE):
        col = []
        for y in range(0, WORLD_SIZE):
            col.append({"amount": 0, "examples": []})
        minion_amounts.append(col)
    for worker in workers:
        worker_amounts[int(worker.x)][int(worker.y)]["amount"] += 1
        worker_amounts[int(worker.x)][int(worker.y)]["examples"].append(worker)
    for minion in minions:
        minion_amounts[int(minion.x)][int(minion.y)]["amount"] += 1
        minion_amounts[int(minion.x)][int(minion.y)]["examples"].append(minion)
    for x in range(0, WORLD_SIZE):
        for y in range(0, WORLD_SIZE):
            if worker_amounts[x][y]["amount"] > 0 and minion_amounts[x][y]["amount"] > 0:
                if worker_amounts[x][y]["amount"] > minion_amounts[x][y]["amount"] or (worker_amounts[x][y]["amount"] == minion_amounts[x][y]["amount"] and random.randint(0, 1) == 0):
                    minions.remove(minion_amounts[x][y]["examples"][random.randint(0, len(minion_amounts[x][y]["examples"]) - 1)])
                else:
                    workers.remove(worker_amounts[x][y]["examples"][random.randint(0, len(worker_amounts[x][y]["examples"]) - 1)])
            elif worker_amounts[x][y]["amount"] == 0 and minion_amounts[x][y]["amount"] >= 3:
                world.world[x][y].construct = Construct(NOTHING)
    return workers, minions


def get_visible(world):
    visible_list = []
    for x in range(0, len(world.world)):
        for y in range(0, len(world.world[x])):
            for view_x in range(x - world.world[x][y].construct.view_range, x + world.world[x][y].construct.view_range + 1):
                if view_x >= 0 and view_x < WORLD_SIZE:
                    for view_y in range(y - world.world[x][y].construct.view_range, y + world.world[x][y].construct.view_range + 1):
                        if view_y >= 0 and view_y < WORLD_SIZE:
                            visible_list.append((view_x, view_y))
    visible = []
    for x in range(0, WORLD_SIZE):
        col = []
        for y in range(0, WORLD_SIZE):
            col.append(False)
        visible.append(col)
    l_bound = 256
    r_bound = -1
    u_bound = 256
    d_bound = -1
    for tile in visible_list:
        if tile[0] < l_bound:
            l_bound = tile[0]
        if tile[0] > r_bound:
            r_bound = tile[0]
        if tile[1] < u_bound:
            u_bound = tile[1]
        if tile[1] > d_bound:
            d_bound = tile[1]
        visible[tile[0]][tile[1]] = True
    return visible, l_bound, r_bound, u_bound, d_bound


def align_camera(camera, l_bound, r_bound, u_bound, d_bound):
    if r_bound - l_bound > d_bound - u_bound:
        camera.zoom = int(450 / (r_bound - l_bound + 1))
        camera.x = 140 - l_bound * camera.zoom
        camera.y = 12 - u_bound * camera.zoom + 32 * (r_bound - l_bound) / (d_bound - u_bound)
    else:
        camera.zoom = int(450 / (d_bound - u_bound + 1))
        camera.x = 140 - l_bound * camera.zoom + 32 * (d_bound - u_bound) / (r_bound - l_bound)
        camera.y = 12 - u_bound * camera.zoom


def display_world(screen, camera, world, visible):
    for x in range(0, len(visible)):
        for y in range(0, len(visible[x])):
            if visible[x][y]:
                ground = GROUND_PNGS[world.world[x][y].ground]
                screen.blit(pygame.transform.scale(ground, (int(camera.zoom), int(camera.zoom))), (x * camera.zoom + camera.x, y * camera.zoom + camera.y))
                construct = CONSTRUCT_PNGS[world.world[x][y].construct.construct]
                if not(world.world[x][y].construct.built):
                    construct = CONSTRUCTION_PNG
                if construct != NOTHING_PNG:
                    screen.blit(pygame.transform.scale(construct, (int(camera.zoom), int(camera.zoom))), (x * camera.zoom + camera.x, y * camera.zoom + camera.y))


def display_workers(screen, camera, workers):
    for worker in workers:
        screen.blit(pygame.transform.scale(WORKER_PNG, (int(camera.zoom / 4), int(camera.zoom / 4))), (worker.x * camera.zoom + camera.x, worker.y * camera.zoom + camera.y))


def display_minions(screen, camera, minions, visible):
    visible_minions = []
    for x in range(0, len(visible)):
        for y in range(0, len(visible[x])):
            if visible[x][y]:
                for minion in minions:
                    if minion.x > x and minion.x < x + 1 and minion.y > y and minion.y < y + 1:
                        visible_minions.append(minion)
    for minion in visible_minions:
        screen.blit(pygame.transform.scale(MINION_PNG, (int(camera.zoom / 4), int(camera.zoom / 4))), (minion.x * camera.zoom + camera.x, minion.y * camera.zoom + camera.y))


def display_ragor(screen, camera, ragor):
    if ragor.awake:
        screen.blit(pygame.transform.scale(RAGOR_PNG, (int(abs(camera.zoom) * 2), int(abs(camera.zoom) * 2))), (ragor.x * camera.zoom + camera.x, ragor.y * camera.zoom + camera.y))


def display_ui(screen, selection):
    png = CONSTRUCT_PNGS[selection.construct]
    screen.blit(pygame.transform.scale(png, (176, 176)), (624, 0))
    screen.blit(RADAR_BTN_PNG, (624, 176))
    screen.blit(BARRACKS_BTN_PNG, (624, 208))
    screen.blit(ROAD_BTN_PNG, (624, 240))
    screen.blit(TURRET_BTN_PNG, (624, 272))
    screen.blit(DRILL_BTN_PNG, (624, 304))
    screen.blit(NOTHING_BTN_PNG, (624, 448))


def tick_timer(timer):
    return timer + 1


try:
    main()
except BaseException:
    print("Time: " + str(TIMER / 60))
    print("Try again? Also follow me on Twitter @sage_se")
pygame.quit()
