cthulhu.py by sage 2018

Cthulhu v1.0 by sage 2018
Some notes:
Construction is faster with more barracks in the world
Only 21 barracks may be constructed
You can only construct adjacent to barracks and roads
Drills can only be constructed on top of stone
You can only construct twice the number of turrets as you have drills
Enemies are attracted to visible tiles
You'll know when the game's over - you'll know for sure

You will need pygame and Python 3 to run.
run with:
python cthulhu.py
or
python3 cthulhu.py
depending on your OS