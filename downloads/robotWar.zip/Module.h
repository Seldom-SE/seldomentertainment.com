#ifndef MODULE_H
#define MODULE_H

#include <string>

enum Module_Type {CORE, GUN};
enum Condition {LIVE, DEAD};

class Robot;

class Module
{
public:
    Module(Module_Type, std::string);
    Condition damage(int);
    void fire(Robot&);
    Module_Type get_type();
    Condition get_condition();
private:
    Condition condition;
    int hit_points;
    Module_Type type;
    std::string name;
};

#endif