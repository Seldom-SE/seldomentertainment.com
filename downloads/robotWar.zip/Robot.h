#ifndef ROBOT_H
#define ROBOT_H

#include <vector>
#include <string>

class Module;

class Robot
{
public:
    Robot(std::string);
    void take_turn(Robot&);
    void destroy_dead_modules();
    Module& get_random_module();
    int get_module_count();
    std::string get_name();
private:
    std::vector<Module> modules;
    std::string name;
};

#endif