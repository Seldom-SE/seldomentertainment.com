#include "Module.h"
#include "Robot.h"
#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

Robot::Robot(std::string name_)
{
    Module core(CORE, "core");
    Module gun(GUN, "gun");
    modules = {core, gun};
    name = name_;
}
void Robot::take_turn(Robot& enemy)
{
    std::cout << "\nIt is " << name << "'s turn\n";
    for(Module& module : modules)
    {
        if(module.get_type() == GUN)
        {
            std::cout << name << " fires at " << enemy.get_name() << std::endl;
            module.fire(enemy);
            break;
        }
    }
}
void Robot::destroy_dead_modules()
{
    for(int i = 0; i < modules.size(); i++)
    {
        if(modules.at(i).get_condition() == DEAD)
        {
            modules.erase(modules.begin() + i);
        }
    }
}
Module& Robot::get_random_module()
{
    return modules.at(rand() % modules.size());
}
int Robot::get_module_count()
{
    return modules.size();
}
std::string Robot::get_name()
{
    return name;
}

std::vector<Module> modules;
std::string name;