#include <iostream>
#include <string>
#include <stdio.h>
#include <cstdlib>
#include <ctime>
#include "Module.h"
#include "Robot.h"

int main()
{
    std::srand(std::time(NULL));

    Robot thomas_robot("Thomas's Robot");
    Robot cj_robot("CJ's Robot");
    bool fighting = true;

    std::cout << thomas_robot.get_name() + " VS " + cj_robot.get_name() + " --- FIGHT!\n\n";

    while(fighting)
    {
        thomas_robot.take_turn(cj_robot);
        if(cj_robot.get_module_count() == 0)
            break;
        cj_robot.take_turn(thomas_robot);
        if(thomas_robot.get_module_count() == 0)
            break;
    }

    char pause;
    std::cin >> pause;

    return 0;
}