#include "Module.h"
#include "Robot.h"
#include <iostream>
#include <vector>
#include <string>

Module::Module(Module_Type type_, std::string name_)
{
    condition = LIVE;
    hit_points = 4;
    type = type_;
    name = name_;
}
Condition Module::damage(int damage)
{
    std::cout << name << " takes " << damage << " damage\n";
    hit_points -= damage;
    std::cout << name << " is at " << hit_points << " hit points\n";
    if (hit_points <= 0)
    {
        std::cout << name << " was destroyed\n";
        condition = DEAD;
    }
    return condition;
}
void Module::fire(Robot& target)
{
    if (type == GUN)
    {
        Module& target_module = target.get_random_module();
        Condition condition = target_module.damage(rand() % 4);
        target.destroy_dead_modules();
    }
    else
    {
        std::cout << "non-gun attempted to fire\n";
    }
}
Module_Type Module::get_type()
{
    return type;
}

Condition Module::get_condition()
{
    return condition;
}