# dont_t_move.py
# by Dark Realms

# shading, player-rotating, door handle-dodging, length / width / height, magic numbers, variables from dictionaries, make repetative code efficient, new content

import math
import pygame
import random
import subprocess
import sys
import traceback

pygame.init()

# Window
GAME_LENGTH = 1024
GAME_HEIGHT = 512
GAME_CAPTION = "Don't Move"
BACKGROUND_COLOR = (0, 0, 0)

# System
RUN_MODE = "run"
QUIT_MODE = "quit"
# Gives player 2 strides per second
FRAMES_PER_SECOND = 23

# Direction
UP = 0
UP_RIGHT = 1
RIGHT = 2
DOWN_RIGHT = 3
DOWN = 4
DOWN_LEFT = 5
LEFT = 6
UP_LEFT = 7

# Player
PLAYER_SIZE = 32
PLAYER_INITIAL_X = (GAME_LENGTH) / 2
PLAYER_INITIAL_Y = (GAME_HEIGHT) / 2
PLAYER_INITIAL_DIRECTION = UP
PLAYER_INITIAL_ROTATION = 0
PLAYER_DIAGONAL_SIZE = 45
PLAYER_SPEED = 1
PLAYER_DIAGONAL_SPEED = 1 / math.sqrt(2)
PLAYER_DIAGONAL_OFFSET = 6.5
STANDING = 0
PLAYER_STANDING_IMAGE = pygame.image.load("player_standing.png")
WALKING = 1
TURNING = 2
PLAYER_INITIAL_STATE = STANDING
PLAYER_STARTING_WALKING_ANIMATION = [pygame.image.load("player_starting_walking_0.png"), pygame.image.load("player_starting_walking_1.png")]
PLAYER_WALKING_ANIMATION = [pygame.image.load("player_walking_00.png"), pygame.image.load("player_walking_01.png"), pygame.image.load("player_walking_02.png"), pygame.image.load("player_walking_03.png"), pygame.image.load("player_walking_04.png"), pygame.image.load("player_walking_05.png"), pygame.image.load("player_walking_06.png"), pygame.image.load("player_walking_07.png"), pygame.image.load("player_walking_08.png"), pygame.image.load("player_walking_09.png"), pygame.image.load("player_walking_10.png"), pygame.image.load("player_walking_11.png"), pygame.image.load("player_walking_12.png"), pygame.image.load("player_walking_13.png"), pygame.image.load("player_walking_14.png"), pygame.image.load("player_walking_15.png"), pygame.image.load("player_walking_16.png"), pygame.image.load("player_walking_17.png"), pygame.image.load("player_walking_18.png"), pygame.image.load("player_walking_19.png"), pygame.image.load("player_walking_20.png"), pygame.image.load("player_walking_21.png"), pygame.image.load("player_walking_22.png")]

# Room
ROOM_LENGTH = 128
ROOM_WIDTH = 128
ROOM_X = (GAME_LENGTH - ROOM_LENGTH) / 2
ROOM_Y = (GAME_HEIGHT - ROOM_WIDTH) / 2
ROOM_WALL_WIDTH = 45
ROOM_UPPER_WALL = ROOM_Y - PLAYER_SIZE
ROOM_LEFT_WALL = ROOM_X - PLAYER_SIZE
ROOM_LOWER_WALL = ROOM_Y + ROOM_WIDTH - PLAYER_SIZE
ROOM_RIGHT_WALL = ROOM_X + ROOM_LENGTH - PLAYER_SIZE
ROOM_IMAGE = pygame.image.load("room.png")
ROOM_IMAGE_LENGTH = ROOM_LENGTH + ROOM_WALL_WIDTH * 2
ROOM_IMAGE_WIDTH = ROOM_WIDTH + ROOM_WALL_WIDTH * 2
ROOM_IMAGE_X = (GAME_LENGTH - ROOM_IMAGE_LENGTH) / 2
ROOM_IMAGE_Y = (GAME_HEIGHT - ROOM_IMAGE_WIDTH) / 2
ROOM_IMAGE_RECTANGLE = pygame.Rect(ROOM_IMAGE_X, ROOM_IMAGE_Y, ROOM_IMAGE_LENGTH, ROOM_IMAGE_WIDTH)

def display_game(screen, game_data):
    # Draw the room
    # DEBUG: pygame.draw.rect(screen, (255, 255, 255), pygame.Rect(ROOM_X, ROOM_Y, ROOM_LENGTH, ROOM_WIDTH))
    screen.blit(ROOM_IMAGE, ROOM_IMAGE_RECTANGLE)
    # Draw the player
    screen.blit(game_data['player']['rotated_image'], pygame.Rect(game_data['player']['x'] - game_data['player']['rotated_image'].get_width() / 2, game_data['player']['y'] - game_data['player']['rotated_image'].get_height() / 2, PLAYER_SIZE, PLAYER_SIZE))
    
def clip_player_out_of_walls(game_data):
    # If the player has clipped into a wall, push him back to the nearest available location
    if game_data['player']['y'] < ROOM_UPPER_WALL:
        game_data['player']['y'] = ROOM_UPPER_WALL
    elif game_data['player']['y'] > ROOM_LOWER_WALL:
        game_data['player']['y'] = ROOM_LOWER_WALL
    if game_data['player']['x'] < ROOM_LEFT_WALL:
        game_data['player']['x'] = ROOM_LEFT_WALL
    elif game_data['player']['x'] > ROOM_RIGHT_WALL:
        game_data['player']['x'] = ROOM_RIGHT_WALL

def orient_player(game_data):
    # Rotate player's original image. Direction is converted to degrees.
    game_data['player']['rotated_image'] = pygame.transform.rotate(game_data['player']['image'], game_data['player']['rotation'])

def rotate_player(game_data):
    # Find where to turn
    destination = (8 - game_data['player']['facing']) * 45
    if destination == 360:
        destination = 0
    if game_data['player']['rotation'] != destination:
        # Find which direction to turn
        difference = game_data['player']['rotation'] - destination
        if difference < 0:
            difference += 360
        # Turn
        if difference > 180:
            game_data['player']['rotation'] += 8
        elif difference < 180:
            game_data['player']['rotation'] -= 8
        else:
            if random.randint(0, 1):
                game_data['player']['rotation'] += 8
            else:
                game_data['player']['rotation'] -= 8
        # Put rotation into bounds
        if game_data['player']['rotation'] >= 360:
            game_data['player']['rotation'] -= 360
        elif game_data['player']['rotation'] < 0:
            game_data['player']['rotation'] += 360
        # Correct overshots
        difference = game_data['player']['rotation'] - destination
        if difference < 7 and difference > -7:
            game_data['player']['rotation'] = destination

def update_player_animation(game_data):
    # Set the player image
    if game_data['player']['state'] == STANDING:
        # Frame -2 is used for the starting walking animation
        game_data['player']['frame'] = -2
        game_data['player']['image'] = PLAYER_STANDING_IMAGE
    elif game_data['player']['state'] == WALKING:
        if game_data['player']['frame'] < 0:
            # The starting walking animation is not looped
            game_data['player']['image'] = PLAYER_STARTING_WALKING_ANIMATION[game_data['player']['frame'] + 2]
            game_data['player']['frame'] += 1
        else:
            # Loop the walking animation
            if game_data['player']['frame'] > 21:
                game_data['player']['frame'] = 0
            else:
                game_data['player']['frame'] += 1
            game_data['player']['image'] = PLAYER_WALKING_ANIMATION[game_data['player']['frame']]
        
def move_player(direction, speed, game_data):
    game_data['player']['facing'] = direction
    # Unpackage what the direction means and move the player
    if abs(direction - 4) > 2:
        game_data['player']['y'] -= speed
    if abs(direction - 2) < 2:
        game_data['player']['x'] += speed
    if abs(direction - 4) < 2:
        game_data['player']['y'] += speed
    if direction > 4:
        game_data['player']['x'] -= speed
    game_data['player']['state'] = WALKING

def handle_player_movement(up, left, down, right, game_data):
    # Find the direction, then move the player
    if up ^ down:
        if up:
            if right ^ left:
                if right:
                    move_player(UP_RIGHT, PLAYER_DIAGONAL_SPEED, game_data)
                else:
                    move_player(UP_LEFT, PLAYER_DIAGONAL_SPEED, game_data)
            else:
                move_player(UP, PLAYER_SPEED, game_data)
        else:
            if right ^ left:
                if right:
                    move_player(DOWN_RIGHT, PLAYER_DIAGONAL_SPEED, game_data)
                else:
                    move_player(DOWN_LEFT, PLAYER_DIAGONAL_SPEED, game_data)
            else:
                move_player(DOWN, PLAYER_SPEED, game_data)
    else:
        if right ^ left:
            if right:
                move_player(RIGHT, PLAYER_SPEED, game_data)
            else:
                move_player(LEFT, PLAYER_SPEED, game_data)

def check_events(game_data):
    # Player facing
    up = False
    right = False
    down = False
    left = False
    # Events
    for event in pygame.event.get():
        # Test if the window has been closed
        if event.type == pygame.QUIT:
            game_data['mode'] = QUIT_MODE
    # Reset state
    game_data['player']['state'] = STANDING
    # Keys down
    pressed = pygame.key.get_pressed()
    # Find the direction the player is moving
    # "W" key
    if pressed[pygame.K_w] and game_data['player']['y'] > ROOM_UPPER_WALL:
        up = True
    # "A" key
    if pressed[pygame.K_a] and game_data['player']['x'] > ROOM_LEFT_WALL:
        left = True
    # "S" key
    if pressed[pygame.K_s] and game_data['player']['y'] < ROOM_LOWER_WALL:
        down = True
    # "D" key
    if pressed[pygame.K_d] and game_data['player']['x'] < ROOM_RIGHT_WALL:
        right = True
    # Orient and move player
    handle_player_movement(up, left, down, right, game_data)

# Put initial objects in their proper locations
def setup():
    # Set the window name
    pygame.display.set_caption(GAME_CAPTION)
    # Return the screen, clock, and game data
    return pygame.display.set_mode((GAME_LENGTH, GAME_HEIGHT)), pygame.time.Clock(), {'mode': RUN_MODE, 'player': {'x': PLAYER_INITIAL_X, 'y': PLAYER_INITIAL_Y, 'facing': PLAYER_INITIAL_DIRECTION, 'rotation': PLAYER_INITIAL_ROTATION, 'state': PLAYER_INITIAL_STATE, 'rotated_image': PLAYER_STANDING_IMAGE, 'image': PLAYER_STANDING_IMAGE, 'frame': 0}}

def main():
    screen, clock, game_data = setup()
    # Main loop
    while game_data['mode'] == RUN_MODE:
        # Check for and perform events
        check_events(game_data)
        # Switch to next animation frame
        update_player_animation(game_data)
        # Turn player
        rotate_player(game_data)
        # Turn player image
        orient_player(game_data)
        # Place the player within bounds
        clip_player_out_of_walls(game_data)
        # Empty the screen
        screen.fill(BACKGROUND_COLOR)
        # Put objects onto the screen
        display_game(screen, game_data)
        # Show the screen
        pygame.display.flip()
        # Wait one tick at 64 FPS
        clock.tick(FRAMES_PER_SECOND)
        # DEBUG: print(game_data['player']['rotation'])

def debug():
    screen, clock, game_data = setup()
    square = pygame.transform.scale(pygame.image.load("debug.png"), (256,256))
    rotation = 0
    while game_data['mode'] == "run":
        check_events(game_data)
        screen.fill((0,0,0))
        rotated_square = pygame.transform.rotate(square, rotation)
        offset = (rotated_square.get_width() - 256) / 2
        print(rotated_square.get_width(), offset)
        screen.blit(rotated_square, pygame.Rect(384 - offset, 128 - offset, 32, 32))
        pygame.display.flip()
        rotation += 1
        clock.tick(32)

# Run the program. Find errors.
try:
    main()
except Exception as e:
    for frame in traceback.extract_tb(sys.exc_info()[2]):
        fname, lineno, fn, text = frame
        print("Error in %s on line %d" % (fname, lineno))
    print(sys.exc_info())
finally:
    pygame.quit()
    sys.exit()
