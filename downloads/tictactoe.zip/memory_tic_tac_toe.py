# Memory Tic-Tac-Toe
# memory_tic_tac_toe.py
# Thomas Hansen
# 2-player game which follows the rules of Tic-Tac-Toe
# The two players take turns entering the coordinates where to put his piece
#  on a 3x3 game board
# The game board is never shown until the end
# If a player places his piece in a spot where a piece already exists,
#  he is not informed and the piece is not set
# Once game pieces of the same player match 3-in-a-row, the game ends and
#  information such as who won, the board, how many pieces were placed on top
#  of other pieces, etc is shown

# Board posistions
row = ""
column = ""

# Rows and Columns
top = "Top"
middle = "Middle"
bottom = "Bottom"
left = "Left"
right = "Right"

# Pieces
X = "X"
O = "O"
_ = "-"

# Board
top_left = _
top_middle = _
top_right = _
middle_left = _
middle_middle = _
middle_right = _
bottom_left = _
bottom_middle = _
bottom_right = _

# Piece successfully placed
piece_placed = False

# Pieces placed on other pieces
piece_overlaps = {"X": 0, "O": 0}

# Turn
turn = ""

# Game State
playing = True

# Show introduction and instructions
print("Memory Tic-Tac-Toe")
print("Play this game like regular Tic-Tac-Toe, but you")
print("won't know the board until the end.")
print("The game will request the rows and columns to")
print("put the pieces.")
print("For the row, enter \"Top\", \"Middle\", or \"Bottom\".")
print("For the column, enter \"Left\", \"Middle\", or \"Right\".")
print()

# As long as no one has won
while playing:

    # Switch turn
    if turn == X:
        turn = O
    else:
        turn = X
    print()
    print(turn + "'s Turn")

    # Reset board positions
    row = ""
    column = ""

    # Input the row
    while (row == ""):
        row = input("Row > ")
        if (row != top and row != middle and row != bottom):
            print("Enter \"Top\", \"Middle\", or \"Bottom\".")
            row = ""

    # Input the column
    while (column == ""):
        column = input("Column > ")
        if (column != left and column != middle and column != right):
            print("Enter \"Left\", \"Middle\", or \"Right\".")
            column = ""

    # Set board position
    if (row == top):
        if (column == left):
            if (top_left == _):
                top_left = turn
                piece_placed = True
        elif (column == middle):
            if (top_middle == _):
                top_middle = turn
                piece_placed = True
        elif (column == right):
            if (top_right == _):
                top_right = turn
                piece_placed = True
    elif (row == middle):
        if (column == left):
            if (middle_left == _):
                middle_left = turn
                piece_placed = True
        elif (column == middle):
            if (middle_middle == _):
                middle_middle = turn
                piece_placed = True
        elif (column == right):
            if (middle_right == _):
                middle_right = turn
                piece_placed = True
    elif (row == bottom):
        if (column == left):
            if (bottom_left == _):
                bottom_left = turn
                piece_placed = True
        elif (column == middle):
            if (bottom_middle == _):
                bottom_middle = turn
                piece_placed = True
        elif (column == right):
            if (bottom_right == _):
                bottom_right = turn   
                piece_placed = True

    # Check if a piece was placed
    if piece_placed:
        piece_placed = False
    else:
        piece_overlaps[turn] += 1

    # Check for a 3-in-a-row
    if top_left == turn:
        if top_middle == turn:
            if top_right == turn:
                playing = False
        if middle_middle == turn:
            if bottom_right == turn:
                playing = False
        if middle_left == turn:
            if bottom_left == turn:
                playing = False
    if top_middle == turn:
        if middle_middle == turn:
            if bottom_middle == turn:
                playing = False
    if top_right == turn:
        if middle_middle == turn:
            if bottom_left == turn:
                playing = False
        if middle_right == turn:
            if bottom_right == turn:
                playing = False
    if middle_left == turn:
        if middle_middle == turn:
            if middle_right == turn:
                playing = False
    if bottom_left == turn:
        if bottom_middle == turn:
            if bottom_right == turn:
                playing = False

    # Update board
    board = [top_left, top_middle, top_right, middle_left, middle_middle, middle_right, bottom_left, bottom_middle, bottom_right]

    # Check if the board is full
    empty_positions = 0
    for position in board:
        if position == _:
            empty_positions += 1
    if empty_positions == 0:
        turn = "Nobody"
        playing = False

# A player has won. The player of whom the turn is wins.
print()
print(turn, "won.")
print()
print(top_left, top_middle, top_right)
print(middle_left, middle_middle, middle_right)
print(bottom_left, bottom_middle, bottom_right)
print()
print("X placed", piece_overlaps["X"], "pieces over existing pieces.")
print("O placed", piece_overlaps["O"], "pieces over existing pieces.")
print()
print(9 - empty_positions, "pieces were placed.")
print(empty_positions, "spaces were left empty.")
