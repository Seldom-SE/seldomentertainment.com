extern crate rand;
extern crate ansi_term;

use rand::Rng;
use std::time::Duration;
use std::thread;
use std::fmt;
use ansi_term::Colour::{Red, Yellow, RGB};

const GRID_SIZE: usize = 40;
const FRAME_DURATION: Duration = Duration::from_millis(100);

trait Rule {
    fn next(&self, state: u8, neighbors: u8) -> u8;
}

struct GameOfLife {}

impl Rule for GameOfLife {
    fn next(&self, state: u8, neighbors: u8) -> u8 {
        match (state, neighbors) {
            (0, 3) => 1,
            (1, 2...3) => 1,
            _ => 0,
        }
    }
}

struct BriansBrain {}

impl Rule for BriansBrain {
    fn next(&self, state: u8, neighbors: u8) -> u8 {
        match (state, neighbors) {
            (0, 2) => 2,
            (2, _) => 1,
            _ => 0,
        }
    }
}

struct StarWars {}

impl Rule for StarWars {
    fn next(&self, state: u8, neighbors: u8) -> u8 {
        match (state, neighbors) {
            (0, 2) => 3,
            (3, 3...5) => 3,
            (3, _) => 2,
            (2, _) => 1,
            _ => 0
        }
    }
}

struct Grid {
    rule: StarWars, // TO CHANGE
    cells: [[u8; GRID_SIZE * 4]; GRID_SIZE],
}

impl Grid {
    fn new() -> Self {
        let mut cells = [[0; GRID_SIZE * 4]; GRID_SIZE];
        for (i, row) in cells.iter_mut().enumerate() {
            for (j, cell) in row.iter_mut().enumerate() {
                //*cell = if i <= 1 && j <= 1 {3} else {0}
                *cell = rand::thread_rng().gen_range(0, 4); // TO CHANGE
            }
        }
        Self {
            rule: StarWars {}, // TO CHANGE
            cells: cells
        }
    }

    fn tick(&mut self) {
        let neighbors = self.get_neighbors_from_cells();
        self.gen_cells_from_neighbors(neighbors);
    }

    fn get_neighbors_from_cells(&self) -> [[u8; GRID_SIZE * 4]; GRID_SIZE] {
        let mut neighbors = [[0; GRID_SIZE * 4]; GRID_SIZE];
        for (i, row) in neighbors.iter_mut().enumerate() {
            for (j, cell) in row.iter_mut().enumerate() {
                *cell = self.get_neighbors(i, j)
            }
        }
        neighbors
    }

    fn get_neighbors(&self, row: usize, col: usize) -> u8 {
        let mut amt = 0;
        let neighbors = [(row as i16 - 1, col as i16 - 1), (row as i16 - 1, col as i16), (row as i16 - 1, col as i16 + 1),
                         (row as i16,     col as i16 - 1),                               (row as i16,     col as i16 + 1),
                         (row as i16 + 1, col as i16 - 1), (row as i16 + 1, col as i16), (row as i16 + 1, col as i16 + 1)];
        for (i, j) in neighbors.iter() {
            if self.get_at(*i, *j) >= 3 {amt += 1}; // TO CHANGE
        }
        amt
    }

    fn get_at(&self, row: i16, col: i16) -> u8 {
        self.cells[if row < 0 {(GRID_SIZE       as i16 + row) as usize} else if row >= GRID_SIZE       as i16 {row as usize - GRID_SIZE}       else {row as usize}]
                  [if col < 0 {((GRID_SIZE * 4) as i16 + col) as usize} else if col >= (GRID_SIZE * 4) as i16 {col as usize - (GRID_SIZE * 4)} else {col as usize}]
    }

    fn gen_cells_from_neighbors(&mut self, neighbors: [[u8; GRID_SIZE * 4]; GRID_SIZE]) {
        for i in 0..GRID_SIZE {
            for j in 0..GRID_SIZE * 4 {
                self.cells[i][j] = self.rule.next(self.cells[i][j], neighbors[i][j]);
            }
        }
    }
}

impl fmt::Display for Grid {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut out = String::new();
        for row in self.cells.iter() {
            for cell in row.iter() {
                let string = match *cell {
                    0 => " ".to_string(),
                    1 => Red.paint("#").to_string(),
                    2 => RGB(255, 128, 0).paint("#").to_string(),
                    3 => Yellow.paint("#").to_string(),
                    _ => Red.paint("!").to_string()
                };
                out += string.as_str();
            }
            out += "\n";
        }
        write!(f, "{}", out)
    }
}

fn clear() {
    print!("{}[2J", 27 as char);
}

fn main() {
    let mut grid = Grid::new();
    loop {
        grid.tick();
        clear();
        print!("{}", grid);
        thread::sleep(FRAME_DURATION);
    }
}
