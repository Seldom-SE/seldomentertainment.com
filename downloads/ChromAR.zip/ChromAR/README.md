# ChromAR

Color matching app for the colorblind and those with no sense for matching

By:
Rithvik Arun (rarun)
Tom Hansen (Seldom)

At sunhacks 2019
