//
//  PaletteWrapper.swift
//  ChromAR
//
//  Created by Tom Hansen on 9/21/19.
//  Copyright © 2019 Rithvik Arun. All rights reserved.
//

import Foundation

struct PaletteWrapper {
    var palette: Palette
    var index: Int
}
