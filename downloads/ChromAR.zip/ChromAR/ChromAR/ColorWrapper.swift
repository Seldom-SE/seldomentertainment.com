//
//  ColorWrapper.swift
//  ChromAR
//
//  Created by Tom Hansen on 9/21/19.
//  Copyright © 2019 Rithvik Arun. All rights reserved.
//

import Foundation
import UIKit

struct ColorWrapper {
    var color: UIColor
    var index: Int
    var matched: Bool
}
